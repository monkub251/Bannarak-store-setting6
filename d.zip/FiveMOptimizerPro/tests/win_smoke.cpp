// Windows-only smoke test: exercises the real registry, process runner and system detection.
// Safe to run on a real PC: it only touches HKCU\Software\FmoSmokeTest, which it removes again.
#include <iostream>
#include <windows.h>

#include "Optimizer.h"
#include "Platform.h"
#include "ProcessReducer.h"
#include "Registry.h"
#include "Util.h"

using namespace fmo;
static int fails = 0;
#define CHECK(c) do { if (!(c)) { ++fails; std::cerr << "FAIL line " << __LINE__ << ": " #c "\n"; } else std::cout << "ok   " #c "\n"; } while (0)

int main(int argc, char** argv) {
    if (argc > 1 && std::string(argv[1]) == "--sleep") { Sleep(60000); return 0; }
    auto reg = makeSystemRegistry();
    CHECK(reg->isReal());
    const std::string key = "Software\\FmoSmokeTest";
    std::string err;
    CHECK(reg->read(Hive::HKCU, key, "D").state == RegRead::NotFound);
    CHECK(reg->write(Hive::HKCU, key, "D", RegValue::dw(0x26), err));
    CHECK(reg->write(Hive::HKCU, key, "S", RegValue::sz("GpuPreference=2;"), err));
    CHECK(reg->write(Hive::HKCU, key, "ünï cödé", RegValue::sz("ok"), err));
    RegRead d = reg->read(Hive::HKCU, key, "D");
    CHECK(d.state == RegRead::Found && d.value == RegValue::dw(0x26));
    RegRead s = reg->read(Hive::HKCU, key, "S");
    CHECK(s.state == RegRead::Found && s.value.str == "GpuPreference=2;");
    CHECK(reg->read(Hive::HKCU, key, "ünï cödé").value.str == "ok");
    CHECK(reg->removeValue(Hive::HKCU, key, "D", err));
    CHECK(reg->read(Hive::HKCU, key, "D").state == RegRead::NotFound);
    CHECK(reg->removeValue(Hive::HKCU, key, "D", err));  // idempotent
    reg->removeValue(Hive::HKCU, key, "S", err);
    reg->removeValue(Hive::HKCU, key, "ünï cödé", err);

    // Full optimizer cycle against the real registry (HKCU tweaks only; no admin needed)
    {
        SysInfo sys = detectSystem(*reg);
        CHECK(sys.windows && sys.logicalCores > 0 && sys.ramBytes > 0);
        std::cout << "     " << sys.osName << " build " << sys.build << " " << sys.cpu << " elevated=" << sys.elevated << "\n";
        fs::path data = fs::temp_directory_path() / "fmo_smoke_data";
        fs::remove_all(data);
        BackupStore store(data / "backups");
        OptimizerEnv env;
        env.registry = reg.get();
        env.backups = &store;
        env.dataDir = data;
        env.sys = sys;
        env.sys.elevated = false;   // never touch HKLM from a smoke test
        Optimizer opt(env);
        Options o;
        o.cleanJunk = false;
        o.powerPlan = false;
        Report r = opt.run(o);
        std::cout << Optimizer::reportText(r);
        CHECK(r.count(Status::Failed) == 0);
        auto sets = store.list();
        if (!sets.empty()) {
            Report rr = opt.restore(sets[0]);
            CHECK(rr.count(Status::Failed) == 0);
        }
        fs::remove_all(data);
    }

    ProcResult p = runProcess({systemTool("whoami.exe")}, 10000);
    std::cout << "     whoami -> started=" << p.started << " exit=" << p.exitCode << " out=" << p.output << "\n";
    CHECK(p.started);
    ProcResult bad = runProcess({"C:\\definitely\\missing.exe"}, 2000);
    CHECK(!bad.started && !bad.error.empty());

    auto procs = enumerateProcesses();
    CHECK(!procs.empty());
    bool foundSelf = false;
    for (auto& r : procs) if (r.pid == currentPid()) foundSelf = true;
    CHECK(foundSelf);
    CHECK(!runningProcessNames().empty());
    // Process reducer: start a throw-away process, select it with the MAXIMUM tier and verify it is really gone.
    {
        wchar_t selfPath[MAX_PATH];
        GetModuleFileNameW(nullptr, selfPath, MAX_PATH);
        std::string exe = narrow(selfPath);
        STARTUPINFOW si{};
        si.cb = sizeof si;
        PROCESS_INFORMATION pi{};
        std::wstring cmd = widen("\"" + exe + "\" --sleep");
        if (CreateProcessW(nullptr, cmd.data(), nullptr, nullptr, FALSE, 0, nullptr, nullptr, &si, &pi)) {
            Sleep(1500);
            auto all = enumerateProcesses();
            std::vector<ProcRow> only;
            for (auto& r : all) if (r.pid == pi.dwProcessId) only.push_back(r);
            CHECK(only.size() == 1);
            auto sel = selectTargets(ReduceTier::Maximum, {}, only, currentPid());
            CHECK(sel.size() == 1);
            ReduceOutcome out = reduceProcesses(sel);
            CHECK(out.closed.size() == 1 && out.failed.empty());
            CHECK(WaitForSingleObject(pi.hProcess, 0) == WAIT_OBJECT_0);
            CloseHandle(pi.hProcess);
            CloseHandle(pi.hThread);
        } else {
            std::cout << "     (could not start helper process; reducer termination not exercised)\n";
        }
    }
    std::cout << (fails ? "SMOKE FAILED\n" : "SMOKE PASSED\n");
    return fails ? 1 : 0;
}
