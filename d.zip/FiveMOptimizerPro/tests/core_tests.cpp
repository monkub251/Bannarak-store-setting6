// Minimal dependency-free test runner for the core engine.
#include <atomic>
#ifdef _WIN32
#include <process.h>
static int fmoPid() { return _getpid(); }
#else
#include <unistd.h>
static int fmoPid() { return static_cast<int>(::getpid()); }
#endif
#include <chrono>
#include <fstream>
#include <iostream>

#include "Backup.h"
#include "JunkCleaner.h"
#include "Optimizer.h"
#include "ProcessReducer.h"
#include "Tweaks.h"

using namespace fmo;

static int g_fail = 0, g_checks = 0;
#define CHECK(cond)                                                                       \
    do {                                                                                  \
        ++g_checks;                                                                       \
        if (!(cond)) {                                                                    \
            ++g_fail;                                                                     \
            std::cerr << "FAIL " << __FILE__ << ":" << __LINE__ << "  " #cond << "\n";    \
        }                                                                                 \
    } while (0)

static fs::path tmpRoot() {
    static fs::path r = [] {
        fs::path p = fs::temp_directory_path() / ("fmo_test_" + nowStamp() + "_" + std::to_string(fmoPid()));
        fs::create_directories(p);
        return p;
    }();
    return r;
}
static fs::path fresh(const std::string& name) {
    fs::path p = tmpRoot() / name;
    fs::remove_all(p);
    fs::create_directories(p);
    return p;
}
static void touch(const fs::path& p, size_t bytes, int ageMinutes = 0) {
    fs::create_directories(p.parent_path());
    std::ofstream(p, std::ios::binary) << std::string(bytes, 'x');
    if (ageMinutes) fs::last_write_time(p, fs::file_time_type::clock::now() - std::chrono::minutes(ageMinutes));
}
static bool findResult(const Report& r, const std::string& id, Status s) {
    for (auto& i : r.items)
        if (i.id == id && i.status == s) return true;
    return false;
}

// ------------------------------------------------------------------ util
static void testUtil() {
    std::string s = "a=b\tc\nd%e";
    CHECK(unescapeField(escapeField(s)) == s);
    CHECK(escapeField(s).find('\t') == std::string::npos);
    CHECK(JunkCleaner::globMatch("thumbcache_*.db", "ThumbCache_256.db"));
    CHECK(!JunkCleaner::globMatch("thumbcache_*.db", "thumbcache_256.txt"));
    CHECK(formatBytes(1536) == "1.50 KB");
}

// ------------------------------------------------------------------ backup
static void testBackup() {
    BackupStore st(fresh("backups"));
    BackupEntry e;
    e.kind = "reg";
    e.f = {{"key", "Soft\\ware"}, {"name", "a=b"}, {"data", "line\nbreak"}};
    BackupSet a, b;
    std::string err;
    CHECK(st.create({e, e}, a, err));
    CHECK(st.create({e}, b, err));
    CHECK(a.id != b.id);  // never overwrites
    auto list = st.list();
    CHECK(list.size() == 2);
    CHECK(list[0].entries[0] == e);
    // incomplete manifest (no END) is rejected and skipped
    fs::path bad = st.root() / "99999999-999999";
    fs::create_directories(bad);
    std::ofstream(bad / "manifest.txt") << "FMO-BACKUP\t1\nCREATED\tx\nE\treg\tk=v\n";
    CHECK(st.list().size() == 2);
    // unwritable root -> create fails cleanly
    fs::path file = tmpRoot() / "iam_a_file";
    std::ofstream(file) << "x";
    BackupStore broken(file / "sub");
    CHECK(!broken.create({e}, a, err));
}

// ------------------------------------------------------------------ tweak planning
static SysInfo win11(bool elevated, bool home = false) {
    SysInfo s;
    s.windows = true;
    s.build = 22631;
    s.elevated = elevated;
    s.homeEdition = home;
    return s;
}

static void testPlan() {
    auto cat = tweakCatalog();
    // both profiles: shared setting merged once, naming both profiles
    Plan p = buildPlan(cat, ProfileImpact | ProfileFlow, {}, win11(true), true);
    int sysresp = 0;
    for (auto& i : p.items)
        if (i.def.id == "sysresp") {
            ++sysresp;
            CHECK(i.sources.find("VANTA IMPACT") != std::string::npos && i.sources.find("ONYX FLOW") != std::string::npos);
        }
    CHECK(sysresp == 1);
    // opt-in tweaks are never part of a normal plan
    for (auto& i : p.items) CHECK(i.def.id.rfind("ptr_", 0) != 0);
    Plan withPtr = buildPlan(cat, ProfileImpact, {"ptr_MouseSpeed"}, win11(true), true);
    bool seen = false;
    for (auto& i : withPtr.items) seen |= i.def.id == "ptr_MouseSpeed";
    CHECK(seen);
    // not elevated: HKLM items skipped with a reason, HKCU items remain
    Plan na = buildPlan(cat, ProfileImpact | ProfileFlow, {}, win11(false), false);
    bool anyHklm = false;
    for (auto& i : na.items) anyHklm |= i.def.hive == Hive::HKLM;
    CHECK(!anyHklm);
    CHECK(!na.notes.empty());
    // Home edition: policy tweak skipped
    Plan home = buildPlan(cat, ProfileImpact, {}, win11(true, true), true);
    for (auto& i : home.items) CHECK(!i.def.policy);
    // Windows 11 build: Windows-10-only setting skipped
    Plan w11 = buildPlan(cat, ProfileFlow, {}, win11(true), true);
    for (auto& i : w11.items) CHECK(i.def.id != "bgapps");
    // conflict: same target, different value -> both dropped and reported
    TweakDef a, b;
    a.id = "a"; a.title = "A"; a.hive = b.hive = Hive::HKCU; a.key = b.key = "K"; a.name = b.name = "V";
    b.id = "b"; b.title = "B";
    a.desired = RegValue::dw(1); b.desired = RegValue::dw(2);
    a.profiles = ProfileImpact; b.profiles = ProfileFlow;
    Plan c = buildPlan({a, b}, ProfileImpact | ProfileFlow, {}, win11(true), true);
    CHECK(c.items.empty());
    CHECK(c.notes.size() == 1 && c.notes[0].status == Status::Warning);
    // only one of the two profiles active -> no conflict
    Plan d = buildPlan({a, b}, ProfileImpact, {}, win11(true), true);
    CHECK(d.items.size() == 1);
}

// ------------------------------------------------------------------ optimizer end to end (memory registry)
static Env makeEnv(MemoryRegistry& reg, BackupStore& store, IProcessApi* procs, bool elevated = true) {
    Env e;
    e.reg = &reg;
    e.store = &store;
    e.procs = procs;
    e.sys = win11(elevated);
    e.sys.windows = true;
    e.cleaner = CleanerEnv{};
    return e;
}

static Options baseOpts() {
    Options o;
    o.cleanJunk = false;
    o.powerPlan = false;
    return o;
}

static void testOptimizerAndRestore() {
    MemoryRegistry reg;
    // pre-existing user values: one differs, one already optimal, rest absent
    std::string err;
    reg.write(Hive::HKCU, "Software\\Microsoft\\GameBar", "AutoGameModeEnabled", RegValue::dw(0), err);
    reg.write(Hive::HKCU, "System\\GameConfigStore", "GameDVR_Enabled", RegValue::dw(0), err);  // already optimal
    reg.write(Hive::HKLM, "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile", "SystemResponsiveness", RegValue::dw(20), err);
    BackupStore store(fresh("opt_backups"));
    Optimizer opt(makeEnv(reg, store, nullptr));
    Report r = opt.run(baseOpts());

    CHECK(!r.backupId.empty());
    CHECK(findResult(r, "gamemode", Status::Applied));
    CHECK(findResult(r, "gamedvr_store", Status::AlreadyOk));
    CHECK(findResult(r, "sysresp", Status::Applied));
    CHECK(reg.read(Hive::HKCU, "Software\\Microsoft\\GameBar", "AutoGameModeEnabled").value == RegValue::dw(1));
    CHECK(reg.read(Hive::HKLM, "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", "Scheduling Category").value == RegValue::sz("High"));
    CHECK(r.restartRecommended);  // Win32PrioritySeparation applied

    // second run: nothing left to change, no new backup
    Report r2 = opt.run(baseOpts());
    CHECK(r2.backupId.empty());
    CHECK(r2.count(Status::Applied) == 0);

    // restore returns original values and removes values that did not exist before
    auto sets = store.list();
    CHECK(sets.size() == 1);
    Report rr = opt.restore(sets[0]);
    CHECK(rr.count(Status::Failed) == 0);
    CHECK(reg.read(Hive::HKCU, "Software\\Microsoft\\GameBar", "AutoGameModeEnabled").value == RegValue::dw(0));
    CHECK(reg.read(Hive::HKLM, "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile", "SystemResponsiveness").value == RegValue::dw(20));
    CHECK(reg.read(Hive::HKLM, "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games", "Scheduling Category").state == RegRead::NotFound);
    CHECK(reg.read(Hive::HKCU, "System\\GameConfigStore", "GameDVR_Enabled").value == RegValue::dw(0));
    CHECK(store.list()[0].restored);
}

static void testOptimizerFailures() {
    // writes that silently do not stick are reported as FAILED, never as applied
    {
        MemoryRegistry reg;
        reg.silentlyDropWrites = true;
        BackupStore store(fresh("fail1"));
        Optimizer opt(makeEnv(reg, store, nullptr));
        Report r = opt.run(baseOpts());
        CHECK(r.count(Status::Applied) == 1);  // only the backup entry
        CHECK(findResult(r, "gamemode", Status::Failed));
    }
    // access denied on HKLM: HKCU still applied, HKLM failed
    {
        MemoryRegistry reg;
        reg.denyWriteHives.insert("HKLM");
        BackupStore store(fresh("fail2"));
        Optimizer opt(makeEnv(reg, store, nullptr));
        Report r = opt.run(baseOpts());
        CHECK(findResult(r, "gamemode", Status::Applied));
        CHECK(findResult(r, "sysresp", Status::Failed));
    }
    // backup cannot be written: nothing is modified
    {
        MemoryRegistry reg;
        fs::path file = tmpRoot() / "blocker";
        std::ofstream(file) << "x";
        BackupStore store(file / "sub");
        Optimizer opt(makeEnv(reg, store, nullptr));
        Report r = opt.run(baseOpts());
        CHECK(findResult(r, "backup", Status::Failed));
        CHECK(reg.read(Hive::HKCU, "Software\\Microsoft\\GameBar", "AutoGameModeEnabled").state == RegRead::NotFound);
    }
    // not elevated: HKLM tweaks skipped, nothing attempted
    {
        MemoryRegistry reg;
        BackupStore store(fresh("fail3"));
        Optimizer opt(makeEnv(reg, store, nullptr, false));
        Report r = opt.run(baseOpts());
        CHECK(findResult(r, "sysresp", Status::Skipped));
        CHECK(reg.read(Hive::HKLM, "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile", "SystemResponsiveness").state == RegRead::NotFound);
    }
}

// ------------------------------------------------------------------ cleaner
static CleanerEnv cleanerEnv(const fs::path& base, bool fivemRunning = false) {
    CleanerEnv e;
    e.userProfile = base / "Users" / "tester";
    e.localAppData = e.userProfile / "AppData" / "Local";
    e.appData = e.userProfile / "AppData" / "Roaming";
    e.userTemp = e.localAppData / "Temp";
    e.winDir = base / "Windows";
    e.programData = base / "ProgramData";
    e.fivemAppDir = e.localAppData / "FiveM" / "FiveM.app";
    e.fivemRunning = [fivemRunning] { return fivemRunning; };
    e.tempMinAgeMinutes = 60;
    return e;
}

static const CleanCategory* byId(const std::vector<CleanCategory>& v, const std::string& id) {
    for (auto& c : v)
        if (c.id == id) return &c;
    return nullptr;
}

static void testCleaner() {
    fs::path base = fresh("cleaner");
    CleanerEnv env = cleanerEnv(base);
    JunkCleaner jc(env);

    // fixtures
    touch(env.userTemp / "old1.tmp", 1000, 300);
    touch(env.userTemp / "sub" / "old2.tmp", 2000, 300);
    touch(env.userTemp / "recent.tmp", 500, 1);               // too new: kept
    fs::path outside = base / "outside_important";
    touch(outside / "keep.txt", 4000, 999);
    std::error_code ec;
    fs::create_directory_symlink(outside, env.userTemp / "link_to_outside", ec);
    bool symlinkOk = !ec;
    touch(env.localAppData / "Microsoft/Windows/Explorer/thumbcache_96.db", 700);
    touch(env.localAppData / "Microsoft/Windows/Explorer/IconCache.db", 700);       // not matched by pattern: kept
    touch(env.localAppData / "Google/Chrome/User Data/Default/Cache/data_0", 900);
    touch(env.localAppData / "Google/Chrome/User Data/Default/Cookies", 100);        // never touched
    touch(env.localAppData / "Google/Chrome/User Data/Default/Login Data", 100);     // never touched
    touch(env.localAppData / "FiveM/FiveM.app/data/cache/x.bin", 3000);
    touch(env.localAppData / "FiveM/FiveM.app/data/server-cache/y.bin", 1000);
    touch(env.localAppData / "FiveM/FiveM.app/citizen/important.dll", 100);          // never touched
    touch(env.localAppData / "FiveM/FiveM.app/CitizenFX.ini", 10);                   // never touched
    touch(env.appData / "SomeApp/settings.json", 50);                                // never touched
    touch(env.userProfile / "Documents/thesis.docx", 50);                            // never touched

    auto cats = jc.categories();
    CHECK(byId(cats, "user_temp") && byId(cats, "fivem_cache") && byId(cats, "recycle_bin"));
    CHECK(byId(cats, "recycle_bin")->tier == Tier::Optional && !byId(cats, "recycle_bin")->selectedByDefault);

    // scan is an estimate and deletes nothing
    auto sc = jc.scan(*byId(cats, "user_temp"));
    CHECK(sc.available && sc.files == 2 && sc.bytes == 3000);
    CHECK(fs::exists(env.userTemp / "old1.tmp"));

    auto r = jc.clean(*byId(cats, "user_temp"));
    CHECK(r.deleted == 2 && r.bytesReclaimed == 3000);
    CHECK(!fs::exists(env.userTemp / "old1.tmp") && !fs::exists(env.userTemp / "sub"));
    CHECK(fs::exists(env.userTemp / "recent.tmp"));
    CHECK(r.skipped >= 1);
    CHECK(fs::exists(outside / "keep.txt"));  // symlink target untouched
    if (symlinkOk) CHECK(fs::is_symlink(env.userTemp / "link_to_outside"));
    CHECK(r.status == Status::Warning);

    r = jc.clean(*byId(cats, "thumbnails"));
    CHECK(r.deleted == 1 && fs::exists(env.localAppData / "Microsoft/Windows/Explorer/IconCache.db"));

    r = jc.clean(*byId(cats, "browser_cache"));
    CHECK(r.deleted == 1);
    CHECK(fs::exists(env.localAppData / "Google/Chrome/User Data/Default/Cookies"));
    CHECK(fs::exists(env.localAppData / "Google/Chrome/User Data/Default/Login Data"));

    r = jc.clean(*byId(cats, "fivem_cache"));
    CHECK(r.deleted == 2 && r.bytesReclaimed == 4000);
    CHECK(fs::exists(env.localAppData / "FiveM/FiveM.app/citizen/important.dll"));
    CHECK(fs::exists(env.localAppData / "FiveM/FiveM.app/CitizenFX.ini"));
    CHECK(fs::exists(env.appData / "SomeApp/settings.json"));
    CHECK(fs::exists(env.userProfile / "Documents/thesis.docx"));

    // nothing left: reported as already clean, not as success
    r = jc.clean(*byId(cats, "fivem_cache"));
    CHECK(r.status == Status::AlreadyOk && r.deleted == 0);

    // FiveM running -> skipped, nothing deleted
    touch(env.localAppData / "FiveM/FiveM.app/data/cache/z.bin", 10);
    JunkCleaner running(cleanerEnv(base, true));
    auto rc = running.clean(*byId(running.categories(), "fivem_cache"));
    CHECK(rc.status == Status::Skipped && fs::exists(env.localAppData / "FiveM/FiveM.app/data/cache/z.bin"));

    // cancellation
    for (int i = 0; i < 20; ++i) touch(env.userTemp / ("c" + std::to_string(i)), 10, 500);
    std::atomic<bool> cancel{true};
    auto rcx = jc.clean(*byId(cats, "user_temp"), {}, &cancel);
    CHECK(rcx.deleted == 0 && fs::exists(env.userTemp / "c0"));

    // root validation: dangerous roots are refused even if a category asks for them
    CHECK(!jc.isSafeRoot(base));                         // too shallow / ancestor of forbidden folders
    CHECK(!jc.isSafeRoot(env.userProfile));
    CHECK(!jc.isSafeRoot(env.localAppData));
    CHECK(!jc.isSafeRoot(env.appData));
    CHECK(!jc.isSafeRoot(env.userProfile / "Documents"));
    CHECK(!jc.isSafeRoot(env.userProfile / "Documents" / "sub"));
    CHECK(!jc.isSafeRoot(env.winDir));
    CHECK(!jc.isSafeRoot(fs::path("relative/path")));
    CHECK(!jc.isSafeRoot(fs::path("/")));
    CHECK(jc.isSafeRoot(env.userTemp));
    CleanCategory evil;
    evil.id = "evil";
    evil.targets.push_back({env.appData, "", true});
    auto re = jc.clean(evil);
    CHECK(re.deleted == 0 && fs::exists(env.appData / "SomeApp/settings.json") && re.status == Status::Skipped);
}

// ------------------------------------------------------------------ process reducer
class FakeProcs : public IProcessApi {
public:
    std::vector<ProcEntry> procs;
    std::set<uint32_t> unkillable;
    std::map<uint32_t, Prio> prio;
    std::vector<uint32_t> terminated;
    std::vector<ProcEntry> list() override { return procs; }
    bool requestClose(uint32_t) override { return true; }
    bool terminate(uint32_t pid, std::string& err) override {
        if (unkillable.count(pid)) { err = "access denied"; return false; }
        terminated.push_back(pid);
        procs.erase(std::remove_if(procs.begin(), procs.end(), [&](const ProcEntry& p) { return p.pid == pid; }), procs.end());
        return true;
    }
    bool setPriority(uint32_t pid, Prio p, std::string&) override { prio[pid] = p; return true; }
    bool launch(const std::string&, std::string&) override { return true; }
    uint32_t selfPid() override { return 1000; }
};

static ProcEntry P(uint32_t pid, const char* name, uint32_t parent = 1, bool mine = true, const char* path = nullptr, uint64_t ws = 1000) {
    ProcEntry e;
    e.pid = pid; e.parentPid = parent; e.name = name; e.ownedByUser = mine; e.workingSet = ws;
    e.path = path ? path : (std::string("C:\\Apps\\") + name);
    return e;
}

static void testReducer() {
    FakeProcs f;
    f.procs = {P(1000, "FiveMOptimizerPro.exe"), P(1001, "chrome.exe"), P(1002, "chrome.exe", 1001), P(1003, "discord.exe"),
               P(1004, "explorer.exe"), P(1005, "FiveM_b2802_GTAProcess.exe"), P(1006, "svchost.exe", 1, false),
               P(1007, "Notepad.exe"), P(1008, "csrss.exe"), P(1009, "MsMpEng.exe"), P(1010, "Launcher.exe"),
               P(1011, "someotheruser.exe", 1, false), P(1012, "steam.exe"), P(1013, "OneDrive.exe")};
    ReducerOptions known;
    known.keepNames = {"discord.exe"};
    auto t1 = selectTargets(f.procs, 1000, known);
    std::set<std::string> n1;
    for (auto& t : t1) n1.insert(t.name);
    CHECK(n1 == (std::set<std::string>{"chrome.exe", "OneDrive.exe"}));  // known apps only

    ReducerOptions mx = known;
    mx.maxMode = true;
    auto t2 = selectTargets(f.procs, 1000, mx);
    std::set<std::string> n2;
    for (auto& t : t2) n2.insert(t.name);
    CHECK(n2 == (std::set<std::string>{"chrome.exe", "Notepad.exe", "OneDrive.exe"}));
    // never: itself, other users/sessions, system-critical, security, game, launchers, kept apps
    for (const char* never : {"FiveMOptimizerPro.exe", "discord.exe", "explorer.exe", "FiveM_b2802_GTAProcess.exe", "svchost.exe",
                              "csrss.exe", "MsMpEng.exe", "Launcher.exe", "someotheruser.exe", "steam.exe"})
        CHECK(!n2.count(never));

    // only the top-level chrome.exe is relaunched on restore
    auto roots = relaunchRoots(t2);
    int chromeRoots = 0;
    for (auto& r : roots) chromeRoots += r.name == "chrome.exe";
    CHECK(chromeRoots == 1);

    // run it: verified closing, one process refuses to die
    f.unkillable.insert(1007);
    ReducerOptions run = mx;
    run.gracefulWaitMs = 100;
    auto out = reduceProcesses(f, run);
    CHECK(out.closed.size() == 3 && out.stillRunning.size() == 1 && out.stillRunning[0].name == "Notepad.exe");
    CHECK(f.prio[1005] == Prio::High);          // game raised
    CHECK(f.prio.count(1004) == 0);             // protected process priority untouched
    CHECK(f.prio[1007] == Prio::Idle);          // leftover background process lowered
}

static void testOptimizerMaxBoostProcessesBackup() {
    // MAX BOOST records closed applications in the backup so Restore can relaunch them
    FakeProcs f;
    f.procs = {P(1000, "FiveMOptimizerPro.exe"), P(1001, "chrome.exe", 1, true, "C:\\Program Files\\Chrome\\chrome.exe"),
               P(1002, "chrome.exe", 1001, true, "C:\\Program Files\\Chrome\\chrome.exe")};
    MemoryRegistry reg;
    BackupStore store(fresh("maxboost"));
    Optimizer opt(makeEnv(reg, store, &f));
    Options o = baseOpts();
    o.processes = ProcMode::Max;
    Report r = opt.run(o);
    CHECK(findResult(r, "procs", Status::Applied));
    auto sets = store.list();
    CHECK(sets.size() == 1);
    int procEntries = 0;
    for (auto& e : sets[0].entries) procEntries += e.kind == "proc";
    CHECK(procEntries == 1);
    Report rr = opt.restore(sets[0]);
    CHECK(rr.count(Status::Failed) == 0);
}

static void testServicesGuards() {
    for (auto& c : services::candidates()) CHECK(!services::isProtected(c.name));
    for (auto& c : services::aggressiveCandidates()) CHECK(!services::isProtected(c.name));
    CHECK(services::isProtected("WinDefend") && services::isProtected("mpssvc") && services::isProtected("wuauserv") &&
          services::isProtected("Dnscache") && services::isProtected("RpcSs"));
}

int main() {
    testUtil();
    testBackup();
    testPlan();
    testOptimizerAndRestore();
    testOptimizerFailures();
    testCleaner();
    testReducer();
    testOptimizerMaxBoostProcessesBackup();
    testServicesGuards();
    std::error_code ec;
    fs::remove_all(tmpRoot(), ec);
    std::cout << (g_checks - g_fail) << "/" << g_checks << " checks passed\n";
    return g_fail ? 1 : 0;
}
