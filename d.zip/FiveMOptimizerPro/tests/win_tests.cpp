// Windows-only integration checks: real registry, real process runner, real process API.
// Built only for Windows targets; also runs under Wine in CI-less environments.
#ifdef _WIN32
#include <iostream>
#include <thread>

#include "Optimizer.h"
#include "Platform.h"
#include "ProcessReducer.h"
#include "Registry.h"

#include <windows.h>

using namespace fmo;
static int g_fail = 0, g_checks = 0;
#define CHECK(c)                                                              \
    do {                                                                      \
        ++g_checks;                                                           \
        if (!(c)) {                                                           \
            ++g_fail;                                                         \
            std::cerr << "FAIL line " << __LINE__ << ": " #c << "\n";         \
        }                                                                     \
    } while (0)

int main() {
    auto reg = makeSystemRegistry();
    CHECK(reg->isReal());
    const char* key = "Software\\FmoTest\\Probe";
    std::string err;
    // missing -> NotFound
    CHECK(reg->read(Hive::HKCU, key, "A").state == RegRead::NotFound);
    // dword + string roundtrip, unicode value
    CHECK(reg->write(Hive::HKCU, key, "A", RegValue::dw(0x26), err));
    CHECK(reg->write(Hive::HKCU, key, "S", RegValue::sz("GpuPreference=2;"), err));
    CHECK(reg->write(Hive::HKCU, key, "C:\\Users\\x\\FiveM\\FiveM.exe", RegValue::sz("v"), err));
    CHECK(reg->read(Hive::HKCU, key, "A").value == RegValue::dw(0x26));
    CHECK(reg->read(Hive::HKCU, key, "S").value == RegValue::sz("GpuPreference=2;"));
    CHECK(reg->read(Hive::HKCU, key, "C:\\Users\\x\\FiveM\\FiveM.exe").state == RegRead::Found);
    // overwrite changes type
    CHECK(reg->write(Hive::HKCU, key, "A", RegValue::sz("0"), err));
    CHECK(reg->read(Hive::HKCU, key, "A").value == RegValue::sz("0"));
    CHECK(reg->removeValue(Hive::HKCU, key, "A", err));
    CHECK(reg->read(Hive::HKCU, key, "A").state == RegRead::NotFound);
    CHECK(reg->removeValue(Hive::HKCU, key, "A", err));  // idempotent
    CHECK(!reg->subKeys(Hive::HKCU, "Software\\FmoTest").empty());
    // cleanup test keys
    RegDeleteKeyW(HKEY_CURRENT_USER, L"Software\\FmoTest\\Probe");
    RegDeleteKeyW(HKEY_CURRENT_USER, L"Software\\FmoTest");

    // process runner: no shell, exit codes, output capture, argument quoting
    std::string cmd = systemTool("cmd.exe");
    ProcResult r = runProcess({cmd, "/c", "echo", "hello world"}, 10000);
    CHECK(r.started && r.exitCode == 0 && r.output.find("hello world") != std::string::npos);
    r = runProcess({cmd, "/c", "exit", "7"}, 10000);
    CHECK(r.started && r.exitCode == 7);
    r = runProcess({"C:\\definitely\\missing.exe"}, 2000);
    CHECK(!r.started);
    r = runProcess({cmd, "/c", "ping", "-n", "30", "127.0.0.1"}, 500);
    CHECK(r.timedOut);

    // system info
    SysInfo si = detectSystem(*reg);
    CHECK(si.windows && si.logicalCores > 0 && si.ramBytes > 0 && !si.arch.empty());
    std::cout << "OS: " << si.osName << " build " << si.build << " arch " << si.arch << " cores " << si.logicalCores << "\n";

    // real process API: spawn a child process, find it, close it, verify it is gone
    STARTUPINFOW sti{};
    sti.cb = sizeof sti;
    PROCESS_INFORMATION pi{};
    std::wstring cl = L"\"" + widen(systemTool("ping.exe")) + L"\" -n 60 127.0.0.1";
    BOOL spawned = CreateProcessW(nullptr, cl.data(), nullptr, nullptr, FALSE, CREATE_NO_WINDOW, nullptr, nullptr, &sti, &pi);
    CHECK(spawned);
    if (spawned) {
        auto api = makeSystemProcessApi();
        auto procs = api->list();
        bool found = false;
        for (auto& p : procs)
            if (p.pid == pi.dwProcessId) found = true;
        CHECK(found);
        std::string e2;
        CHECK(api->setPriority(pi.dwProcessId, Prio::Idle, e2));
        CHECK(api->terminate(pi.dwProcessId, e2));
        bool gone = true;
        for (auto& p : api->list())
            if (p.pid == pi.dwProcessId) gone = false;
        CHECK(gone);
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
    }
    CHECK(!runningProcessNames().empty());
    LoadSnapshot ls = sampleLoad(200);
    CHECK(ls.ramPercent > 0);

    // services: queries on a service that does not exist, and the protected guard
    auto st = services::query("FmoNoSuchService");
    CHECK(!st.installed);
    CHECK(!services::setStartType("WinDefend", 4, false, err));

    std::cout << (g_checks - g_fail) << "/" << g_checks << " windows checks passed\n";
    return g_fail ? 1 : 0;
}
#else
int main() { return 0; }
#endif
