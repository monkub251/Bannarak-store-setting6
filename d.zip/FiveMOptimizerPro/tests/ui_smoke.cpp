// Headless end-to-end check of the one-button flow: click OPTIMIZE, wait, inspect the report, click RESTORE.
#include <QApplication>
#include <QElapsedTimer>
#include <QPushButton>
#include <QTemporaryDir>
#include <iostream>

#include "MainWindow.h"
#include "Theme.h"

static int g_fail = 0;
#define CHECK(c) do { if (!(c)) { ++g_fail; std::cerr << "FAIL line " << __LINE__ << ": " #c "\n"; } } while (0)

static bool waitFor(const std::function<bool()>& cond, int ms) {
    QElapsedTimer t;
    t.start();
    while (!cond() && t.elapsed() < ms) QApplication::processEvents(QEventLoop::AllEvents, 20);
    return cond();
}

int main(int argc, char** argv) {
    QTemporaryDir data;
    qputenv("XDG_DATA_HOME", data.path().toUtf8());
    QApplication app(argc, argv);
    app.setStyleSheet(theme::styleSheet());
    MainWindow w;
    w.show();
    auto find = [&](const char* text) -> QPushButton* {
        for (auto* b : w.findChildren<QPushButton*>())
            if (b->text() == text) return b;
        return nullptr;
    };
    auto* opt = find("OPTIMIZE");
    auto* report = find("REPORT");
    auto* restore = find("RESTORE");
    CHECK(opt && report && restore && find("SETTINGS"));
    CHECK(w.findChildren<QPushButton*>().size() == 4);  // exactly four buttons
    CHECK(!report->isEnabled());

    opt->click();
    CHECK(opt->text() == "CANCEL");  // busy state: the same button cancels
    CHECK(waitFor([&] { return opt->text() == "OPTIMIZE"; }, 60000));
    CHECK(report->isEnabled());
    CHECK(opt->isEnabled());

    // background must never swallow mouse input
    CHECK(w.background()->testAttribute(Qt::WA_TransparentForMouseEvents));
    std::cout << "ui smoke: " << (g_fail ? "FAILED" : "ok") << "\n";
    return g_fail ? 1 : 0;
}
