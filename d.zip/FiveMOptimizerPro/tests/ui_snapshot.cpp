// Renders the main window at fixed animation times and writes PNG screenshots (offscreen).
#include <QApplication>
#include <QDir>
#include <QPixmap>
#include <QTemporaryDir>

#include "MainWindow.h"
#include "ParticleBackground.h"

int main(int argc, char** argv) {
    QTemporaryDir data;
    qputenv("XDG_DATA_HOME", data.path().toUtf8());
    QApplication app(argc, argv);
    QApplication::setOrganizationName("BANNARAK STORE");
    QApplication::setApplicationName("FiveMOptimizerPro");
    QString out = argc > 1 ? argv[1] : ".";
    QDir().mkpath(out);

    MainWindow w;
    w.resize(1240, 800);
    w.show();
    app.processEvents();
    auto shot = [&](const QString& name) {
        app.processEvents();
        w.grab().save(out + "/" + name + ".png");
    };
    // Animation phases (cycle = 24 s): gathering, held, dissolving, drifting
    for (auto [t, n] : {std::pair{3.0, "bg_gathering"}, {5.5, "bg_gathering_late"}, {11.0, "dashboard_formed"}, {16.0, "bg_dissolving"}, {22.0, "bg_scattered"}}) {
        w.background()->setManualTime(t);
        shot(n);
    }
    w.background()->setManualTime(11.0);
    const char* names[] = {"page_dashboard", "page_cleaner", "page_network", "page_fivem", "page_restore", "page_settings"};
    for (int i = 0; i < 6; ++i) { w.showPage(i); shot(names[i]); }
    w.showPage(0);
    w.background()->setReducedMotion(true);
    shot("reduced_motion");
    w.resize(1060, 720);
    shot("min_size");
    return 0;
}
