#pragma once
#include <QElapsedTimer>
#include <QImage>
#include <QPainterPath>
#include <QTimer>
#include <QWidget>
#include <vector>

// Animated background layer.
//
// Cycle (26 s, seamless): fine white dust drifts in the dark -> curves in and gathers into the outline of the
// BANNARAK mark and wordmark -> the real chrome logo materialises out of the dust and a slow light sweep
// travels across the metal -> the logo dissolves back into dust. Particle positions are a closed-form function
// of time (no integration state), so the loop has no reset, resizing is free and pause/resume cannot jump.
// The widget never accepts mouse input and sits behind the functional interface.
class ParticleBackground : public QWidget {
    Q_OBJECT
public:
    explicit ParticleBackground(QWidget* parent = nullptr);

    void setReducedMotion(bool on);  // static, fully formed logo; timer stopped
    bool reducedMotion() const { return reduced_; }
    void setFormationRect(const QRectF& r);  // area (widget coordinates) the logo and wordmark fit into
    void setParticleCount(int n);
    void setManualTime(double seconds);  // screenshots/tests; negative = real clock
    static double cycleSeconds() { return 26.0; }

    // Renders one frame at time t (used by the snapshot tool).
    QImage renderFrame(double t, const QSize& size);

protected:
    void paintEvent(QPaintEvent*) override;
    void showEvent(QShowEvent*) override;
    void hideEvent(QHideEvent*) override;

private:
    struct Particle {
        float tx, ty;          // formation target in canvas space (0..1)
        float sx, sy;          // scatter anchor in widget space (0..1)
        float ph1, ph2, f1, f2;
        float delay;           // 0..1, staggers the gather
        float swirl;           // curvature of the travel path
        float bright;          // 0..1
        float size;
        bool detail;           // keeps breathing while the shape holds
        bool ambient;          // never forms, just drifts
    };
    void buildTargets();
    void rebuildParticles();
    void applyTimerState();
    void paintFrame(QPainter& p, const QSize& size, double t) const;
    double now() const;

    QImage canvas_;                 // mark + wordmark composite (target sampling only)
    QImage logoImg_;                // original chrome logo
    QRectF logoRect_;               // logo position in canvas space
    QPainterPath wordPath_;         // wordmark outline in canvas space
    std::vector<std::pair<QPointF, float>> samples_;
    std::vector<Particle> parts_;
    mutable QImage logoScaled_;     // cache, rebuilt on size change
    mutable QSize logoScaledSize_;
    // Static layers are rendered once per size (full-window gradients are the expensive part of a frame).
    mutable QPixmap baseCache_, vignetteCache_, beamCache_, haloCache_;
    mutable QSize cacheSize_;
    mutable QPointF haloCenter_;
    mutable float haloRadius_ = -1.f;
    void ensureCaches(const QSize& size, const QPointF& logoCenter, float haloRadius) const;
    QTimer timer_;
    QElapsedTimer clock_;
    bool reduced_ = false;
    bool paused_ = false;
    QRectF rect_;
    bool hasRect_ = false;
    int count_ = 3400;
    double manual_ = -1;
    double pausedTotal_ = 0;
    qint64 pauseStartMs_ = 0;
};
