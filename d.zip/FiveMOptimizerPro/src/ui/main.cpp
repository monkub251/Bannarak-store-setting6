#include <QApplication>

#include "MainWindow.h"
#include "Theme.h"

int main(int argc, char** argv) {
    QApplication app(argc, argv);
    QApplication::setApplicationName("FiveM Optimizer PRO");
    QApplication::setOrganizationName("BANNARAK");
    app.setStyleSheet(theme::styleSheet());
    MainWindow w;
    w.show();
    return app.exec();
}
