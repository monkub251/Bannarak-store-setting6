#include "MainWindow.h"

#include <QApplication>
#include <QCheckBox>
#include <QComboBox>
#include <QDialog>
#include <QDialogButtonBox>
#include <QFileDialog>
#include <QFormLayout>
#include <QHBoxLayout>
#include <QHeaderView>
#include <QLabel>
#include <QLineEdit>
#include <QMessageBox>
#include <QProgressBar>
#include <QPushButton>
#include <QRegularExpression>
#include <QStackedLayout>
#include <QStandardPaths>
#include <QThread>
#include <QTimer>
#include <QTreeWidget>
#include <QVBoxLayout>

#include "Log.h"
#include "Theme.h"

using namespace fmo;

namespace {
QString q(const std::string& s) { return QString::fromUtf8(s.c_str()); }

QString glyph(Status s) {
    switch (s) {
        case Status::Applied: return QStringLiteral("✓ APPLIED");
        case Status::AlreadyOk: return QStringLiteral("= OK");
        case Status::Skipped: return QStringLiteral("– SKIPPED");
        case Status::Warning: return QStringLiteral("! WARNING");
        case Status::Failed: return QStringLiteral("✕ FAILED");
    }
    return {};
}
}  // namespace

// ============================================================================ construction
MainWindow::MainWindow(const CleanerEnv* cleanerOverride, QWidget* parent)
    : QMainWindow(parent), settings_("BANNARAK", "FiveMOptimizerPro") {
    setWindowTitle("BANNARAK STORE — FiveM Optimizer PRO");
    setWindowIcon(QIcon(":/logo_mark.png"));
    setMinimumSize(900, 640);
    resize(1180, 760);

    reg_ = makeSystemRegistry();
    procs_ = makeSystemProcessApi();
    QString data = QStandardPaths::writableLocation(QStandardPaths::AppLocalDataLocation);
    if (data.isEmpty()) data = QDir::homePath() + "/.fivem-optimizer-pro";
    fs::path root = pathFromUtf8(data.toUtf8().toStdString());
    store_ = std::make_unique<BackupStore>(root / "backups");
    Logger::instance().setFile(root / "logs" / "optimizer.log");
    sys_ = detectSystem(*reg_);
    cleanerEnv_ = cleanerOverride ? *cleanerOverride : CleanerEnv::fromSystem();
    fivem_ = detectFiveM(cleanerEnv_.localAppData);

    // layer 0: animated background (full bleed). layer 1: the four buttons and a status line.
    auto* rootW = new QWidget;
    rootW->setObjectName("root");
    setCentralWidget(rootW);
    auto* layers = new QStackedLayout(rootW);
    layers->setStackingMode(QStackedLayout::StackAll);
    layers->setContentsMargins(0, 0, 0, 0);
    bg_ = new ParticleBackground;
    layers->addWidget(bg_);

    auto* content = new QWidget;
    content->setObjectName("content");
    auto* v = new QVBoxLayout(content);
    v->setContentsMargins(22, 18, 22, 20);
    v->setSpacing(0);

    // Static corner logo: simplified, non-animated brand mark (separate from the animated background).
    auto* top = new QHBoxLayout;
    auto* logo = new QLabel;
    logo->setObjectName("cornerLogo");
    logo->setFixedSize(48, 48);
    logo->setPixmap(QPixmap(":/logo_mark.png").scaled(48, 48, Qt::KeepAspectRatio, Qt::SmoothTransformation));
    auto* brand = new QLabel("BANNARAK STORE\nFIVEM OPTIMIZER PRO");
    brand->setObjectName("brandSmall");
    top->addWidget(logo);
    top->addSpacing(10);
    top->addWidget(brand);
    top->addStretch();
    v->addLayout(top);

    formationHost_ = new QWidget;
    formationHost_->setAttribute(Qt::WA_TransparentForMouseEvents);
    v->addWidget(formationHost_, 1);

    statusLabel_ = new QLabel("Ready");
    statusLabel_->setObjectName("status");
    statusLabel_->setAlignment(Qt::AlignCenter);
    statusLabel_->setWordWrap(true);
    v->addWidget(statusLabel_);
    v->addSpacing(8);
    progress_ = new QProgressBar;
    progress_->setRange(0, 100);
    progress_->setFixedSize(380, 3);
    progress_->setTextVisible(false);
    progress_->setValue(0);
    auto* pr = new QHBoxLayout;
    pr->addStretch();
    pr->addWidget(progress_);
    pr->addStretch();
    v->addLayout(pr);
    v->addSpacing(18);

    auto* row = new QHBoxLayout;
    row->setSpacing(14);
    restoreBtn_ = new QPushButton("RESTORE");
    optimizeBtn_ = new QPushButton("OPTIMIZE");
    settingsBtn_ = new QPushButton("SETTINGS");
    reportBtn_ = new QPushButton("REPORT");
    optimizeBtn_->setObjectName("primary");
    for (auto* b : {restoreBtn_, settingsBtn_, reportBtn_}) b->setObjectName("ghost");
    for (auto* b : {restoreBtn_, optimizeBtn_, settingsBtn_, reportBtn_}) b->setCursor(Qt::PointingHandCursor);
    reportBtn_->setEnabled(false);
    optimizeBtn_->setToolTip("Everything in one click: backup, registry/policy, power plan, DNS, services, close background "
                             "processes, junk cleaning, then a verified report.");
    restoreBtn_->setToolTip("Undo every change made by OPTIMIZE (verified, newest first).");
    row->addStretch();
    row->addWidget(restoreBtn_);
    row->addWidget(optimizeBtn_);
    row->addWidget(settingsBtn_);
    row->addWidget(reportBtn_);
    row->addStretch();
    v->addLayout(row);
    v->addSpacing(10);
    adminLabel_ = new QLabel;
    adminLabel_->setObjectName("brandSmall");
    adminLabel_->setAlignment(Qt::AlignCenter);
    v->addWidget(adminLabel_);

    layers->addWidget(content);
    layers->setCurrentWidget(content);

    connect(optimizeBtn_, &QPushButton::clicked, this, [this] {
        if (busy_) { cancel_ = true; statusLabel_->setText("Cancelling after the current step..."); }
        else startOptimize();
    });
    connect(restoreBtn_, &QPushButton::clicked, this, [this] { startRestore(); });
    connect(settingsBtn_, &QPushButton::clicked, this, [this] { showSettings(); });
    connect(reportBtn_, &QPushButton::clicked, this, [this] { showReportDialog(); });

    loadPrefs();
    applyPrefs();
    adminLabel_->setText(!sys_.windows ? "DEVELOPMENT BUILD (NOT WINDOWS)"
                         : sys_.elevated ? "ADMINISTRATOR" : "STANDARD USER — SOME TWEAKS WILL BE SKIPPED");
}

MainWindow::~MainWindow() {
    cancel_ = true;
    if (worker_) worker_->wait();
}

void MainWindow::resizeEvent(QResizeEvent* e) {
    QMainWindow::resizeEvent(e);
    QTimer::singleShot(0, this, [this] { updateFormation(); });
}
void MainWindow::showEvent(QShowEvent* e) {
    QMainWindow::showEvent(e);
    QTimer::singleShot(0, this, [this] { updateFormation(); });
}

void MainWindow::updateFormation() {
    if (!formationHost_) return;
    QPoint tl = formationHost_->mapTo(centralWidget(), QPoint(0, 0));
    QRectF r(tl, formationHost_->size());
    // the logo may use the full width and extends slightly above the host so it stays large on small windows
    r.setLeft(0);
    r.setRight(bg_->width());
    r.setTop(std::max(0.0, r.top() - 12));
    bg_->setFormationRect(r);
}

// ============================================================================ preferences
void MainWindow::loadPrefs() {
    prefs_.reduced = settings_.value("reducedMotion", false).toBool();
    prefs_.quality = settings_.value("quality", 1).toInt();
    prefs_.impact = settings_.value("profileImpact", true).toBool();
    prefs_.flow = settings_.value("profileFlow", true).toBool();
    prefs_.askBeforeClosing = settings_.value("askClose", true).toBool();
    prefs_.pointerOff = settings_.value("pointerOff", false).toBool();
    prefs_.keep = settings_.value("keep", "discord.exe").toString();
}

void MainWindow::savePrefs() {
    settings_.setValue("reducedMotion", prefs_.reduced);
    settings_.setValue("quality", prefs_.quality);
    settings_.setValue("profileImpact", prefs_.impact);
    settings_.setValue("profileFlow", prefs_.flow);
    settings_.setValue("askClose", prefs_.askBeforeClosing);
    settings_.setValue("pointerOff", prefs_.pointerOff);
    settings_.setValue("keep", prefs_.keep);
}

void MainWindow::applyPrefs() {
    bg_->setReducedMotion(prefs_.reduced);
    bg_->setParticleCount(prefs_.quality == 0 ? 1800 : prefs_.quality == 1 ? 3400 : 5200);
}

void MainWindow::showSettings() {
    QDialog d(this);
    d.setWindowTitle("Settings");
    d.setMinimumWidth(460);
    auto* f = new QFormLayout(&d);
    f->setContentsMargins(22, 20, 22, 18);
    f->setVerticalSpacing(12);

    auto* reduced = new QCheckBox("Reduced motion (static logo)");
    reduced->setChecked(prefs_.reduced);
    auto* quality = new QComboBox;
    quality->addItems({"Low", "Medium", "High"});
    quality->setCurrentIndex(prefs_.quality);
    auto* impact = new QCheckBox("VANTA IMPACT — melee / impact feel");
    impact->setChecked(prefs_.impact);
    auto* flow = new QCheckBox("ONYX FLOW — knife / movement / emote feel");
    flow->setChecked(prefs_.flow);
    auto* ask = new QCheckBox("Ask before closing background programs");
    ask->setChecked(prefs_.askBeforeClosing);
    auto* pointer = new QCheckBox("Also disable mouse acceleration (changes mouse feel)");
    pointer->setChecked(prefs_.pointerOff);
    auto* keep = new QLineEdit(prefs_.keep);
    keep->setPlaceholderText("discord.exe, obs64.exe");
    keep->setToolTip("Programs OPTIMIZE never closes, separated by commas.");

    f->addRow(reduced);
    f->addRow("Particle quality", quality);
    f->addRow(impact);
    f->addRow(flow);
    f->addRow(pointer);
    f->addRow(ask);
    f->addRow("Never close", keep);
    auto* note = new QLabel("OPTIMIZE always applies every reduction. System-critical processes, the game, its launchers and the "
                            "programs above are never closed, because that crashes Windows or the game.");
    note->setObjectName("note");
    note->setWordWrap(true);
    f->addRow(note);
    auto* bb = new QDialogButtonBox(QDialogButtonBox::Save | QDialogButtonBox::Cancel);
    f->addRow(bb);
    connect(bb, &QDialogButtonBox::accepted, &d, &QDialog::accept);
    connect(bb, &QDialogButtonBox::rejected, &d, &QDialog::reject);
    if (d.exec() != QDialog::Accepted) return;
    prefs_.reduced = reduced->isChecked();
    prefs_.quality = quality->currentIndex();
    prefs_.impact = impact->isChecked();
    prefs_.flow = flow->isChecked();
    prefs_.pointerOff = pointer->isChecked();
    prefs_.askBeforeClosing = ask->isChecked();
    prefs_.keep = keep->text();
    savePrefs();
    applyPrefs();
}

// ============================================================================ engine plumbing
Options MainWindow::currentOptions() const {
    Options o = Options::maxBoost();  // one button = every reduction
    o.profiles = (prefs_.impact ? ProfileImpact : 0) | (prefs_.flow ? ProfileFlow : 0);
    o.cleanJunk = true;
    o.powerPlan = true;
    o.applyFastestDns = true;  // only switches when measurably faster; verified and reversible
    o.pointerPrecisionOff = prefs_.pointerOff;
    o.keepProcesses.clear();
    for (const auto& part : prefs_.keep.split(QRegularExpression("[,;\\s]+"), Qt::SkipEmptyParts))
        o.keepProcesses.insert(part.trimmed().toLower().toStdString());
    return o;
}

Env MainWindow::makeEnv() {
    Env e;
    e.reg = reg_.get();
    e.store = store_.get();
    e.procs = procs_.get();
    sys_ = detectSystem(*reg_);
    e.sys = sys_;
    e.fivem = fivem_;
    e.cleaner = cleanerEnv_;
    return e;
}

void MainWindow::post(std::function<void()> fn) { QMetaObject::invokeMethod(this, std::move(fn), Qt::QueuedConnection); }

void MainWindow::runAsync(std::function<void()> work, std::function<void()> done) {
    auto* t = QThread::create(std::move(work));
    worker_ = t;
    connect(t, &QThread::finished, this, [this, t, done = std::move(done)] {
        worker_ = nullptr;
        done();
        t->deleteLater();
    });
    t->start();
}

void MainWindow::setBusy(bool busy, const QString& optimizeText) {
    busy_ = busy;
    optimizeBtn_->setText(busy ? "CANCEL" : optimizeText);
    restoreBtn_->setEnabled(!busy);
    settingsBtn_->setEnabled(!busy);
    reportBtn_->setEnabled(!busy && !lastReport_.items.empty());
    if (!busy) progress_->setValue(0);
}

// ============================================================================ OPTIMIZE
void MainWindow::startOptimize() {
    if (busy_) return;
    Options o = currentOptions();

    if (prefs_.askBeforeClosing) {
        ReducerOptions ro;
        ro.maxMode = true;
        for (auto& k : o.keepProcesses) ro.keepNames.insert(k);
        auto targets = selectTargets(procs_->list(), procs_->selfPid(), ro);
        if (!targets.empty()) {
            std::set<std::string> names;
            for (auto& t : targets) names.insert(t.name);
            QString list;
            int n = 0;
            for (auto& s : names)
                if (n++ < 12) list += "• " + q(s) + "\n";
            if (names.size() > 12) list += QString("… and %1 more\n").arg(names.size() - 12);
            QMessageBox box(this);
            box.setWindowTitle("Close background programs");
            box.setText(QString("OPTIMIZE will close %1 background programs. Unsaved work in them will be lost.\n\n%2").arg(names.size()).arg(list));
            auto* again = new QCheckBox("Don't ask again");
            box.setCheckBox(again);
            box.setStandardButtons(QMessageBox::Ok | QMessageBox::Cancel);
            box.setDefaultButton(QMessageBox::Ok);
            int r = box.exec();
            if (again->isChecked()) { prefs_.askBeforeClosing = false; savePrefs(); }
            if (r != QMessageBox::Ok) return;
        }
    }

    cancel_ = false;
    setBusy(true);
    statusLabel_->setText("Starting...");
    auto env = std::make_shared<Env>(makeEnv());
    auto report = std::make_shared<Report>();
    runAsync(
        [this, env, o, report] {
            Callbacks cb;
            cb.cancel = &cancel_;
            cb.progress = [this](int pct, const std::string& msg) {
                post([this, pct, m = q(msg)] {
                    progress_->setValue(pct);
                    statusLabel_->setText(m + "...");
                });
            };
            Optimizer opt(*env);
            *report = opt.run(o, cb);
        },
        [this, report] {
            setBusy(false);
            finishReport(*report, "Optimization");
            if (report->restartRecommended && sys_.windows) {
                auto r = QMessageBox::question(this, "Restart recommended",
                                               "Some changes take full effect after a restart or sign-out.\nRestart Windows now? (30 seconds to cancel with 'shutdown /a')");
                if (r == QMessageBox::Yes) {
                    std::string err;
                    if (!scheduleRestart(30, err)) QMessageBox::warning(this, "Restart", q("Could not schedule the restart: " + err));
                }
            }
        });
}

void MainWindow::finishReport(const Report& r, const QString& what) {
    lastReport_ = r;
    reportBtn_->setEnabled(true);
    int applied = r.count(Status::Applied), bad = r.count(Status::Failed), warn = r.count(Status::Warning);
    QString s = QString("%1 finished — %2 applied").arg(what).arg(applied);
    if (warn) s += QString(" · %1 need attention").arg(warn);
    if (bad) s += QString(" · %1 failed").arg(bad);
    if (!r.measurements.empty()) s += "\n" + q(r.measurements.front());
    statusLabel_->setText(s);
    progress_->setValue(100);
}

// ============================================================================ RESTORE
void MainWindow::startRestore() {
    if (busy_) return;
    auto sets = std::make_shared<std::vector<BackupSet>>();
    for (auto& s : store_->list())
        if (!s.restored) sets->push_back(s);  // list() is newest first, which is the correct undo order
    if (sets->empty()) {
        statusLabel_->setText("Nothing to restore — no unrestored backups exist.");
        return;
    }
    auto r = QMessageBox::question(this, "Restore",
                                   QString("Undo all %1 optimization run(s)?\nSettings, services, power plan and DNS return to their original state. "
                                           "Closed programs are started again (unsaved data cannot be recovered).")
                                       .arg(sets->size()));
    if (r != QMessageBox::Yes) return;
    cancel_ = false;
    setBusy(true);
    statusLabel_->setText("Restoring...");
    progress_->setRange(0, 0);
    auto env = std::make_shared<Env>(makeEnv());
    auto report = std::make_shared<Report>();
    runAsync(
        [env, sets, report] {
            Optimizer opt(*env);
            for (const auto& s : *sets) {
                Report one = opt.restore(s);
                for (auto& i : one.items) report->items.push_back(i);
            }
        },
        [this, report] {
            progress_->setRange(0, 100);
            setBusy(false);
            finishReport(*report, "Restore");
        });
}

// ============================================================================ REPORT
void MainWindow::showReportDialog() {
    QDialog d(this);
    d.setWindowTitle("Report");
    d.resize(960, 560);
    auto* v = new QVBoxLayout(&d);
    v->setContentsMargins(18, 16, 18, 14);
    auto* summary = new QLabel;
    summary->setObjectName("value");
    summary->setWordWrap(true);
    v->addWidget(summary);
    auto* tree = new QTreeWidget;
    tree->setColumnCount(4);
    tree->setHeaderLabels({"STATUS", "AREA", "ITEM", "DETAIL"});
    tree->setRootIsDecorated(false);
    tree->setAlternatingRowColors(true);
    tree->header()->setSectionResizeMode(0, QHeaderView::ResizeToContents);
    tree->header()->setSectionResizeMode(1, QHeaderView::ResizeToContents);
    tree->setColumnWidth(2, 260);
    tree->header()->setStretchLastSection(true);
    v->addWidget(tree, 1);

    const Report& r = lastReport_;
    for (const auto& i : r.items) {
        auto* it = new QTreeWidgetItem(tree);
        it->setText(0, glyph(i.status));
        it->setText(1, q(i.category));
        it->setText(2, q(i.title));
        it->setText(3, q(i.detail));
        it->setToolTip(3, q(i.detail));
        if (i.status == Status::Failed || i.status == Status::Warning) {
            QFont f = it->font(0);
            f.setBold(true);
            for (int c = 0; c < 4; ++c) it->setFont(c, f);
        }
        if (i.status == Status::Skipped || i.status == Status::AlreadyOk)
            for (int c = 0; c < 4; ++c) it->setForeground(c, QColor(140, 140, 140));
    }
    QString s = r.items.empty() ? "No report yet. Press OPTIMIZE."
                                : QString("Applied %1 · Already OK %2 · Skipped %3 · Warnings %4 · Failed %5")
                                      .arg(r.count(Status::Applied)).arg(r.count(Status::AlreadyOk)).arg(r.count(Status::Skipped))
                                      .arg(r.count(Status::Warning)).arg(r.count(Status::Failed));
    for (const auto& m : r.measurements) s += "\n" + q(m);
    summary->setText(s);

    auto* bb = new QDialogButtonBox;
    auto* exp = bb->addButton("Export...", QDialogButtonBox::ActionRole);
    bb->addButton(QDialogButtonBox::Close);
    v->addWidget(bb);
    connect(bb, &QDialogButtonBox::rejected, &d, &QDialog::reject);
    connect(exp, &QPushButton::clicked, &d, [this, &d] {
        QString path = QFileDialog::getSaveFileName(&d, "Export report", "FiveM-Optimizer-report.txt", "Text (*.txt)");
        if (path.isEmpty()) return;
        QFile f(path);
        if (f.open(QIODevice::WriteOnly | QIODevice::Text)) f.write(q(renderReport(lastReport_)).toUtf8());
    });
    d.exec();
}

void MainWindow::setDemoReport() {
    Report r;
    r.backupId = "20261019-070000";
    r.add("Backup", "bk", "Backup created", Status::Applied, "11 original settings saved and read back successfully.");
    r.add("Registry", "gamemode", "Windows Game Mode on", Status::Applied, "Verified (CORE).");
    r.add("Registry", "sysresp", "Multimedia scheduler responsiveness 10%", Status::Applied, "Verified (VANTA IMPACT + ONYX FLOW).");
    r.add("Registry", "gamedvr_store", "Game DVR flag off", Status::AlreadyOk, "Already set.");
    r.add("Policy", "policy_gamedvr", "Policy: Game recording and broadcasting off", Status::Skipped, "Windows Home does not support Group Policy.");
    r.add("Processes", "procs", "Background processes", Status::Applied, "41 of 41 processes closed (verified).");
    r.add("Services", "SysMain", "SysMain (Superfetch)", Status::Warning, "Set to Disabled but the service is still running.");
    r.add("Cleanup", "user_temp", "User temporary files", Status::Applied, "scanned 812, deleted 790, skipped 22, failed 0, reclaimed 1.84 GB (measured)");
    r.measurements = {"Free RAM (measured): 9.80 GB -> 11.62 GB", "Running processes (measured): 214 -> 167"};
    finishReport(r, "Optimization");
}
