// Developer tool: renders the real MainWindow to PNG files so the design can be reviewed without a display.
// Usage: ui_snapshot <output-dir>   (set QT_QPA_PLATFORM=offscreen)
#include <filesystem>
#include <QApplication>
#include <QDir>
#include <QElapsedTimer>
#include <cstdio>
#include <QTimer>

#include "MainWindow.h"
#include "Theme.h"

int main(int argc, char** argv) {
    QApplication app(argc, argv);
    app.setStyleSheet(theme::styleSheet());
    QString out = argc > 1 ? argv[1] : ".";
    QDir().mkpath(out);

    if (argc > 2 && QString(argv[2]) == "bench") {  // frame-cost benchmark (software rasteriser = worst case)
        ParticleBackground bg;
        bg.setFormationRect(QRectF(0, 20, 1180, 520));
        for (double t0 : {5.0, 13.0, 20.0}) {
            QElapsedTimer tm;
            tm.start();
            for (int i = 0; i < 30; ++i) bg.renderFrame(t0 + i * 0.033, QSize(1180, 760));
            std::printf("t=%.0f: %.1f ms/frame\n", t0, tm.elapsed() / 30.0);
        }
        return 0;
    }
    MainWindow w;
    w.resize(1180, 760);
    w.show();
    for (int i = 0; i < 4; ++i) QApplication::processEvents();

    // cycle = 26 s: scattered 0, gathering 5, outline formed 8.5, solid+sweep 11.5/13, dissolving 18, dust 24
    struct Shot { double t; const char* name; };
    const Shot shots[] = {{0.5, "1_dust"}, {5.0, "2_gathering"}, {8.6, "3_outline"}, {11.0, "4_solid"},
                          {13.0, "5_sweep"}, {17.5, "6_dissolve"}};
    for (const auto& s : shots) {
        w.background()->setManualTime(s.t);
        for (int i = 0; i < 3; ++i) QApplication::processEvents();
        w.grab().save(out + "/" + s.name + ".png");
    }
    w.background()->setManualTime(13.0);
    w.setDemoReport();
    for (int i = 0; i < 3; ++i) QApplication::processEvents();
    w.grab().save(out + "/7_after_run.png");

    for (int which = 0; which < 2; ++which) {  // modal dialogs: grab from a timer, then close
        QTimer::singleShot(400, [&out, which] {
            if (auto* d = QApplication::activeModalWidget()) {
                d->grab().save(out + (which == 0 ? "/10_settings.png" : "/11_report.png"));
                d->close();
            }
        });
        if (which == 0) w.showSettings(); else w.showReportDialog();
    }
    w.background()->setReducedMotion(true);
    for (int i = 0; i < 3; ++i) QApplication::processEvents();
    w.grab().save(out + "/8_reduced_motion.png");
    w.background()->setReducedMotion(false);
    w.background()->setManualTime(13.0);
    w.resize(900, 640);
    for (int i = 0; i < 4; ++i) QApplication::processEvents();
    w.grab().save(out + "/9_min_size.png");
    return 0;
}
