#pragma once
#include <QString>

namespace theme {

// Strict monochrome: black, charcoal, silver, white. Status is conveyed by glyphs and weight, not hue.
inline QString styleSheet() {
    return R"(
* { font-family: "Segoe UI", "Inter", "DejaVu Sans", sans-serif; font-size: 13px; color: #e6e6e6; }
QWidget#root { background: #030304; }
QWidget#content { background: transparent; }
QDialog, QMessageBox { background: #0a0a0b; }

QLabel#brandSmall { color: #8d8d8d; font-size: 10px; letter-spacing: 3px; }
QLabel#status { color: #cfcfcf; font-size: 13px; letter-spacing: 1px; }
QLabel#value { color: #f2f2f2; }
QLabel#note { color: #8d8d8d; font-size: 11px; }

QPushButton { background: rgba(255,255,255,12); border: 1px solid #3a3a3a; border-radius: 3px; padding: 8px 16px; letter-spacing: 1px; }
QPushButton:hover { background: rgba(255,255,255,26); border-color: #6a6a6a; }
QPushButton:pressed { background: rgba(255,255,255,40); }
QPushButton:disabled { color: #5a5a5a; border-color: #262626; background: rgba(255,255,255,5); }

QPushButton#primary { min-width: 260px; background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #f6f6f6, stop:0.5 #cdcdcd, stop:1 #8c8c8c);
    color: #050505; font-size: 16px; font-weight: 700; letter-spacing: 7px; border: 1px solid #ffffff; border-radius: 2px; padding: 16px 40px; }
QPushButton#primary:hover { background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 #ffffff, stop:0.5 #e4e4e4, stop:1 #a6a6a6); }
QPushButton#primary:disabled { background: #2a2a2a; color: #666666; border-color: #333333; }
QPushButton#ghost { background: rgba(5,5,5,150); color: #e8e8e8; font-size: 11px; font-weight: 600; letter-spacing: 4px;
    border: 1px solid #5a5a5a; border-radius: 2px; padding: 15px 22px; min-width: 96px; }
QPushButton#ghost:hover { background: rgba(255,255,255,26); border-color: #d0d0d0; }
QPushButton#ghost:disabled { color: #4a4a4a; border-color: #262626; }

QCheckBox { spacing: 10px; }
QCheckBox::indicator { width: 15px; height: 15px; border: 1px solid #6a6a6a; border-radius: 2px; background: #0b0b0b; }
QCheckBox::indicator:checked { background: #e8e8e8; border-color: #ffffff; }

QProgressBar { background: #141414; border: none; border-radius: 1px; }
QProgressBar::chunk { background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #6a6a6a, stop:1 #ffffff); }

QTreeWidget { background: rgba(6,6,6,230); border: 1px solid #262626; border-radius: 3px; alternate-background-color: rgba(255,255,255,6);
    selection-background-color: rgba(255,255,255,40); }
QHeaderView::section { background: #0c0c0c; color: #9a9a9a; border: none; border-bottom: 1px solid #2a2a2a; padding: 6px 8px; letter-spacing: 1px; font-size: 11px; }
QComboBox, QLineEdit { background: #0b0b0b; border: 1px solid #3a3a3a; border-radius: 3px; padding: 6px 10px; }
QComboBox QAbstractItemView { background: #0b0b0b; selection-background-color: #2a2a2a; }
QScrollBar:vertical { background: transparent; width: 10px; }
QScrollBar::handle:vertical { background: #3a3a3a; border-radius: 4px; min-height: 24px; }
QScrollBar::add-line, QScrollBar::sub-line { height: 0; width: 0; }
QToolTip { background: #101010; color: #e6e6e6; border: 1px solid #3a3a3a; }
)";
}

}  // namespace theme
