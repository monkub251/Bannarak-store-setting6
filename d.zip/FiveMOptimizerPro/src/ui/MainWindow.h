#pragma once
#include <QMainWindow>
#include <QSettings>
#include <atomic>
#include <functional>
#include <memory>

#include "JunkCleaner.h"
#include "Optimizer.h"
#include "ParticleBackground.h"

class QLabel;
class QProgressBar;
class QPushButton;
class QThread;

// Four buttons only: OPTIMIZE (everything in one click), RESTORE, SETTINGS, REPORT.
class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    // `cleanerOverride` lets the snapshot tool point the cleaner at demo folders.
    explicit MainWindow(const fmo::CleanerEnv* cleanerOverride = nullptr, QWidget* parent = nullptr);
    ~MainWindow() override;

    ParticleBackground* background() { return bg_; }
    void showSettings();
    void showReportDialog();
    void setDemoReport();  // snapshot tool only

protected:
    void resizeEvent(QResizeEvent*) override;
    void showEvent(QShowEvent*) override;

private:
    struct Prefs {
        bool reduced = false;
        int quality = 1;  // 0 low, 1 medium, 2 high
        bool impact = true, flow = true;
        bool askBeforeClosing = true;
        bool pointerOff = false;
        QString keep = "discord.exe";
    };

    void loadPrefs();
    void savePrefs();
    void applyPrefs();
    void updateFormation();
    fmo::Env makeEnv();
    fmo::Options currentOptions() const;
    void runAsync(std::function<void()> work, std::function<void()> done);
    void post(std::function<void()> fn);
    void setBusy(bool busy, const QString& optimizeText = "OPTIMIZE");
    void startOptimize();
    void startRestore();
    void finishReport(const fmo::Report& r, const QString& what);

    std::unique_ptr<fmo::IRegistry> reg_;
    std::unique_ptr<fmo::BackupStore> store_;
    std::unique_ptr<fmo::IProcessApi> procs_;
    fmo::CleanerEnv cleanerEnv_;
    fmo::SysInfo sys_;
    fmo::FiveMInfo fivem_;
    std::atomic<bool> cancel_{false};
    bool busy_ = false;
    QThread* worker_ = nullptr;
    fmo::Report lastReport_;
    QSettings settings_;
    Prefs prefs_;

    ParticleBackground* bg_ = nullptr;
    QWidget* formationHost_ = nullptr;  // empty stretch area the logo is fitted into
    QPushButton *optimizeBtn_ = nullptr, *restoreBtn_ = nullptr, *settingsBtn_ = nullptr, *reportBtn_ = nullptr;
    QLabel *statusLabel_ = nullptr, *adminLabel_ = nullptr;
    QProgressBar* progress_ = nullptr;
};
