#include "ParticleBackground.h"

#include <QGuiApplication>
#include <QLinearGradient>
#include <QPainter>
#include <QRadialGradient>
#include <QRandomGenerator>
#include <QTransform>
#include <algorithm>
#include <cmath>

namespace {
constexpr int kCanvasW = 1200;
constexpr int kCanvasH = 800;
constexpr int kLogoH = 540;
constexpr int kWordCenterY = 690;
constexpr int kWordSplitY = 590;  // samples below this belong to the wordmark

float smoother(float x) { x = std::clamp(x, 0.f, 1.f); return x * x * x * (x * (x * 6.f - 15.f) + 10.f); }
float clamp01(float x) { return std::clamp(x, 0.f, 1.f); }

// 0..1: scattered -> gathered -> held -> dissolving -> scattered, periodic in u.
float envelope(float u) {
    if (u < 0.30f) return u / 0.30f;
    if (u < 0.64f) return 1.f;
    if (u < 0.86f) return 1.f - (u - 0.64f) / 0.22f;
    return 0.f;
}

// The supplied logo file is cropped tight, so swooshes end in hard edges. Fade the outermost pixels to transparent.
void featherEdges(QImage& img, int px) {
    if (px < 1) return;
    const int w = img.width(), h = img.height();
    for (int y = 0; y < h; ++y) {
        QRgb* line = reinterpret_cast<QRgb*>(img.scanLine(y));
        int dy = std::min(y, h - 1 - y);
        for (int x = 0; x < w; ++x) {
            int d = std::min(std::min(x, w - 1 - x), dy);
            if (d >= px) {
                // skip the interior quickly
                if (x < w - px && x >= px) { x = w - px - 1; }
                continue;
            }
            float f = smoother(float(d) / float(px));
            QRgb c = line[x];
            line[x] = qRgba(int(qRed(c) * f), int(qGreen(c) * f), int(qBlue(c) * f), int(qAlpha(c) * f));
        }
    }
}

// How "solid" the real chrome logo is at phase u0 (0 = only dust, 1 = fully materialised).
float solidAmount(float u0) {
    float rise = smoother((u0 - 0.36f) / 0.09f);
    float fall = smoother((u0 - 0.60f) / 0.07f);
    return rise * (1.f - fall);
}
}  // namespace

ParticleBackground::ParticleBackground(QWidget* parent) : QWidget(parent) {
    setAttribute(Qt::WA_TransparentForMouseEvents);
    setAttribute(Qt::WA_OpaquePaintEvent);
    setFocusPolicy(Qt::NoFocus);
    clock_.start();
    timer_.setTimerType(Qt::PreciseTimer);
    timer_.setInterval(33);  // ~30 fps cap
    connect(&timer_, &QTimer::timeout, this, qOverload<>(&QWidget::update));
    connect(qApp, &QGuiApplication::applicationStateChanged, this, [this](Qt::ApplicationState s) {
        bool shouldPause = s != Qt::ApplicationActive;
        if (shouldPause == paused_) return;
        if (shouldPause) pauseStartMs_ = clock_.elapsed();
        else pausedTotal_ += (clock_.elapsed() - pauseStartMs_) / 1000.0;
        paused_ = shouldPause;
        applyTimerState();
    });
    buildTargets();
    rebuildParticles();
}

void ParticleBackground::buildTargets() {
    logoImg_ = QImage(QStringLiteral(":/logo_mark.png")).convertToFormat(QImage::Format_ARGB32_Premultiplied);

    canvas_ = QImage(kCanvasW, kCanvasH, QImage::Format_ARGB32_Premultiplied);
    canvas_.fill(Qt::transparent);
    QPainter p(&canvas_);
    p.setRenderHints(QPainter::Antialiasing | QPainter::SmoothPixmapTransform | QPainter::TextAntialiasing);

    // Mark
    if (!logoImg_.isNull()) {
        double lw = logoImg_.width() * double(kLogoH) / logoImg_.height();
        logoRect_ = QRectF((kCanvasW - lw) / 2.0, 6, lw, kLogoH);
        p.drawImage(logoRect_, logoImg_);
    }

    // Wordmark: heavy slanted capitals, wide tracking, one clean diagonal cut through the lower third.
    QFont f;
    f.setFamilies({"Segoe UI Black", "Arial Black", "Montserrat ExtraBold", "Impact", "DejaVu Sans"});
    f.setPixelSize(128);
    f.setWeight(QFont::Black);
    f.setLetterSpacing(QFont::AbsoluteSpacing, 18);
    QPainterPath text;
    text.addText(0, 0, f, QStringLiteral("BANNARAK STORE"));
    QRectF b = text.boundingRect();
    qreal s = (kCanvasW - 200) / b.width();
    QTransform tr;
    tr.translate(kCanvasW / 2.0, kWordCenterY);
    tr.scale(s, s);
    tr.shear(-0.20, 0);
    tr.translate(-b.center().x(), -b.center().y());
    wordPath_ = tr.map(text);
    QRectF pb = wordPath_.boundingRect();
    QPainterPath cut;
    qreal cy = pb.top() + pb.height() * 0.64;
    cut.addPolygon(QPolygonF({{pb.left() - 40, cy + 12}, {pb.right() + 40, cy - 16}, {pb.right() + 40, cy - 9}, {pb.left() - 40, cy + 19}}));
    wordPath_ = wordPath_.subtracted(cut);
    p.fillPath(wordPath_, Qt::white);
    p.end();

    samples_.clear();
    for (int y = 0; y < kCanvasH; y += 2) {
        const QRgb* line = reinterpret_cast<const QRgb*>(canvas_.constScanLine(y));
        for (int x = 0; x < kCanvasW; x += 2) {
            QColor c = QColor::fromRgba(qUnpremultiply(line[x]));
            float a = c.alphaF();
            if (a < 0.25f) continue;
            float w = y >= kWordSplitY ? a : a * std::max(0.35f, float(c.lightnessF()));
            if (w > 0.2f) samples_.push_back({QPointF(x / double(kCanvasW), y / double(kCanvasH)), w});
        }
    }
}

void ParticleBackground::rebuildParticles() {
    parts_.clear();
    if (samples_.empty()) return;
    QRandomGenerator rng(1337);
    auto rnd = [&](float a, float b) { return a + float(rng.generateDouble()) * (b - a); };

    std::vector<size_t> logoIdx, wordIdx;
    for (size_t i = 0; i < samples_.size(); ++i)
        (samples_[i].first.y() * kCanvasH >= kWordSplitY ? wordIdx : logoIdx).push_back(i);
    auto pick = [&](const std::vector<size_t>& pool) -> const std::pair<QPointF, float>& {
        for (int tries = 0; tries < 50; ++tries) {
            const auto& s = samples_[pool[rng.bounded(int(pool.size()))]];
            if (rnd(0, 1) < s.second) return s;
        }
        return samples_[pool[0]];
    };

    int nWord = int(count_ * 0.34), nLogo = count_ - nWord;
    for (int i = 0; i < count_; ++i) {
        const auto& pool = i < nLogo ? logoIdx : wordIdx;
        if (pool.empty()) continue;
        const auto& s = pick(pool);
        Particle p{};
        p.tx = float(s.first.x()) + rnd(-0.0006f, 0.0006f);
        p.ty = float(s.first.y()) + rnd(-0.0006f, 0.0006f);
        p.sx = rnd(-0.05f, 1.05f);
        p.sy = rnd(-0.05f, 1.05f);
        p.ph1 = rnd(0, 6.2832f);
        p.ph2 = rnd(0, 6.2832f);
        p.f1 = rnd(0.10f, 0.26f);
        p.f2 = rnd(0.10f, 0.26f);
        p.delay = rnd(0, 1);
        p.swirl = rnd(-1, 1);
        p.bright = 0.45f + 0.55f * s.second;
        p.size = rnd(1.0f, 2.2f);
        p.detail = rnd(0, 1) < 0.2f;
        parts_.push_back(p);
    }
    for (int i = 0; i < 320; ++i) {  // ambient dust: never forms anything
        Particle p{};
        p.sx = rnd(0, 1);
        p.sy = rnd(0, 1);
        p.ph1 = rnd(0, 6.2832f);
        p.ph2 = rnd(0, 6.2832f);
        p.f1 = rnd(0.04f, 0.14f);
        p.f2 = rnd(0.04f, 0.14f);
        p.bright = rnd(0.2f, 0.65f);
        p.size = rnd(0.8f, 1.7f);
        p.ambient = true;
        parts_.push_back(p);
    }
}

void ParticleBackground::setReducedMotion(bool on) {
    reduced_ = on;
    applyTimerState();
    update();
}
void ParticleBackground::setFormationRect(const QRectF& r) { rect_ = r; hasRect_ = r.isValid(); update(); }
void ParticleBackground::setParticleCount(int n) {
    n = std::clamp(n, 600, 7000);
    if (n == count_) return;
    count_ = n;
    rebuildParticles();
    update();
}
void ParticleBackground::setManualTime(double s) {
    manual_ = s;
    applyTimerState();
    update();
}

void ParticleBackground::applyTimerState() {
    bool run = isVisible() && !paused_ && !reduced_ && manual_ < 0;
    if (run && !timer_.isActive()) timer_.start();
    if (!run && timer_.isActive()) timer_.stop();
}
void ParticleBackground::showEvent(QShowEvent*) { applyTimerState(); }
void ParticleBackground::hideEvent(QHideEvent*) { applyTimerState(); }

double ParticleBackground::now() const {
    if (manual_ >= 0) return manual_;
    qint64 ms = paused_ ? pauseStartMs_ : clock_.elapsed();
    return ms / 1000.0 - pausedTotal_;
}

void ParticleBackground::paintEvent(QPaintEvent*) {
    QPainter p(this);
    paintFrame(p, size(), now());
}

QImage ParticleBackground::renderFrame(double t, const QSize& sz) {
    QImage img(sz, QImage::Format_ARGB32_Premultiplied);
    QPainter p(&img);
    paintFrame(p, sz, t);
    return img;
}

void ParticleBackground::ensureCaches(const QSize& sz, const QPointF& logoCenter, float haloRadius) const {
    const float W = sz.width(), H = sz.height();
    if (cacheSize_ != sz || baseCache_.isNull()) {
        cacheSize_ = sz;
        baseCache_ = QPixmap(sz);
        {
            QPainter b(&baseCache_);
            b.fillRect(QRectF(0, 0, W, H), QColor(3, 3, 4));
            QRadialGradient glow(QPointF(W / 2, H * 0.30), std::max(W, H) * 0.70);
            glow.setColorAt(0.0, QColor(34, 35, 38));
            glow.setColorAt(0.45, QColor(12, 12, 14));
            glow.setColorAt(1.0, QColor(2, 2, 3));
            b.fillRect(QRectF(0, 0, W, H), glow);
        }
        vignetteCache_ = QPixmap(sz);
        vignetteCache_.fill(Qt::transparent);
        {
            QPainter v(&vignetteCache_);
            QRadialGradient vig(QPointF(W / 2, H * 0.45), std::max(W, H) * 0.78);
            vig.setColorAt(0.60, QColor(0, 0, 0, 0));
            vig.setColorAt(1.00, QColor(0, 0, 0, 170));
            v.fillRect(QRectF(0, 0, W, H), vig);
        }
        beamCache_ = QPixmap(sz);
        beamCache_.fill(Qt::transparent);
        {
            QPainter b(&beamCache_);
            b.translate(W / 2, -H * 0.10);
            b.scale(0.42, 1.0);
            QRadialGradient beam(QPointF(0, 0), H * 1.05);
            beam.setColorAt(0.0, QColor(255, 255, 255, 255));
            beam.setColorAt(0.35, QColor(255, 255, 255, 85));
            beam.setColorAt(1.0, QColor(255, 255, 255, 0));
            b.fillRect(QRectF(-W * 3, -H, W * 6, H * 3), beam);
        }
        haloRadius_ = -1.f;  // force halo rebuild
    }
    if (haloRadius_ != haloRadius || haloCenter_ != logoCenter) {
        haloRadius_ = haloRadius;
        haloCenter_ = logoCenter;
        haloCache_ = QPixmap(sz);
        haloCache_.fill(Qt::transparent);
        QPainter h(&haloCache_);
        QRadialGradient halo(logoCenter, haloRadius);
        halo.setColorAt(0.0, QColor(255, 255, 255, 255));
        halo.setColorAt(1.0, QColor(255, 255, 255, 0));
        h.fillRect(QRectF(0, 0, W, H), halo);
    }
}

void ParticleBackground::paintFrame(QPainter& p, const QSize& sz, double t) const {
    const float W = sz.width(), H = sz.height();
    QRectF area = hasRect_ ? rect_ : QRectF(0, 0, W, H * 0.7);

    const float T = float(cycleSeconds());
    const float u0 = reduced_ ? 0.5f : float(std::fmod(t, double(T))) / T;
    const double tm = reduced_ ? 0.0 : t;
    const float solid = reduced_ ? 1.f : solidAmount(u0);

    const float scale = float(std::min(area.width() * 0.96 / kCanvasW, area.height() * 0.98 / kCanvasH));
    const float ox = float(area.center().x()) - kCanvasW * scale / 2.f;
    const float oy = float(area.center().y()) - kCanvasH * scale / 2.f;
    const QPointF logoCenter(ox + (logoRect_.center().x()) * scale, oy + logoRect_.center().y() * scale);

    // ---- atmosphere (static layers come from caches; only opacity changes per frame)
    ensureCaches(sz, logoCenter, logoRect_.width() * scale * 0.95f);
    p.drawPixmap(0, 0, baseCache_);
    {
        float breathe = 0.85f + 0.15f * std::sin(float(tm * 0.35));
        p.setOpacity(std::min(1.0, (26 + 34 * solid) * breathe / 255.0));
        p.drawPixmap(0, 0, beamCache_);
        if (solid > 0.002f) {
            p.setOpacity(38.0 * solid / 255.0);
            p.drawPixmap(0, 0, haloCache_);
        }
        p.setOpacity(1.0);
    }

    // ---- dust / gathering particles
    if (!parts_.empty()) {
        std::vector<QPointF> buckets[8];
        for (auto& b : buckets) b.reserve(parts_.size() / 4);
        const float partFade = 1.f - 0.82f * solid;  // dust yields to the solid logo but never fully vanishes
        for (const Particle& pt : parts_) {
            float spx = pt.sx * W + 30.f * std::cos(float(pt.f1 * tm) + pt.ph1);
            float spy = pt.sy * H + 24.f * std::sin(float(pt.f2 * tm) + pt.ph2);
            float x = spx, y = spy, alpha;
            if (pt.ambient) {
                alpha = 50.f + 120.f * pt.bright;
            } else {
                float g = 1.f;
                if (!reduced_) {
                    float u = u0 - pt.delay * 0.10f;
                    u -= std::floor(u);
                    g = envelope(u);
                }
                float e = smoother(g);
                float tx = ox + pt.tx * kCanvasW * scale, ty = oy + pt.ty * kCanvasH * scale;
                float dx = tx - spx, dy = ty - spy;
                float len = std::sqrt(dx * dx + dy * dy) + 1e-3f;
                float curve = pt.swirl * e * (1.f - e) * len * 0.35f;
                x = spx + dx * e + (-dy / len) * curve;
                y = spy + dy * e + (dx / len) * curve;
                if (pt.detail && !reduced_) {
                    x += 2.0f * std::cos(float(tm * 0.9) + pt.ph1) * e;
                    y += 2.0f * std::sin(float(tm * 0.8) + pt.ph2) * e;
                }
                alpha = (70.f + 175.f * pt.bright) * (0.30f + 0.70f * e) * partFade;
                if (reduced_) alpha = 0;
            }
            if (alpha < 8.f) continue;
            int lvl = std::clamp(int(alpha / 64.f), 0, 3);
            buckets[lvl * 2 + (pt.size > 1.4f ? 1 : 0)].push_back(QPointF(x, y));
        }
        p.setRenderHint(QPainter::Antialiasing, true);
        static const int alphas[4] = {70, 130, 190, 245};
        for (int lvl = 0; lvl < 4; ++lvl)
            for (int sz2 = 0; sz2 < 2; ++sz2) {
                auto& b = buckets[lvl * 2 + sz2];
                if (b.empty()) continue;
                QColor c = lvl >= 2 ? QColor(255, 255, 255) : QColor(204, 208, 216);
                c.setAlpha(alphas[lvl]);
                p.setPen(QPen(c, sz2 ? 1.9 : 1.2, Qt::SolidLine, Qt::RoundCap));
                p.drawPoints(b.data(), int(b.size()));
            }
    }

    // ---- the real chrome logo + silver wordmark, materialising out of the dust
    if (solid > 0.003f && !logoImg_.isNull()) {
        QRectF lr(ox + logoRect_.x() * scale, oy + logoRect_.y() * scale, logoRect_.width() * scale, logoRect_.height() * scale);
        QSize ts = lr.size().toSize();
        if (ts.width() > 0 && logoScaledSize_ != ts) {
            logoScaled_ = logoImg_.scaled(ts, Qt::IgnoreAspectRatio, Qt::SmoothTransformation).convertToFormat(QImage::Format_ARGB32_Premultiplied);
            featherEdges(logoScaled_, std::max(4, int(std::min(ts.width(), ts.height()) * 0.06)));
            logoScaledSize_ = ts;
        }
        // sweep position travels left -> right during the hold, then rests off-screen
        float sweepU = reduced_ ? 2.f : clamp01((u0 - 0.40f) / 0.20f);
        float band = -0.25f + 1.5f * sweepU;  // 0..1 across the logo width
        QImage frame = logoScaled_;
        {
            QPainter ip(&frame);
            ip.setCompositionMode(QPainter::CompositionMode_SourceAtop);
            QLinearGradient sw(QPointF(frame.width() * (band - 0.22f), 0), QPointF(frame.width() * (band + 0.22f), frame.height() * 0.35f));
            sw.setColorAt(0.0, QColor(255, 255, 255, 0));
            sw.setColorAt(0.5, QColor(255, 255, 255, 170));
            sw.setColorAt(1.0, QColor(255, 255, 255, 0));
            ip.fillRect(frame.rect(), sw);
        }
        p.setOpacity(solid);
        p.drawImage(lr.topLeft(), frame);

        // wordmark
        p.save();
        p.translate(ox, oy);
        p.scale(scale, scale);
        QRectF pb = wordPath_.boundingRect();
        QLinearGradient silver(QPointF(0, pb.top()), QPointF(0, pb.bottom()));
        silver.setColorAt(0.00, QColor(255, 255, 255));
        silver.setColorAt(0.42, QColor(176, 180, 188));
        silver.setColorAt(0.50, QColor(245, 246, 248));
        silver.setColorAt(1.00, QColor(122, 126, 134));
        p.setRenderHint(QPainter::Antialiasing, true);
        p.fillPath(wordPath_, silver);
        // same sweep, clipped to the lettering
        p.setClipPath(wordPath_);
        float wb = pb.left() + pb.width() * (band * 1.1f - 0.05f);
        QLinearGradient ws(QPointF(wb - 140, pb.top()), QPointF(wb + 140, pb.bottom()));
        ws.setColorAt(0.0, QColor(255, 255, 255, 0));
        ws.setColorAt(0.5, QColor(255, 255, 255, 200));
        ws.setColorAt(1.0, QColor(255, 255, 255, 0));
        p.fillRect(pb.adjusted(-20, -20, 20, 20), ws);
        p.setClipping(false);
        // hairline horizon under the wordmark
        QLinearGradient hl(QPointF(pb.left() - 40, 0), QPointF(pb.right() + 40, 0));
        hl.setColorAt(0.0, QColor(255, 255, 255, 0));
        hl.setColorAt(0.5, QColor(255, 255, 255, 120));
        hl.setColorAt(1.0, QColor(255, 255, 255, 0));
        p.fillRect(QRectF(pb.left() - 40, pb.bottom() + 26, pb.width() + 80, 1.2), hl);
        p.restore();
        p.setOpacity(1.0);
    }

    // vignette on top so the edges always fall into black
    p.drawPixmap(0, 0, vignetteCache_);
}
