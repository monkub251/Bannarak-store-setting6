#pragma once
#include <cstdint>
#include <set>
#include <string>
#include <vector>

#include "FiveM.h"
#include "Platform.h"
#include "Registry.h"
#include "Types.h"

namespace fmo {

enum ProfileBit : uint32_t {
    ProfileBase = 1,    // always part of OPTIMIZE NOW
    ProfileImpact = 2,  // "VANTA IMPACT"  - melee / impact feel
    ProfileFlow = 4,    // "ONYX FLOW"     - knife / movement / emote feel
    ProfileOptIn = 8    // only when the user enables the tweak by id in Settings
};

const char* profileDisplayName(uint32_t bit);

struct TweakDef {
    std::string id, title, rationale;
    Hive hive = Hive::HKCU;
    std::string key, name;
    RegValue desired;
    bool needsAdmin = false;
    unsigned minBuild = 0, maxBuild = 0;  // 0 = unbounded
    uint32_t profiles = ProfileBase;
    bool policy = false;       // Group Policy backed (requires a Windows edition with policy support)
    bool restartNote = false;  // takes full effect after sign-out / restart
};

struct PlanItem {
    TweakDef def;
    std::string sources;  // which profiles requested it
};

struct Plan {
    std::vector<PlanItem> items;
    std::vector<TaskResult> notes;  // skipped / conflicts, already explained
};

std::vector<TweakDef> tweakCatalog();
// Registry tweaks that depend on where FiveM is installed (graphics preference per executable).
std::vector<TweakDef> dynamicTweaks(const FiveMInfo& fivem);

// Merges compatible requests, detects conflicting ones (different value for the same target: both are dropped
// and reported), and filters by Windows build, Windows edition (Group Policy) and elevation.
Plan buildPlan(const std::vector<TweakDef>& catalog, uint32_t activeProfiles, const std::set<std::string>& optInIds,
               const SysInfo& sys, bool elevated);

}  // namespace fmo
