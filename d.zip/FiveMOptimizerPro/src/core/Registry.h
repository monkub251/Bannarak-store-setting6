#pragma once
#include <cstdint>
#include <map>
#include <memory>
#include <set>
#include <string>
#include <vector>

namespace fmo {

enum class Hive { HKCU, HKLM };
enum class RegType { DWord, String };

struct RegValue {
    RegType type = RegType::DWord;
    uint32_t dword = 0;
    std::string str;
    static RegValue dw(uint32_t v) { RegValue r; r.type = RegType::DWord; r.dword = v; return r; }
    static RegValue sz(const std::string& s) { RegValue r; r.type = RegType::String; r.str = s; return r; }
    bool operator==(const RegValue& o) const {
        return type == o.type && (type == RegType::DWord ? dword == o.dword : str == o.str);
    }
    bool operator!=(const RegValue& o) const { return !(*this == o); }
    std::string toText() const { return type == RegType::DWord ? std::to_string(dword) : str; }
};

struct RegRead {
    enum State { Found, NotFound, Error } state = NotFound;
    RegValue value;
    std::string error;
};

inline const char* hiveName(Hive h) { return h == Hive::HKCU ? "HKCU" : "HKLM"; }

class IRegistry {
public:
    virtual ~IRegistry() = default;
    virtual RegRead read(Hive h, const std::string& key, const std::string& name) = 0;
    virtual bool write(Hive h, const std::string& key, const std::string& name, const RegValue& v,
                       std::string& err) = 0;
    // Removes a value (never a key). Succeeds when the value is already absent.
    virtual bool removeValue(Hive h, const std::string& key, const std::string& name, std::string& err) = 0;
    virtual std::vector<std::string> subKeys(Hive h, const std::string& key) = 0;
    virtual bool isReal() const = 0;
};

// In-memory registry: used by unit tests and on non-Windows builds.
class MemoryRegistry : public IRegistry {
public:
    RegRead read(Hive h, const std::string& key, const std::string& name) override;
    bool write(Hive h, const std::string& key, const std::string& name, const RegValue& v,
               std::string& err) override;
    bool removeValue(Hive h, const std::string& key, const std::string& name, std::string& err) override;
    std::vector<std::string> subKeys(Hive h, const std::string& key) override;
    bool isReal() const override { return false; }

    // Fault injection for tests.
    std::set<std::string> denyWriteHives;  // e.g. "HKLM"
    bool silentlyDropWrites = false;       // write() reports success but nothing changes

private:
    static std::string id(Hive h, const std::string& key, const std::string& name);
    std::map<std::string, RegValue> values_;
};

// Real Windows registry on Windows, MemoryRegistry elsewhere.
std::unique_ptr<IRegistry> makeSystemRegistry();

}  // namespace fmo
