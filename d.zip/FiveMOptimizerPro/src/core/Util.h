#pragma once
#include <cstdint>
#include <filesystem>
#include <string>
#include <vector>

namespace fmo {
namespace fs = std::filesystem;

std::string nowStamp();  // yyyymmdd-HHMMSS (local time)
std::string isoNow();    // yyyy-mm-ddTHH:MM:SS (local time)
std::string formatBytes(uint64_t bytes);

// Percent-escaping for the backup manifest (escapes % \t \n \r =).
std::string escapeField(const std::string& s);
std::string unescapeField(const std::string& s);

std::vector<std::string> splitStr(const std::string& s, char sep);
std::string toLower(std::string s);
bool iequals(const std::string& a, const std::string& b);
std::string trim(const std::string& s);

std::string getEnv(const char* name);  // UTF-8; empty when unset
fs::path pathFromUtf8(const std::string& s);
std::string pathToUtf8(const fs::path& p);

#ifdef _WIN32
std::wstring widen(const std::string& s);
std::string narrow(const std::wstring& s);
#endif
}  // namespace fmo
