#include "Platform.h"

#include <algorithm>
#include <chrono>
#include <cstring>
#include <fstream>
#include <sstream>
#include <thread>

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <psapi.h>
#include <shellapi.h>
#include <tlhelp32.h>
#else
#include <fcntl.h>
#include <poll.h>
#include <signal.h>
#include <sys/statvfs.h>
#include <sys/wait.h>
#include <unistd.h>
#endif

namespace fmo {

// ============================================================================ Windows
#ifdef _WIN32

static std::wstring quoteArg(const std::wstring& a) {
    if (!a.empty() && a.find_first_of(L" \t\n\v\"") == std::wstring::npos) return a;
    std::wstring r = L"\"";
    for (auto it = a.begin();; ++it) {
        unsigned bs = 0;
        while (it != a.end() && *it == L'\\') {
            ++it;
            ++bs;
        }
        if (it == a.end()) {
            r.append(bs * 2, L'\\');
            break;
        }
        if (*it == L'"') {
            r.append(bs * 2 + 1, L'\\');
            r.push_back(L'"');
        } else {
            r.append(bs, L'\\');
            r.push_back(*it);
        }
    }
    r.push_back(L'"');
    return r;
}

ProcResult runProcess(const std::vector<std::string>& argv, int timeoutMs) {
    ProcResult res;
    if (argv.empty()) {
        res.error = "empty command";
        return res;
    }
    std::wstring cmd;
    for (size_t i = 0; i < argv.size(); ++i) {
        if (i) cmd += L' ';
        cmd += quoteArg(widen(argv[i]));
    }
    SECURITY_ATTRIBUTES sa{sizeof sa, nullptr, TRUE};
    HANDLE rd = nullptr, wr = nullptr;
    if (!CreatePipe(&rd, &wr, &sa, 0)) {
        res.error = "CreatePipe failed";
        return res;
    }
    SetHandleInformation(rd, HANDLE_FLAG_INHERIT, 0);
    STARTUPINFOW si{};
    si.cb = sizeof si;
    si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;
    si.hStdOutput = wr;
    si.hStdError = wr;
    si.hStdInput = GetStdHandle(STD_INPUT_HANDLE);
    PROCESS_INFORMATION pi{};
    std::wstring exe = widen(argv[0]);
    BOOL ok = CreateProcessW(exe.c_str(), cmd.data(), nullptr, nullptr, TRUE, CREATE_NO_WINDOW, nullptr, nullptr,
                             &si, &pi);
    CloseHandle(wr);
    if (!ok) {
        res.error = "CreateProcess failed (error " + std::to_string(GetLastError()) + ")";
        CloseHandle(rd);
        return res;
    }
    res.started = true;
    DWORD start = GetTickCount();
    auto drain = [&]() {
        for (;;) {
            DWORD avail = 0;
            if (!PeekNamedPipe(rd, nullptr, 0, nullptr, &avail, nullptr) || avail == 0) break;
            char buf[4096];
            DWORD n = 0;
            if (!ReadFile(rd, buf, std::min<DWORD>(avail, sizeof buf), &n, nullptr) || n == 0) break;
            res.output.append(buf, n);
        }
    };
    for (;;) {
        drain();
        DWORD w = WaitForSingleObject(pi.hProcess, 20);
        if (w == WAIT_OBJECT_0) {
            drain();
            break;
        }
        if (GetTickCount() - start > static_cast<DWORD>(timeoutMs)) {
            TerminateProcess(pi.hProcess, 1);
            res.timedOut = true;
            break;
        }
    }
    DWORD code = 1;
    GetExitCodeProcess(pi.hProcess, &code);
    res.exitCode = static_cast<int>(code);
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);
    CloseHandle(rd);
    return res;
}

std::string systemTool(const std::string& exeName) {
    wchar_t dir[MAX_PATH];
    UINT n = GetSystemDirectoryW(dir, MAX_PATH);
    if (n == 0 || n >= MAX_PATH) return {};
    return narrow(std::wstring(dir, n)) + "\\" + exeName;
}

bool isWindows() { return true; }

bool isElevated() {
    HANDLE tok = nullptr;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &tok)) return false;
    TOKEN_ELEVATION e{};
    DWORD sz = 0;
    BOOL ok = GetTokenInformation(tok, TokenElevation, &e, sizeof e, &sz);
    CloseHandle(tok);
    return ok && e.TokenIsElevated;
}

bool relaunchElevated(const std::string& arguments) {
    wchar_t exe[MAX_PATH];
    DWORD n = GetModuleFileNameW(nullptr, exe, MAX_PATH);
    if (n == 0 || n >= MAX_PATH) return false;
    std::wstring args = widen(arguments);
    SHELLEXECUTEINFOW sei{};
    sei.cbSize = sizeof sei;
    sei.lpVerb = L"runas";
    sei.lpFile = exe;
    sei.lpParameters = args.c_str();
    sei.nShow = SW_SHOWNORMAL;
    return ShellExecuteExW(&sei) == TRUE;
}

bool isDesktopPc() {
    SYSTEM_POWER_STATUS sps{};
    if (!GetSystemPowerStatus(&sps)) return true;
    // BatteryFlag 128 = no system battery
    return sps.BatteryFlag == 128 || sps.BatteryFlag == 255;
}

bool scheduleRestart(int delaySeconds, std::string& err) {
    ProcResult r = runProcess({systemTool("shutdown.exe"), "/r", "/t", std::to_string(delaySeconds), "/c",
                               "Restart requested by FiveM Optimizer PRO"},
                              10000);
    if (!r.started || r.exitCode != 0) {
        err = r.started ? ("shutdown.exe exit code " + std::to_string(r.exitCode)) : r.error;
        return false;
    }
    return true;
}

typedef LONG(WINAPI* RtlGetVersionFn)(PRTL_OSVERSIONINFOW);

SysInfo detectSystem(IRegistry& reg) {
    SysInfo s;
    s.windows = true;
    s.elevated = isElevated();
    s.desktop = isDesktopPc();
    RTL_OSVERSIONINFOW vi{};
    vi.dwOSVersionInfoSize = sizeof vi;
    if (HMODULE nt = GetModuleHandleW(L"ntdll.dll")) {
        auto fn = reinterpret_cast<RtlGetVersionFn>(reinterpret_cast<void*>(GetProcAddress(nt, "RtlGetVersion")));
        if (fn) fn(&vi);
    }
    s.build = vi.dwBuildNumber;
    const char* cv = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion";
    auto rs = [&](const char* n) {
        RegRead r = reg.read(Hive::HKLM, cv, n);
        return r.state == RegRead::Found && r.value.type == RegType::String ? r.value.str : std::string();
    };
    s.osName = rs("ProductName");
    if (s.build >= 22000 && s.osName.find("Windows 10") != std::string::npos)
        s.osName.replace(s.osName.find("Windows 10"), 10, "Windows 11");  // ProductName is stale on Win11
    s.edition = rs("EditionID");
    s.displayVersion = rs("DisplayVersion");
    s.homeEdition = s.edition.compare(0, 4, "Core") == 0;
    SYSTEM_INFO si{};
    GetNativeSystemInfo(&si);
    switch (si.wProcessorArchitecture) {
        case PROCESSOR_ARCHITECTURE_AMD64: s.arch = "x64"; break;
        case PROCESSOR_ARCHITECTURE_ARM64: s.arch = "ARM64"; break;
        case PROCESSOR_ARCHITECTURE_INTEL: s.arch = "x86"; break;
        default: s.arch = "unknown";
    }
    s.logicalCores = si.dwNumberOfProcessors;
    RegRead cpu = reg.read(Hive::HKLM, "HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0", "ProcessorNameString");
    if (cpu.state == RegRead::Found) s.cpu = trim(cpu.value.str);
    MEMORYSTATUSEX ms{};
    ms.dwLength = sizeof ms;
    if (GlobalMemoryStatusEx(&ms)) {
        s.ramBytes = ms.ullTotalPhys;
        s.ramFreeBytes = ms.ullAvailPhys;
    }
    const char* cls = "SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}";
    for (const auto& sub : reg.subKeys(Hive::HKLM, cls)) {
        if (sub.size() != 4 || !std::isdigit(static_cast<unsigned char>(sub[0]))) continue;
        RegRead d = reg.read(Hive::HKLM, std::string(cls) + "\\" + sub, "DriverDesc");
        RegRead v = reg.read(Hive::HKLM, std::string(cls) + "\\" + sub, "DriverVersion");
        if (d.state == RegRead::Found) {
            std::string g = d.value.str;
            if (v.state == RegRead::Found) g += " (driver " + v.value.str + ")";
            s.gpus.push_back(g);
        }
    }
    wchar_t sysdir[MAX_PATH];
    if (GetSystemDirectoryW(sysdir, MAX_PATH)) {
        wchar_t root[4] = {sysdir[0], L':', L'\\', 0};
        ULARGE_INTEGER freeB{}, total{}, totalFree{};
        if (GetDiskFreeSpaceExW(root, &freeB, &total, &totalFree)) {
            s.sysDriveTotal = total.QuadPart;
            s.sysDriveFree = freeB.QuadPart;
        }
    }
    return s;
}

std::vector<std::string> runningProcessNames() {
    std::vector<std::string> out;
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return out;
    PROCESSENTRY32W pe{};
    pe.dwSize = sizeof pe;
    if (Process32FirstW(snap, &pe)) {
        do {
            out.push_back(narrow(pe.szExeFile));
        } while (Process32NextW(snap, &pe));
    }
    CloseHandle(snap);
    return out;
}

std::vector<ProcInfo> topProcessesByMemory(size_t n) {
    std::vector<ProcInfo> all;
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return all;
    PROCESSENTRY32W pe{};
    pe.dwSize = sizeof pe;
    if (Process32FirstW(snap, &pe)) {
        do {
            HANDLE h = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pe.th32ProcessID);
            if (!h) continue;
            PROCESS_MEMORY_COUNTERS pmc{};
            if (GetProcessMemoryInfo(h, &pmc, sizeof pmc))
                all.push_back({pe.th32ProcessID, narrow(pe.szExeFile), pmc.WorkingSetSize});
            CloseHandle(h);
        } while (Process32NextW(snap, &pe));
    }
    CloseHandle(snap);
    std::sort(all.begin(), all.end(), [](const ProcInfo& a, const ProcInfo& b) { return a.workingSetBytes > b.workingSetBytes; });
    if (all.size() > n) all.resize(n);
    return all;
}

static uint64_t ft(const FILETIME& f) { return (static_cast<uint64_t>(f.dwHighDateTime) << 32) | f.dwLowDateTime; }

LoadSnapshot sampleLoad(int intervalMs) {
    LoadSnapshot l;
    FILETIME i1, k1, u1, i2, k2, u2;
    bool ok = GetSystemTimes(&i1, &k1, &u1) != 0;
    std::this_thread::sleep_for(std::chrono::milliseconds(intervalMs));
    ok = ok && GetSystemTimes(&i2, &k2, &u2);
    if (ok) {
        uint64_t idle = ft(i2) - ft(i1), total = (ft(k2) - ft(k1)) + (ft(u2) - ft(u1));
        if (total > 0) l.cpuPercent = 100.0 * (1.0 - static_cast<double>(idle) / static_cast<double>(total));
    }
    MEMORYSTATUSEX ms{};
    ms.dwLength = sizeof ms;
    if (GlobalMemoryStatusEx(&ms)) {
        l.ramTotal = ms.ullTotalPhys;
        l.ramFree = ms.ullAvailPhys;
        l.ramPercent = 100.0 * (1.0 - static_cast<double>(ms.ullAvailPhys) / static_cast<double>(ms.ullTotalPhys));
    }
    return l;
}

// ============================================================================ POSIX (tests / dev only)
#else

ProcResult runProcess(const std::vector<std::string>& argv, int timeoutMs) {
    ProcResult res;
    if (argv.empty()) {
        res.error = "empty command";
        return res;
    }
    int pfd[2];
    if (pipe(pfd) != 0) {
        res.error = "pipe failed";
        return res;
    }
    pid_t pid = fork();
    if (pid < 0) {
        res.error = "fork failed";
        close(pfd[0]);
        close(pfd[1]);
        return res;
    }
    if (pid == 0) {
        dup2(pfd[1], 1);
        dup2(pfd[1], 2);
        close(pfd[0]);
        close(pfd[1]);
        std::vector<char*> args;
        for (const auto& a : argv) args.push_back(const_cast<char*>(a.c_str()));
        args.push_back(nullptr);
        execv(args[0], args.data());
        _exit(127);
    }
    close(pfd[1]);
    res.started = true;
    auto start = std::chrono::steady_clock::now();
    for (;;) {
        pollfd p{pfd[0], POLLIN, 0};
        int r = poll(&p, 1, 50);
        if (r > 0) {
            char buf[4096];
            ssize_t n = read(pfd[0], buf, sizeof buf);
            if (n <= 0) break;
            res.output.append(buf, static_cast<size_t>(n));
        }
        if (std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - start).count() >
            timeoutMs) {
            kill(pid, SIGKILL);
            res.timedOut = true;
            break;
        }
    }
    close(pfd[0]);
    int st = 0;
    waitpid(pid, &st, 0);
    res.exitCode = WIFEXITED(st) ? WEXITSTATUS(st) : -1;
    return res;
}

std::string systemTool(const std::string&) { return {}; }
bool isWindows() { return false; }
bool isElevated() { return geteuid() == 0; }
bool relaunchElevated(const std::string&) { return false; }
bool isDesktopPc() { return true; }
bool scheduleRestart(int, std::string& err) {
    err = "not supported on this platform";
    return false;
}

SysInfo detectSystem(IRegistry&) {
    SysInfo s;
    s.elevated = isElevated();
    s.arch = "x64";
    s.osName = "Non-Windows development build";
    std::ifstream ci("/proc/cpuinfo");
    std::string line;
    while (std::getline(ci, line)) {
        if (line.rfind("model name", 0) == 0 && s.cpu.empty()) s.cpu = trim(line.substr(line.find(':') + 1));
        if (line.rfind("processor", 0) == 0) ++s.logicalCores;
    }
    std::ifstream mi("/proc/meminfo");
    while (std::getline(mi, line)) {
        uint64_t kb = 0;
        if (line.rfind("MemTotal:", 0) == 0) { std::sscanf(line.c_str(), "MemTotal: %lu", &kb); s.ramBytes = kb * 1024; }
        if (line.rfind("MemAvailable:", 0) == 0) { std::sscanf(line.c_str(), "MemAvailable: %lu", &kb); s.ramFreeBytes = kb * 1024; }
    }
    struct statvfs sv {};
    if (statvfs("/", &sv) == 0) {
        s.sysDriveTotal = static_cast<uint64_t>(sv.f_blocks) * sv.f_frsize;
        s.sysDriveFree = static_cast<uint64_t>(sv.f_bavail) * sv.f_frsize;
    }
    return s;
}

std::vector<std::string> runningProcessNames() {
    std::vector<std::string> out;
    std::error_code ec;
    for (auto& e : fs::directory_iterator("/proc", ec)) {
        std::string n = e.path().filename().string();
        if (n.empty() || !std::isdigit(static_cast<unsigned char>(n[0]))) continue;
        std::ifstream f(e.path() / "comm");
        std::string name;
        if (std::getline(f, name)) out.push_back(name);
    }
    return out;
}

std::vector<ProcInfo> topProcessesByMemory(size_t n) {
    std::vector<ProcInfo> all;
    std::error_code ec;
    for (auto& e : fs::directory_iterator("/proc", ec)) {
        std::string d = e.path().filename().string();
        if (d.empty() || !std::isdigit(static_cast<unsigned char>(d[0]))) continue;
        std::ifstream c(e.path() / "comm"), st(e.path() / "statm");
        std::string name;
        uint64_t sz = 0, rss = 0;
        if (std::getline(c, name) && (st >> sz >> rss))
            all.push_back({static_cast<uint32_t>(std::stoul(d)), name, rss * 4096});
    }
    std::sort(all.begin(), all.end(), [](const ProcInfo& a, const ProcInfo& b) { return a.workingSetBytes > b.workingSetBytes; });
    if (all.size() > n) all.resize(n);
    return all;
}

static bool readCpu(uint64_t& idle, uint64_t& total) {
    std::ifstream f("/proc/stat");
    std::string cpu;
    uint64_t v[8] = {0};
    if (!(f >> cpu)) return false;
    for (auto& x : v) f >> x;
    idle = v[3] + v[4];
    total = 0;
    for (auto x : v) total += x;
    return true;
}

LoadSnapshot sampleLoad(int intervalMs) {
    LoadSnapshot l;
    uint64_t i1 = 0, t1 = 0, i2 = 0, t2 = 0;
    bool ok = readCpu(i1, t1);
    std::this_thread::sleep_for(std::chrono::milliseconds(intervalMs));
    ok = ok && readCpu(i2, t2);
    if (ok && t2 > t1) l.cpuPercent = 100.0 * (1.0 - static_cast<double>(i2 - i1) / static_cast<double>(t2 - t1));
    SysInfo s;
    IRegistry* none = nullptr;
    (void)none;
    MemoryRegistry mr;
    s = detectSystem(mr);
    l.ramTotal = s.ramBytes;
    l.ramFree = s.ramFreeBytes;
    if (s.ramBytes) l.ramPercent = 100.0 * (1.0 - static_cast<double>(s.ramFreeBytes) / static_cast<double>(s.ramBytes));
    return l;
}

#endif

}  // namespace fmo
