#pragma once
#include <map>
#include <string>
#include <vector>

#include "Util.h"

namespace fmo {

// One recorded "original state". kind: reg | service | dns | power
struct BackupEntry {
    std::string kind;
    std::map<std::string, std::string> f;
    bool operator==(const BackupEntry& o) const { return kind == o.kind && f == o.f; }
    std::string get(const std::string& k) const {
        auto it = f.find(k);
        return it == f.end() ? std::string() : it->second;
    }
};

struct BackupSet {
    std::string id;       // folder name, e.g. 20261018-061700
    fs::path dir;
    std::string created;  // ISO time
    std::vector<BackupEntry> entries;
    bool restored = false;
};

// Timestamped, never-overwritten backups. A backup is only considered created once
// the manifest was written, flushed, renamed and read back identically.
class BackupStore {
public:
    explicit BackupStore(fs::path root) : root_(std::move(root)) {}
    bool create(const std::vector<BackupEntry>& entries, BackupSet& out, std::string& err) const;
    std::vector<BackupSet> list() const;  // newest first; unreadable/incomplete backups are skipped
    bool markRestored(const BackupSet& set, std::string& err) const;
    const fs::path& root() const { return root_; }

    static bool parseManifest(const fs::path& file, BackupSet& out, std::string& err);

private:
    fs::path root_;
};

}  // namespace fmo
