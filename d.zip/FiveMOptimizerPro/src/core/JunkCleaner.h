#pragma once
#include <atomic>
#include <cstdint>
#include <functional>
#include <set>
#include <string>
#include <vector>

#include "Registry.h"
#include "Types.h"
#include "Util.h"

namespace fmo {

enum class Tier {
    Safe,      // regenerable; selected by default and included in OPTIMIZE NOW
    Optional   // needs a separate confirmation; never selected automatically
};

struct CleanTarget {
    fs::path root;
    std::string filePattern;  // empty = everything below root; otherwise glob (e.g. thumbcache_*.db), top level only
    bool recursive = true;
};

struct CleanCategory {
    std::string id, title, description;
    Tier tier = Tier::Safe;
    bool needsGameClosed = false;
    bool recycleBin = false;  // special handler (Windows only)
    bool selectedByDefault = false;
    int minAgeMinutes = 0;    // only files untouched for this long are removed
    std::vector<CleanTarget> targets;
};

// Every location the cleaner may ever touch is derived from this struct. Tests inject temp folders.
struct CleanerEnv {
    fs::path userTemp, userTemp2, winDir, localAppData, appData, programData, userProfile;
    fs::path fivemAppDir;
    std::function<bool()> fivemRunning;
    int tempMinAgeMinutes = 60;
    static CleanerEnv fromSystem();
};

struct CategoryScan {
    std::string id;
    bool available = false;   // at least one target root exists
    uint64_t files = 0;
    uint64_t bytes = 0;       // ESTIMATE: what would be reclaimed if everything eligible is deleted
    std::string note;
};

struct CategoryResult {
    std::string id, title;
    uint64_t scanned = 0, deleted = 0, skipped = 0, failed = 0;
    uint64_t bytesReclaimed = 0;  // measured: only counted after the file was verified gone
    Status status = Status::Skipped;
    std::string note;
};

using CleanProgress = std::function<void(const std::string& message)>;

class JunkCleaner {
public:
    explicit JunkCleaner(CleanerEnv env);

    std::vector<CleanCategory> categories() const;
    // Data that is never removed automatically (shown in the UI).
    static std::vector<std::string> protectedData();

    CategoryScan scan(const CleanCategory& c, const std::atomic<bool>* cancel = nullptr) const;
    CategoryResult clean(const CleanCategory& c, const CleanProgress& progress = {},
                         const std::atomic<bool>* cancel = nullptr) const;

    // True when `root` is acceptable as a cleaning root (not a drive root / profile / system folder / ancestor of one).
    bool isSafeRoot(const fs::path& root) const;

    // Windows Disk Cleanup handlers present on this PC (read-only) and whether this tool covers them natively.
    struct Handler { std::string name; bool coveredNatively; };
    static std::vector<Handler> diskCleanupHandlers(IRegistry& reg);

    static bool globMatch(const std::string& pattern, const std::string& name);

private:
    CleanerEnv env_;
    std::vector<fs::path> forbidden_;
    struct Walk;
    void walkTarget(const CleanTarget& t, const CleanCategory& c, bool dryRun, const CleanProgress& progress,
                    const std::atomic<bool>* cancel, CategoryResult& r, CategoryScan* s) const;
};

}  // namespace fmo
