#include "Registry.h"

#include <cstring>

#include <cstring>
#include "Util.h"

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#endif

namespace fmo {

// ---------------------------------------------------------------- MemoryRegistry
std::string MemoryRegistry::id(Hive h, const std::string& key, const std::string& name) {
    return std::string(hiveName(h)) + "|" + toLower(key) + "|" + toLower(name);
}

RegRead MemoryRegistry::read(Hive h, const std::string& key, const std::string& name) {
    RegRead r;
    auto it = values_.find(id(h, key, name));
    if (it == values_.end()) return r;
    r.state = RegRead::Found;
    r.value = it->second;
    return r;
}

bool MemoryRegistry::write(Hive h, const std::string& key, const std::string& name, const RegValue& v,
                           std::string& err) {
    if (denyWriteHives.count(hiveName(h))) {
        err = "access denied";
        return false;
    }
    if (!silentlyDropWrites) values_[id(h, key, name)] = v;
    return true;
}

bool MemoryRegistry::removeValue(Hive h, const std::string& key, const std::string& name, std::string& err) {
    if (denyWriteHives.count(hiveName(h))) {
        err = "access denied";
        return false;
    }
    if (!silentlyDropWrites) values_.erase(id(h, key, name));
    return true;
}

std::vector<std::string> MemoryRegistry::subKeys(Hive h, const std::string& key) {
    std::set<std::string> out;
    std::string prefix = std::string(hiveName(h)) + "|" + toLower(key) + "\\";
    for (const auto& kv : values_) {
        if (kv.first.compare(0, prefix.size(), prefix) != 0) continue;
        std::string rest = kv.first.substr(prefix.size());
        size_t bar = rest.find('|');
        std::string path = rest.substr(0, bar);
        size_t sl = path.find('\\');
        out.insert(path.substr(0, sl));
    }
    return {out.begin(), out.end()};
}

// ---------------------------------------------------------------- Windows registry
#ifdef _WIN32
namespace {

class WinRegistry : public IRegistry {
public:
    bool isReal() const override { return true; }

    RegRead read(Hive h, const std::string& key, const std::string& name) override {
        RegRead out;
        HKEY k = nullptr;
        LONG r = RegOpenKeyExW(root(h), widen(key).c_str(), 0, KEY_QUERY_VALUE | KEY_WOW64_64KEY, &k);
        if (r == ERROR_FILE_NOT_FOUND || r == ERROR_PATH_NOT_FOUND) return out;
        if (r != ERROR_SUCCESS) return fail(out, "open key failed", r);
        DWORD type = 0, size = 0;
        std::wstring wname = widen(name);
        r = RegQueryValueExW(k, wname.c_str(), nullptr, &type, nullptr, &size);
        if (r == ERROR_FILE_NOT_FOUND) {
            RegCloseKey(k);
            return out;
        }
        if (r != ERROR_SUCCESS) {
            RegCloseKey(k);
            return fail(out, "query value failed", r);
        }
        std::vector<BYTE> buf(static_cast<size_t>(size) + 4, 0);
        DWORD got = size;
        r = RegQueryValueExW(k, wname.c_str(), nullptr, &type, buf.data(), &got);
        RegCloseKey(k);
        if (r != ERROR_SUCCESS) return fail(out, "read value failed", r);
        if (type == REG_DWORD && got == sizeof(DWORD)) {
            DWORD v;
            std::memcpy(&v, buf.data(), sizeof v);
            out.state = RegRead::Found;
            out.value = RegValue::dw(v);
        } else if (type == REG_SZ || type == REG_EXPAND_SZ) {
            std::wstring w(reinterpret_cast<wchar_t*>(buf.data()), got / sizeof(wchar_t));
            while (!w.empty() && w.back() == L'\0') w.pop_back();
            out.state = RegRead::Found;
            out.value = RegValue::sz(narrow(w));
        } else {
            out.state = RegRead::Error;
            out.error = "unsupported registry value type (left untouched)";
        }
        return out;
    }

    bool write(Hive h, const std::string& key, const std::string& name, const RegValue& v,
               std::string& err) override {
        HKEY k = nullptr;
        DWORD disp = 0;
        LONG r = RegCreateKeyExW(root(h), widen(key).c_str(), 0, nullptr, 0, KEY_SET_VALUE | KEY_WOW64_64KEY,
                                 nullptr, &k, &disp);
        if (r != ERROR_SUCCESS) {
            err = describe("create/open key failed", r);
            return false;
        }
        std::wstring wname = widen(name);
        if (v.type == RegType::DWord) {
            DWORD d = v.dword;
            r = RegSetValueExW(k, wname.c_str(), 0, REG_DWORD, reinterpret_cast<const BYTE*>(&d), sizeof d);
        } else {
            std::wstring w = widen(v.str);
            r = RegSetValueExW(k, wname.c_str(), 0, REG_SZ, reinterpret_cast<const BYTE*>(w.c_str()),
                               static_cast<DWORD>((w.size() + 1) * sizeof(wchar_t)));
        }
        RegCloseKey(k);
        if (r != ERROR_SUCCESS) {
            err = describe("set value failed", r);
            return false;
        }
        return true;
    }

    bool removeValue(Hive h, const std::string& key, const std::string& name, std::string& err) override {
        HKEY k = nullptr;
        LONG r = RegOpenKeyExW(root(h), widen(key).c_str(), 0, KEY_SET_VALUE | KEY_WOW64_64KEY, &k);
        if (r == ERROR_FILE_NOT_FOUND || r == ERROR_PATH_NOT_FOUND) return true;
        if (r != ERROR_SUCCESS) {
            err = describe("open key failed", r);
            return false;
        }
        r = RegDeleteValueW(k, widen(name).c_str());
        RegCloseKey(k);
        if (r == ERROR_FILE_NOT_FOUND) return true;
        if (r != ERROR_SUCCESS) {
            err = describe("delete value failed", r);
            return false;
        }
        return true;
    }

    std::vector<std::string> subKeys(Hive h, const std::string& key) override {
        std::vector<std::string> out;
        HKEY k = nullptr;
        if (RegOpenKeyExW(root(h), widen(key).c_str(), 0, KEY_ENUMERATE_SUB_KEYS | KEY_WOW64_64KEY, &k) !=
            ERROR_SUCCESS)
            return out;
        for (DWORD i = 0;; ++i) {
            wchar_t name[256];
            DWORD len = 256;
            LONG r = RegEnumKeyExW(k, i, name, &len, nullptr, nullptr, nullptr, nullptr);
            if (r != ERROR_SUCCESS) break;
            out.push_back(narrow(std::wstring(name, len)));
        }
        RegCloseKey(k);
        return out;
    }

private:
    static HKEY root(Hive h) { return h == Hive::HKCU ? HKEY_CURRENT_USER : HKEY_LOCAL_MACHINE; }
    static std::string describe(const char* what, LONG code) {
        return std::string(what) + " (Win32 error " + std::to_string(code) + (code == 5 ? ", access denied" : "") + ")";
    }
    static RegRead& fail(RegRead& r, const char* what, LONG code) {
        r.state = RegRead::Error;
        r.error = describe(what, code);
        return r;
    }
};

}  // namespace
#endif

std::unique_ptr<IRegistry> makeSystemRegistry() {
#ifdef _WIN32
    return std::make_unique<WinRegistry>();
#else
    return std::make_unique<MemoryRegistry>();
#endif
}

}  // namespace fmo
