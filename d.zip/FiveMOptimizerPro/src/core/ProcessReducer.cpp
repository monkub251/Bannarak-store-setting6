#include "ProcessReducer.h"

#include <algorithm>
#include <atomic>
#include <chrono>
#include <thread>

#include "Log.h"
#include "Util.h"

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <psapi.h>
#include <shellapi.h>
#include <tlhelp32.h>
#else
#include <fstream>
#include <unistd.h>
#endif

namespace fmo {

// ------------------------------------------------------------------ selection (pure logic)
bool isAlwaysProtected(const std::string& exeName) {
    static const std::set<std::string> exact = {
        "system", "registry", "idle", "memory compression", "secure system", "smss.exe", "csrss.exe", "wininit.exe",
        "winlogon.exe", "services.exe", "lsass.exe", "lsaiso.exe", "lsm.exe", "svchost.exe", "dwm.exe",
        "fontdrvhost.exe", "explorer.exe", "sihost.exe", "taskhostw.exe", "ctfmon.exe", "runtimebroker.exe",
        "shellexperiencehost.exe", "startmenuexperiencehost.exe", "searchhost.exe", "textinputhost.exe",
        "applicationframehost.exe", "audiodg.exe", "conhost.exe", "wmiprvse.exe", "spoolsv.exe", "dllhost.exe",
        "wudfhost.exe", "dashost.exe", "sppsvc.exe", "smartscreen.exe", "launcher.exe" /* Rockstar launcher */,
        "dxgkrnl", "wlanext.exe", "unsecapp.exe", "taskmgr.exe"};
    static const char* prefixes[] = {"fivem", "gta", "playgta", "rockstar", "socialclub", "steam", "epicgames",
                                     "easyanticheat", "beservice", "nvcontainer", "nvdisplay", "rtk", "atie",
                                     "msmpeng", "nissrv", "securityhealth", "fivemoptimizer"};
    std::string l = toLower(exeName);
    if (exact.count(l)) return true;
    for (auto* p : prefixes)
        if (l.rfind(p, 0) == 0) return true;
    return false;
}

static bool isKnownHog(const std::string& lower) {
    static const std::set<std::string> hogs = {
        "chrome.exe", "msedge.exe", "firefox.exe", "brave.exe", "opera.exe", "onedrive.exe", "teams.exe",
        "ms-teams.exe", "spotify.exe", "skype.exe", "whatsapp.exe", "telegram.exe", "dropbox.exe",
        "googledrivefs.exe", "msedgewebview2.exe", "yourphone.exe", "phoneexperiencehost.exe", "widgets.exe"};
    return hogs.count(lower) > 0;
}

std::vector<ProcEntry> selectTargets(const std::vector<ProcEntry>& all, uint32_t selfPid, const ReducerOptions& o) {
    std::vector<ProcEntry> out;
    for (const auto& p : all) {
        if (!p.ownedByUser || p.pid == selfPid || p.pid == 0 || p.pid == 4) continue;
        std::string l = toLower(p.name);
        if (isAlwaysProtected(l) || o.keepNames.count(l)) continue;
        if (!o.maxMode && !isKnownHog(l)) continue;
        out.push_back(p);
    }
    return out;
}

std::vector<ProcEntry> relaunchRoots(const std::vector<ProcEntry>& targets) {
    std::set<uint32_t> pids;
    for (const auto& t : targets) pids.insert(t.pid);
    std::vector<ProcEntry> roots;
    std::set<std::string> seen;
    for (const auto& t : targets) {
        if (t.path.empty() || pids.count(t.parentPid)) continue;
        std::string pl = toLower(t.path);
        if (pl.find("\\windows\\") != std::string::npos) continue;  // system helpers are not user applications
        if (seen.insert(pl).second) roots.push_back(t);
    }
    return roots;
}

ReducerOutcome reduceProcesses(IProcessApi& api, const ReducerOptions& o, const std::atomic<bool>* cancel) {
    ReducerOutcome out;
    auto before = api.list();
    out.targeted = selectTargets(before, api.selfPid(), o);
    auto cancelled = [&] { return cancel && cancel->load(); };

    // 1) polite close so apps can flush state, 2) wait, 3) terminate whatever is left
    for (const auto& p : out.targeted) api.requestClose(p.pid);
    auto deadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(o.gracefulWaitMs);
    while (std::chrono::steady_clock::now() < deadline && !cancelled()) {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
        auto now = api.list();
        bool any = false;
        for (const auto& t : out.targeted)
            for (const auto& n : now)
                if (n.pid == t.pid && n.name == t.name) any = true;
        if (!any) break;
    }
    for (const auto& p : out.targeted) {
        if (cancelled()) break;
        std::string err;
        if (!api.terminate(p.pid, err) && !err.empty()) logWarn("procs", "terminate " + p.name + ": " + err);
    }
    std::this_thread::sleep_for(std::chrono::milliseconds(200));

    // Verify against a fresh snapshot (pid AND name, so a recycled pid is not mistaken for the process).
    auto after = api.list();
    for (const auto& t : out.targeted) {
        bool alive = false;
        for (const auto& n : after)
            if (n.pid == t.pid && n.name == t.name) alive = true;
        if (alive) out.stillRunning.push_back(t);
        else {
            out.closed.push_back(t);
            out.memoryFreedEstimate += t.workingSet;
        }
    }

    for (const auto& p : after) {
        if (!p.ownedByUser || p.pid == api.selfPid()) continue;
        std::string l = toLower(p.name), err;
        bool game = l.rfind("fivem", 0) == 0 || l.rfind("gta", 0) == 0;
        if (game && o.raiseGame) {
            if (api.setPriority(p.pid, Prio::High, err)) ++out.priorityRaised;
        } else if (o.lowerPriorityOfRest && !isAlwaysProtected(l) && !o.keepNames.count(l)) {
            if (api.setPriority(p.pid, Prio::Idle, err)) ++out.priorityLowered;
        }
    }
    return out;
}

// ------------------------------------------------------------------ real implementation
#ifdef _WIN32
namespace {

class WinProcessApi : public IProcessApi {
public:
    WinProcessApi() {
        ProcessIdToSessionId(GetCurrentProcessId(), &session_);
        HANDLE tok = nullptr;
        if (OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &tok)) {
            DWORD n = 0;
            GetTokenInformation(tok, TokenUser, nullptr, 0, &n);
            userBuf_.resize(n);
            if (!GetTokenInformation(tok, TokenUser, userBuf_.data(), n, &n)) userBuf_.clear();
            CloseHandle(tok);
        }
    }

    uint32_t selfPid() override { return GetCurrentProcessId(); }

    std::vector<ProcEntry> list() override {
        std::vector<ProcEntry> out;
        HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (snap == INVALID_HANDLE_VALUE) return out;
        PROCESSENTRY32W pe{};
        pe.dwSize = sizeof pe;
        if (Process32FirstW(snap, &pe)) {
            do {
                ProcEntry e;
                e.pid = pe.th32ProcessID;
                e.parentPid = pe.th32ParentProcessID;
                e.name = narrow(pe.szExeFile);
                DWORD sess = 0;
                bool sameSession = ProcessIdToSessionId(pe.th32ProcessID, &sess) && sess == session_ && sess != 0;
                HANDLE h = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pe.th32ProcessID);
                if (h) {
                    wchar_t buf[MAX_PATH * 2];
                    DWORD len = MAX_PATH * 2;
                    if (QueryFullProcessImageNameW(h, 0, buf, &len)) e.path = narrow(std::wstring(buf, len));
                    PROCESS_MEMORY_COUNTERS pmc{};
                    if (GetProcessMemoryInfo(h, &pmc, sizeof pmc)) e.workingSet = pmc.WorkingSetSize;
                    CloseHandle(h);
                    e.ownedByUser = sameSession && sameUser(pe.th32ProcessID);
                }
                out.push_back(std::move(e));
            } while (Process32NextW(snap, &pe));
        }
        CloseHandle(snap);
        return out;
    }

    bool requestClose(uint32_t pid) override {
        struct Arg { DWORD pid; bool sent; } a{pid, false};
        EnumWindows(
            [](HWND h, LPARAM lp) -> BOOL {
                auto* x = reinterpret_cast<Arg*>(lp);
                DWORD p = 0;
                GetWindowThreadProcessId(h, &p);
                if (p == x->pid && IsWindowVisible(h)) {
                    PostMessageW(h, WM_CLOSE, 0, 0);
                    x->sent = true;
                }
                return TRUE;
            },
            reinterpret_cast<LPARAM>(&a));
        return a.sent;
    }

    bool terminate(uint32_t pid, std::string& err) override {
        HANDLE h = OpenProcess(PROCESS_TERMINATE | SYNCHRONIZE, FALSE, pid);
        if (!h) {
            if (GetLastError() != ERROR_INVALID_PARAMETER) err = "OpenProcess failed (error " + std::to_string(GetLastError()) + ")";
            return false;
        }
        bool ok = TerminateProcess(h, 1) != 0;
        if (!ok) err = "TerminateProcess failed (error " + std::to_string(GetLastError()) + ")";
        else WaitForSingleObject(h, 1500);
        CloseHandle(h);
        return ok;
    }

    bool setPriority(uint32_t pid, Prio p, std::string& err) override {
        HANDLE h = OpenProcess(PROCESS_SET_INFORMATION, FALSE, pid);
        if (!h) {
            err = "access denied";
            return false;
        }
        DWORD cls = p == Prio::Idle ? IDLE_PRIORITY_CLASS : p == Prio::BelowNormal ? BELOW_NORMAL_PRIORITY_CLASS
                  : p == Prio::AboveNormal ? ABOVE_NORMAL_PRIORITY_CLASS : HIGH_PRIORITY_CLASS;
        bool ok = SetPriorityClass(h, cls) != 0;
        CloseHandle(h);
        return ok;
    }

    bool launch(const std::string& path, std::string& err) override {
        std::wstring w = widen(path);
        SHELLEXECUTEINFOW sei{};
        sei.cbSize = sizeof sei;
        sei.lpVerb = L"open";
        sei.lpFile = w.c_str();
        sei.nShow = SW_SHOWNORMAL;
        sei.fMask = SEE_MASK_NOASYNC;
        if (!ShellExecuteExW(&sei)) {
            err = "ShellExecute failed (error " + std::to_string(GetLastError()) + ")";
            return false;
        }
        return true;
    }

private:
    bool sameUser(DWORD pid) {
        if (userBuf_.empty()) return false;
        HANDLE h = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
        if (!h) return false;
        HANDLE tok = nullptr;
        bool same = false;
        if (OpenProcessToken(h, TOKEN_QUERY, &tok)) {
            DWORD n = 0;
            GetTokenInformation(tok, TokenUser, nullptr, 0, &n);
            std::vector<BYTE> buf(n);
            if (n && GetTokenInformation(tok, TokenUser, buf.data(), n, &n))
                same = EqualSid(reinterpret_cast<TOKEN_USER*>(buf.data())->User.Sid,
                                reinterpret_cast<TOKEN_USER*>(userBuf_.data())->User.Sid) != 0;
            CloseHandle(tok);
        }
        CloseHandle(h);
        return same;
    }
    DWORD session_ = 0;
    std::vector<BYTE> userBuf_;
};

}  // namespace

std::unique_ptr<IProcessApi> makeSystemProcessApi() { return std::make_unique<WinProcessApi>(); }

#else

namespace {
// Development stub: can list, but refuses to touch any process.
class StubProcessApi : public IProcessApi {
public:
    uint32_t selfPid() override { return static_cast<uint32_t>(getpid()); }
    std::vector<ProcEntry> list() override { return {}; }
    bool requestClose(uint32_t) override { return false; }
    bool terminate(uint32_t, std::string& err) override { err = "disabled on non-Windows builds"; return false; }
    bool setPriority(uint32_t, Prio, std::string& err) override { err = "disabled on non-Windows builds"; return false; }
    bool launch(const std::string&, std::string& err) override { err = "disabled on non-Windows builds"; return false; }
};
}  // namespace
std::unique_ptr<IProcessApi> makeSystemProcessApi() { return std::make_unique<StubProcessApi>(); }

#endif

}  // namespace fmo
