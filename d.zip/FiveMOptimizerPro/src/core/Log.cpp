#include "Log.h"

namespace fmo {

Logger& Logger::instance() {
    static Logger l;
    return l;
}

void Logger::setFile(const fs::path& file) {
    std::lock_guard<std::mutex> g(m_);
    if (out_.is_open()) out_.close();
    std::error_code ec;
    fs::create_directories(file.parent_path(), ec);
    out_.open(file, std::ios::app);
}

void Logger::setSink(std::function<void(LogLevel, const std::string&)> sink) {
    std::lock_guard<std::mutex> g(m_);
    sink_ = std::move(sink);
}

void Logger::log(LogLevel level, const std::string& component, const std::string& message) {
    const char* lv = level == LogLevel::Info ? "INFO" : level == LogLevel::Warn ? "WARN" : "ERROR";
    std::string line = isoNow() + "\t" + lv + "\t" + component + "\t" + message;
    std::lock_guard<std::mutex> g(m_);
    if (out_.is_open()) {
        out_ << line << '\n';
        out_.flush();
    }
    if (sink_) sink_(level, line);
}

}  // namespace fmo
