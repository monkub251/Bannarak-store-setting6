#include "Network.h"

#include <algorithm>
#include <chrono>
#include <cstring>

#include "Log.h"

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <winsock2.h>
#include <ws2tcpip.h>
#include <iphlpapi.h>
#include <windows.h>
using sock_t = SOCKET;
static void closeSock(sock_t s) { closesocket(s); }
static const sock_t kBadSock = INVALID_SOCKET;
#else
#include <arpa/inet.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <poll.h>
#include <sys/socket.h>
#include <unistd.h>
using sock_t = int;
static void closeSock(sock_t s) { close(s); }
static const sock_t kBadSock = -1;
#endif

namespace fmo {
namespace net {

std::vector<DnsProvider> providers() {
    return {{"Google Public DNS", {"8.8.8.8", "8.8.4.4"}},
            {"Cloudflare", {"1.1.1.1", "1.0.0.1"}},
            {"Quad9", {"9.9.9.9", "149.112.112.112"}}};
}

bool isValidIpv4(const std::string& s) {
    in_addr a{};
    return inet_pton(AF_INET, s.c_str(), &a) == 1;
}

#ifdef _WIN32
static void ensureWinsock() {
    static bool done = [] {
        WSADATA d;
        return WSAStartup(MAKEWORD(2, 2), &d) == 0;
    }();
    (void)done;
}
#else
static void ensureWinsock() {}
#endif

static double median(std::vector<double> v) {
    if (v.empty()) return -1;
    std::sort(v.begin(), v.end());
    return v[v.size() / 2];
}

static std::vector<unsigned char> buildQuery(const std::string& name, unsigned short id) {
    std::vector<unsigned char> q = {static_cast<unsigned char>(id >> 8), static_cast<unsigned char>(id & 0xFF),
                                    0x01, 0x00, 0, 1, 0, 0, 0, 0, 0, 0};
    size_t start = 0;
    while (start <= name.size()) {
        size_t dot = name.find('.', start);
        std::string label = name.substr(start, dot == std::string::npos ? std::string::npos : dot - start);
        q.push_back(static_cast<unsigned char>(label.size()));
        q.insert(q.end(), label.begin(), label.end());
        if (dot == std::string::npos) break;
        start = dot + 1;
    }
    q.push_back(0);
    q.insert(q.end(), {0, 1, 0, 1});  // type A, class IN
    return q;
}

Probe probeDns(const std::string& label, const std::string& server, int attempts, int timeoutMs) {
    ensureWinsock();
    Probe p;
    p.label = label;
    p.samples = attempts;
    static const char* names[] = {"example.com", "www.google.com", "cloudflare.com", "microsoft.com", "wikipedia.org"};
    std::vector<double> times;
    int failures = 0;
    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(53);
    if (inet_pton(AF_INET, server.c_str(), &addr.sin_addr) != 1) return p;
    for (int i = 0; i < attempts; ++i) {
        sock_t s = socket(AF_INET, SOCK_DGRAM, 0);
        if (s == kBadSock) {
            ++failures;
            continue;
        }
#ifdef _WIN32
        DWORD tv = static_cast<DWORD>(timeoutMs);
        setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char*>(&tv), sizeof tv);
#else
        timeval tv{timeoutMs / 1000, (timeoutMs % 1000) * 1000};
        setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
#endif
        unsigned short id = static_cast<unsigned short>(0x4D00 + i);
        auto q = buildQuery(names[i % 5], id);
        auto t0 = std::chrono::steady_clock::now();
        bool ok = false;
        if (sendto(s, reinterpret_cast<const char*>(q.data()), static_cast<int>(q.size()), 0,
                   reinterpret_cast<sockaddr*>(&addr), sizeof addr) > 0) {
            unsigned char buf[512];
            int n = static_cast<int>(recv(s, reinterpret_cast<char*>(buf), sizeof buf, 0));
            // Valid reply: matching id, QR bit set, RCODE 0 or 3 (NXDOMAIN still proves the resolver answered).
            if (n >= 12 && buf[0] == (id >> 8) && buf[1] == (id & 0xFF) && (buf[2] & 0x80) && ((buf[3] & 0x0F) == 0 || (buf[3] & 0x0F) == 3))
                ok = true;
        }
        double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
        closeSock(s);
        if (ok) times.push_back(ms); else ++failures;
    }
    p.medianMs = median(times);
    p.lossPercent = attempts ? 100.0 * failures / attempts : 100;
    return p;
}

Probe probeTcp(const std::string& label, const std::string& ip, unsigned short port, int attempts, int timeoutMs) {
    ensureWinsock();
    Probe p;
    p.label = label;
    p.samples = attempts;
    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    if (inet_pton(AF_INET, ip.c_str(), &addr.sin_addr) != 1) return p;
    std::vector<double> times;
    int failures = 0;
    for (int i = 0; i < attempts; ++i) {
        sock_t s = socket(AF_INET, SOCK_STREAM, 0);
        if (s == kBadSock) {
            ++failures;
            continue;
        }
#ifdef _WIN32
        u_long nb = 1;
        ioctlsocket(s, FIONBIO, &nb);
#else
        fcntl(s, F_SETFL, fcntl(s, F_GETFL, 0) | O_NONBLOCK);
#endif
        auto t0 = std::chrono::steady_clock::now();
        int r = connect(s, reinterpret_cast<sockaddr*>(&addr), sizeof addr);
        bool ok = false;
        if (r == 0) {
            ok = true;
        } else {
            fd_set w, e;
            FD_ZERO(&w);
            FD_ZERO(&e);
            FD_SET(s, &w);
            FD_SET(s, &e);
            timeval tv{timeoutMs / 1000, (timeoutMs % 1000) * 1000};
            if (select(static_cast<int>(s) + 1, nullptr, &w, &e, &tv) > 0 && FD_ISSET(s, &w)) {
                int err = 0;
#ifdef _WIN32
                int len = sizeof err;
                getsockopt(s, SOL_SOCKET, SO_ERROR, reinterpret_cast<char*>(&err), &len);
#else
                socklen_t len = sizeof err;
                getsockopt(s, SOL_SOCKET, SO_ERROR, &err, &len);
#endif
                ok = err == 0;
            }
        }
        double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
        closeSock(s);
        if (ok) times.push_back(ms); else ++failures;
    }
    p.medianMs = median(times);
    p.lossPercent = attempts ? 100.0 * failures / attempts : 100;
    return p;
}

// ============================================================================ adapters / DNS changes
#ifdef _WIN32

std::vector<Adapter> adapters(IRegistry& reg) {
    std::vector<Adapter> out;
    ULONG size = 0;
    ULONG flags = GAA_FLAG_INCLUDE_GATEWAYS | GAA_FLAG_SKIP_MULTICAST | GAA_FLAG_SKIP_ANYCAST;
    GetAdaptersAddresses(AF_INET, flags, nullptr, nullptr, &size);
    std::vector<unsigned char> buf(size + 1024);
    auto* first = reinterpret_cast<IP_ADAPTER_ADDRESSES*>(buf.data());
    if (GetAdaptersAddresses(AF_INET, flags, nullptr, first, &size) != NO_ERROR) return out;
    for (auto* a = first; a; a = a->Next) {
        if (a->OperStatus != IfOperStatusUp || a->IfType == IF_TYPE_SOFTWARE_LOOPBACK || a->IfType == IF_TYPE_TUNNEL)
            continue;
        Adapter ad;
        ad.guid = a->AdapterName;
        ad.friendlyName = narrow(a->FriendlyName ? a->FriendlyName : L"");
        ad.description = narrow(a->Description ? a->Description : L"");
        ad.ifIndex = a->IfIndex;
        ad.mtu = a->Mtu;
        ad.up = true;
        ad.dhcpIpv4 = (a->Flags & IP_ADAPTER_DHCP_ENABLED) != 0;
        for (auto* d = a->FirstDnsServerAddress; d; d = d->Next) {
            if (d->Address.lpSockaddr && d->Address.lpSockaddr->sa_family == AF_INET) {
                char ip[INET_ADDRSTRLEN];
                inet_ntop(AF_INET, &reinterpret_cast<sockaddr_in*>(d->Address.lpSockaddr)->sin_addr, ip, sizeof ip);
                ad.dnsServers.push_back(ip);
            }
        }
        for (auto* g = a->FirstGatewayAddress; g; g = g->Next) {
            if (g->Address.lpSockaddr && g->Address.lpSockaddr->sa_family == AF_INET) {
                char ip[INET_ADDRSTRLEN];
                inet_ntop(AF_INET, &reinterpret_cast<sockaddr_in*>(g->Address.lpSockaddr)->sin_addr, ip, sizeof ip);
                ad.gateway = ip;
                break;
            }
        }
        RegRead ns = reg.read(Hive::HKLM,
                              std::string("SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters\\Interfaces\\") + ad.guid,
                              "NameServer");
        ad.dnsStatic = ns.state == RegRead::Found && ns.value.type == RegType::String && !trim(ns.value.str).empty();
        out.push_back(std::move(ad));
    }
    return out;
}

static std::string psExe() { return systemTool("WindowsPowerShell\\v1.0\\powershell.exe"); }

static bool runPs(const std::string& script, std::string& err) {
    ProcResult r = runProcess({psExe(), "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", script}, 30000);
    if (!r.started) {
        err = r.error;
        return false;
    }
    if (r.timedOut || r.exitCode != 0) {
        err = r.timedOut ? "PowerShell timed out" : ("PowerShell exit code " + std::to_string(r.exitCode) + ": " + trim(r.output));
        return false;
    }
    return true;
}

bool applyDns(unsigned ifIndex, const std::vector<std::string>& servers, std::string& err) {
    if (servers.empty() || servers.size() > 4) {
        err = "invalid server list";
        return false;
    }
    std::string list;
    for (const auto& s : servers) {
        if (!isValidIpv4(s)) {
            err = "invalid IPv4 address";
            return false;
        }
        list += (list.empty() ? "'" : ",'") + s + "'";
    }
    return runPs("Set-DnsClientServerAddress -InterfaceIndex " + std::to_string(ifIndex) + " -ServerAddresses (" + list + ")", err);
}

bool restoreDns(unsigned ifIndex, bool wasStatic, const std::vector<std::string>& servers, std::string& err) {
    if (!wasStatic)
        return runPs("Set-DnsClientServerAddress -InterfaceIndex " + std::to_string(ifIndex) + " -ResetServerAddresses", err);
    return applyDns(ifIndex, servers, err);
}

bool flushDnsCache(std::string& err) {
    ProcResult r = runProcess({systemTool("ipconfig.exe"), "/flushdns"}, 10000);
    if (!r.started || r.exitCode != 0) {
        err = r.started ? "ipconfig exit code " + std::to_string(r.exitCode) : r.error;
        return false;
    }
    return true;
}

std::string tcpGlobalSettings() {
    ProcResult r = runProcess({systemTool("netsh.exe"), "int", "tcp", "show", "global"}, 10000);
    return r.started ? r.output : std::string();
}

#else

std::vector<Adapter> adapters(IRegistry&) { return {}; }
bool applyDns(unsigned, const std::vector<std::string>&, std::string& err) { err = "not supported on this platform"; return false; }
bool restoreDns(unsigned, bool, const std::vector<std::string>&, std::string& err) { err = "not supported on this platform"; return false; }
bool flushDnsCache(std::string& err) { err = "not supported on this platform"; return false; }
std::string tcpGlobalSettings() { return {}; }

#endif

const Adapter* primaryAdapter(const std::vector<Adapter>& a) {
    for (const auto& x : a)
        if (!x.gateway.empty()) return &x;
    return a.empty() ? nullptr : &a[0];
}

}  // namespace net
}  // namespace fmo
