#include "Tweaks.h"

#include <map>

namespace fmo {

const char* profileDisplayName(uint32_t bit) {
    switch (bit) {
        case ProfileImpact: return "VANTA IMPACT";
        case ProfileFlow: return "ONYX FLOW";
        case ProfileBase: return "CORE";
        default: return "OPTIONAL";
    }
}

static TweakDef T(const char* id, const char* title, const char* why, Hive h, const std::string& key, const std::string& name,
                  RegValue v, uint32_t profiles, bool admin = false) {
    TweakDef t;
    t.id = id;
    t.title = title;
    t.rationale = why;
    t.hive = h;
    t.key = key;
    t.name = name;
    t.desired = std::move(v);
    t.profiles = profiles;
    t.needsAdmin = admin;
    return t;
}

std::vector<TweakDef> tweakCatalog() {
    const char* sysProfile = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile";
    std::vector<TweakDef> c;

    // ------------------------------------------------------------------ CORE
    {
        auto t = T("gamemode", "Windows Game Mode on",
                   "Game Mode (Settings > Gaming) prioritises the foreground game and limits Windows Update driver "
                   "installs and notifications while playing.",
                   Hive::HKCU, "Software\\Microsoft\\GameBar", "AutoGameModeEnabled", RegValue::dw(1), ProfileBase);
        t.minBuild = 15063;
        c.push_back(t);
    }

    // ------------------------------------------------------------------ shared by both profiles
    const uint32_t both = ProfileImpact | ProfileFlow;
    c.push_back(T("gamedvr_capture", "Background game recording off",
                  "Xbox Game Bar background capture (Settings > Captures) encodes video while you play and can add "
                  "frame-time spikes. Turn it back on in Settings if you record clips.",
                  Hive::HKCU, "Software\\Microsoft\\Windows\\CurrentVersion\\GameDVR", "AppCaptureEnabled",
                  RegValue::dw(0), both));
    c.push_back(T("gamedvr_store", "Game DVR flag off", "Companion switch of the same Captures setting (GameConfigStore).",
                  Hive::HKCU, "System\\GameConfigStore", "GameDVR_Enabled", RegValue::dw(0), both));
    {
        auto t = T("policy_gamedvr", "Policy: Game recording and broadcasting off",
                   "Group Policy 'Windows Components > Windows Game Recording and Broadcasting'. Applied only on "
                   "editions that honour policy.",
                   Hive::HKLM, "SOFTWARE\\Policies\\Microsoft\\Windows\\GameDVR", "AllowGameDVR", RegValue::dw(0),
                   both, true);
        t.policy = true;
        c.push_back(t);
    }
    c.push_back(T("sysresp", "Multimedia scheduler responsiveness 10%",
                  "SystemResponsiveness is the share of CPU reserved for low-priority background tasks by the "
                  "Multimedia Class Scheduler (Windows default 20).",
                  Hive::HKLM, sysProfile, "SystemResponsiveness", RegValue::dw(10), both, true));

    // ------------------------------------------------------------------ VANTA IMPACT (melee / impact feel)
    c.push_back(T("mmcss_games_priority", "Games task thread priority 6",
                  "MMCSS 'Games' task priority (default 2). Gives the game's threads more consistent CPU scheduling "
                  "against background work, which reduces frame-time variance.",
                  Hive::HKLM, std::string(sysProfile) + "\\Tasks\\Games", "Priority", RegValue::dw(6),
                  ProfileImpact, true));
    c.push_back(T("mmcss_games_category", "Games task scheduling category High",
                  "MMCSS 'Games' scheduling category (default Medium).", Hive::HKLM,
                  std::string(sysProfile) + "\\Tasks\\Games", "Scheduling Category", RegValue::sz("High"),
                  ProfileImpact, true));

    // ------------------------------------------------------------------ ONYX FLOW (knife / movement / emote feel)
    {
        auto t = T("prio_sep", "Short, fixed foreground quantum (0x26)",
                   "Win32PrioritySeparation: shorter fixed time slices with a 3:1 foreground boost keep the active "
                   "window responsive under background load. Effect is small and workload dependent.",
                   Hive::HKLM, "SYSTEM\\CurrentControlSet\\Control\\PriorityControl", "Win32PrioritySeparation",
                   RegValue::dw(0x26), ProfileFlow, true);
        t.restartNote = true;
        c.push_back(t);
    }
    {
        auto t = T("bgapps", "Background apps off (Windows 10)",
                   "Stops UWP apps from running in the background (Settings > Privacy > Background apps).",
                   Hive::HKCU, "Software\\Microsoft\\Windows\\CurrentVersion\\BackgroundAccessApplications",
                   "GlobalUserDisabled", RegValue::dw(1), ProfileFlow);
        t.maxBuild = 19045;  // the setting moved to per-app controls on Windows 11
        c.push_back(t);
    }

    // ------------------------------------------------------------------ opt-in only
    for (const char* n : {"MouseSpeed", "MouseThreshold1", "MouseThreshold2"}) {
        auto t = T((std::string("ptr_") + n).c_str(), "Disable 'Enhance pointer precision'",
                   "Removes Windows pointer acceleration so mouse movement is 1:1. This changes how your mouse feels, "
                   "so it is never applied unless you enable it.",
                   Hive::HKCU, "Control Panel\\Mouse", n, RegValue::sz("0"), ProfileOptIn);
        t.restartNote = true;
        c.push_back(t);
    }
    return c;
}

std::vector<TweakDef> dynamicTweaks(const FiveMInfo& fivem) {
    std::vector<TweakDef> out;
    if (!fivem.installed) return out;
    std::vector<fs::path> exes = fivem.gameExes;
    if (!fivem.exe.empty()) exes.push_back(fivem.exe);
    for (const auto& e : exes) {
        std::error_code ec;
        if (!fs::is_regular_file(e, ec)) continue;
        TweakDef t = T("gpupref", ("High-performance GPU for " + pathToUtf8(e.filename())).c_str(),
                       "Windows Graphics Settings preference (GpuPreference=2) for this executable; picks the "
                       "discrete GPU on hybrid systems and is harmless on single-GPU PCs.",
                       Hive::HKCU, "Software\\Microsoft\\DirectX\\UserGpuPreferences", "", RegValue::sz("GpuPreference=2;"),
                       ProfileBase);
        t.id = "gpupref:" + toLower(pathToUtf8(e.filename()));
        t.name = pathToUtf8(e);
        t.minBuild = 17134;
        out.push_back(t);
    }
    return out;
}

Plan buildPlan(const std::vector<TweakDef>& catalog, uint32_t active, const std::set<std::string>& optIn,
               const SysInfo& sys, bool elevated) {
    Plan plan;
    struct Group {
        std::vector<const TweakDef*> defs;
        std::vector<uint32_t> bits;
    };
    std::map<std::string, Group> groups;
    std::vector<std::string> order;

    for (const auto& d : catalog) {
        uint32_t hit = d.profiles & (ProfileBase | active);
        bool chosen = hit != 0;
        uint32_t via = hit;
        if (!chosen && (d.profiles & ProfileOptIn) && optIn.count(d.id)) {
            chosen = true;
            via = ProfileOptIn;
        }
        if (!chosen) continue;
        std::string gk = std::string(hiveName(d.hive)) + "|" + toLower(d.key) + "|" + toLower(d.name);
        if (!groups.count(gk)) order.push_back(gk);
        groups[gk].defs.push_back(&d);
        groups[gk].bits.push_back(via);
    }

    for (const auto& gk : order) {
        const Group& g = groups[gk];
        const TweakDef& first = *g.defs[0];
        bool conflict = false;
        for (auto* d : g.defs)
            if (d->desired != first.desired) conflict = true;
        std::string sources;
        for (size_t i = 0; i < g.defs.size(); ++i) {
            for (uint32_t b : {uint32_t(ProfileBase), uint32_t(ProfileImpact), uint32_t(ProfileFlow), uint32_t(ProfileOptIn)})
                if (g.bits[i] & b) {
                    std::string n = profileDisplayName(b);
                    if (sources.find(n) == std::string::npos) sources += (sources.empty() ? "" : " + ") + n;
                }
        }
        if (conflict) {
            plan.notes.push_back({"Profiles", first.id, first.title, Status::Warning,
                                  "Conflict: " + sources + " request different values for " + first.key + "\\" +
                                      first.name + ". Neither was applied."});
            continue;
        }
        const TweakDef& d = first;
        if (d.minBuild && sys.windows && sys.build < d.minBuild) {
            plan.notes.push_back({"Registry", d.id, d.title, Status::Skipped,
                                  "Requires Windows build " + std::to_string(d.minBuild) + " or newer (this PC: " +
                                      std::to_string(sys.build) + ")."});
            continue;
        }
        if (d.maxBuild && sys.windows && sys.build > d.maxBuild) {
            plan.notes.push_back({"Registry", d.id, d.title, Status::Skipped,
                                  "Not applicable on this Windows version (setting was replaced in newer builds)."});
            continue;
        }
        if (d.policy && sys.homeEdition) {
            plan.notes.push_back({"Policy", d.id, d.title, Status::Skipped,
                                  "Windows Home does not support Group Policy; the value would be ignored."});
            continue;
        }
        if (d.needsAdmin && !elevated) {
            plan.notes.push_back({d.policy ? "Policy" : "Registry", d.id, d.title, Status::Skipped,
                                  "Requires Administrator. Use 'Relaunch as Administrator' and run again."});
            continue;
        }
        plan.items.push_back({d, sources});
    }
    return plan;
}

}  // namespace fmo
