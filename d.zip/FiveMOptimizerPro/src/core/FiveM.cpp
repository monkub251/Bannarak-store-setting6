#include "FiveM.h"

#include <algorithm>
#include <sstream>

namespace fmo {

FiveMInfo detectFiveM(const fs::path& localAppData) {
    FiveMInfo info;
    if (localAppData.empty()) return info;
    std::error_code ec;
    info.root = localAppData / "FiveM";
    info.appDir = info.root / "FiveM.app";
    info.exe = info.root / "FiveM.exe";
    bool hasExe = fs::is_regular_file(info.exe, ec);
    bool hasApp = fs::is_directory(info.appDir, ec);
    info.installed = hasExe || hasApp;
    if (hasApp) {
        for (auto& e : fs::directory_iterator(info.appDir, ec)) {
            std::string n = toLower(e.path().filename().string());
            const std::string suffix = "_gtaprocess.exe";
            if (n.rfind("fivem", 0) == 0 && n.size() > suffix.size() &&
                n.compare(n.size() - suffix.size(), suffix.size(), suffix) == 0)
                info.gameExes.push_back(e.path());
        }
    }
    return info;
}

bool isFiveMRunning(const std::vector<std::string>& names) {
    for (const auto& n : names) {
        std::string l = toLower(n);
        if (l.rfind("fivem", 0) == 0) return true;
    }
    return false;
}

bool isFiveMRunning() { return isFiveMRunning(runningProcessNames()); }

std::vector<fs::path> fivemCacheDirs(const FiveMInfo& info) {
    std::vector<fs::path> dirs;
    if (info.appDir.empty()) return dirs;
    for (const char* sub : {"cache", "server-cache", "server-cache-priv"}) dirs.push_back(info.appDir / "data" / sub);
    return dirs;
}

std::vector<Bottleneck> analyzeSnapshot(const LoadSnapshot& l, const SysInfo& s, bool running) {
    std::vector<Bottleneck> out;
    std::ostringstream o;
    if (l.cpuPercent >= 0) {
        o << "CPU usage right now: " << static_cast<int>(l.cpuPercent + 0.5) << "% (measured over 0.5 s).";
        out.push_back({l.cpuPercent > 85 ? "warn" : "info", o.str()});
        if (l.cpuPercent > 85 && !running)
            out.push_back({"warn", "The CPU is already busy with FiveM closed: background processes are competing "
                                   "for CPU time. Review the list of heaviest processes below."});
    }
    if (l.ramPercent >= 0) {
        std::ostringstream r;
        r << "Memory in use: " << static_cast<int>(l.ramPercent + 0.5) << "% of " << formatBytes(l.ramTotal) << ".";
        out.push_back({l.ramPercent > 85 ? "warn" : "info", r.str()});
        if (l.ramPercent > 85)
            out.push_back({"warn", "High memory pressure can cause paging and stutter. Close heavy applications."});
    }
    if (s.ramBytes && s.ramBytes < (8ull << 30))
        out.push_back({"warn", "Less than 8 GB of RAM installed: GTA V / FiveM may page to disk on busy servers."});
    if (s.sysDriveTotal && s.sysDriveFree * 10 < s.sysDriveTotal)
        out.push_back({"warn", "System drive has under 10% free space; this can slow shader/cache writes."});
    out.push_back({"info", "This is a single snapshot. It cannot measure FPS or frame time; see the note on frame-time "
                           "monitoring."});
    return out;
}

std::vector<std::string> knownBackgroundHogs(const std::vector<std::string>& names) {
    static const char* hogs[] = {"chrome.exe", "msedge.exe", "firefox.exe", "OneDrive.exe", "Discord.exe",
                                 "Spotify.exe", "Teams.exe", "ms-teams.exe", "Steam.exe", "EpicGamesLauncher.exe"};
    std::vector<std::string> found;
    for (const char* h : hogs)
        for (const auto& n : names)
            if (iequals(n, h)) {
                if (std::find(found.begin(), found.end(), h) == found.end()) found.push_back(h);
                break;
            }
    return found;
}

}  // namespace fmo
