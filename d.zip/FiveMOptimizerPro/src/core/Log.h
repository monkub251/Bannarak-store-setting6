#pragma once
#include <functional>
#include <fstream>
#include <mutex>
#include <string>

#include "Util.h"

namespace fmo {

enum class LogLevel { Info, Warn, Error };

// Structured, thread-safe logger: "<iso time>\t<LEVEL>\t<component>\t<message>".
class Logger {
public:
    static Logger& instance();
    void setFile(const fs::path& file);
    void setSink(std::function<void(LogLevel, const std::string&)> sink);
    void log(LogLevel level, const std::string& component, const std::string& message);

private:
    std::mutex m_;
    std::ofstream out_;
    std::function<void(LogLevel, const std::string&)> sink_;
};

inline void logInfo(const std::string& c, const std::string& m) { Logger::instance().log(LogLevel::Info, c, m); }
inline void logWarn(const std::string& c, const std::string& m) { Logger::instance().log(LogLevel::Warn, c, m); }
inline void logError(const std::string& c, const std::string& m) { Logger::instance().log(LogLevel::Error, c, m); }

}  // namespace fmo
