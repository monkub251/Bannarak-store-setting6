#pragma once
#include <string>
#include <vector>

#include "Platform.h"
#include "Registry.h"

namespace fmo {
namespace net {

struct Adapter {
    std::string guid, friendlyName, description;
    unsigned ifIndex = 0;
    unsigned mtu = 0;
    bool up = false;
    bool dhcpIpv4 = false;
    bool dnsStatic = false;  // DNS servers were configured manually (not obtained automatically)
    std::vector<std::string> dnsServers;
    std::string gateway;
};

struct DnsProvider {
    std::string name;
    std::vector<std::string> servers;
};
// Well-known public resolvers. Their reachability is verified at run time by the benchmark.
std::vector<DnsProvider> providers();

struct Probe {
    std::string label;
    double medianMs = -1;  // -1 = no successful reply
    double lossPercent = 100;
    int samples = 0;
};

std::vector<Adapter> adapters(IRegistry& reg);  // active (up, non-loopback) IPv4 adapters; Windows only
const Adapter* primaryAdapter(const std::vector<Adapter>& a);  // first adapter with a gateway

// UDP DNS query round-trip time to `server` (port 53) for a few well-known names.
Probe probeDns(const std::string& label, const std::string& server, int attempts = 5, int timeoutMs = 1200);
// TCP connect time to host:443 as a latency/packet-loss indicator (connect failures counted as loss).
Probe probeTcp(const std::string& label, const std::string& ip, unsigned short port, int attempts = 5, int timeoutMs = 1200);

bool isValidIpv4(const std::string& s);

// Changes DNS for one adapter via PowerShell Set-DnsClientServerAddress (interface index + validated IPv4 only).
bool applyDns(unsigned ifIndex, const std::vector<std::string>& servers, std::string& err);
// Restores either automatic (DHCP) DNS or a previous static list.
bool restoreDns(unsigned ifIndex, bool wasStatic, const std::vector<std::string>& servers, std::string& err);
bool flushDnsCache(std::string& err);
std::string tcpGlobalSettings();  // read-only `netsh int tcp show global`

}  // namespace net
}  // namespace fmo
