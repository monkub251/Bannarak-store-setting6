#pragma once
#include <cstdint>
#include <string>
#include <vector>

#include "Registry.h"
#include "Util.h"

namespace fmo {

// ------------------------------------------------------------------ processes
struct ProcResult {
    bool started = false;
    bool timedOut = false;
    int exitCode = -1;
    std::string output;  // stdout + stderr, raw bytes
    std::string error;   // why it could not start
};

// Runs a program WITHOUT a shell. argv[0] must be an absolute path to the executable.
// Arguments are quoted per the Windows CRT rules, so no argument can inject another.
ProcResult runProcess(const std::vector<std::string>& argv, int timeoutMs = 20000);

// Absolute path of a System32 tool (powercfg.exe, ipconfig.exe ...). Empty on non-Windows.
std::string systemTool(const std::string& exeName);

// ------------------------------------------------------------------ environment
bool isWindows();
bool isElevated();
// Relaunches this executable with UAC ("runas"). Returns true when the request was accepted.
bool relaunchElevated(const std::string& arguments);
bool isDesktopPc();  // false when a battery is present
// Asks Windows to restart in `delaySeconds` (cancellable with `shutdown /a`). Call only after user consent.
bool scheduleRestart(int delaySeconds, std::string& err);

struct SysInfo {
    bool windows = false;
    std::string osName, edition, displayVersion, arch;
    unsigned build = 0;
    std::string cpu;
    unsigned logicalCores = 0;
    uint64_t ramBytes = 0, ramFreeBytes = 0;
    std::vector<std::string> gpus;
    uint64_t sysDriveTotal = 0, sysDriveFree = 0;
    bool desktop = true;
    bool homeEdition = false;  // Group Policy Editor is not available on Home
    bool elevated = false;
};
SysInfo detectSystem(IRegistry& reg);

// ------------------------------------------------------------------ processes & load snapshot
struct ProcInfo {
    uint32_t pid = 0;
    std::string name;
    uint64_t workingSetBytes = 0;
};
std::vector<std::string> runningProcessNames();
std::vector<ProcInfo> topProcessesByMemory(size_t n);

struct LoadSnapshot {
    double cpuPercent = -1;  // measured over a short interval; -1 when unavailable
    double ramPercent = -1;
    uint64_t ramTotal = 0, ramFree = 0;
};
LoadSnapshot sampleLoad(int intervalMs = 500);

}  // namespace fmo
