#pragma once
#include <atomic>
#include <cstdint>
#include <functional>
#include <memory>
#include <set>
#include <string>
#include <vector>

namespace fmo {

struct ProcEntry {
    uint32_t pid = 0, parentPid = 0;
    std::string name;  // exe file name, e.g. chrome.exe
    std::string path;  // full image path when readable
    uint64_t workingSet = 0;
    bool ownedByUser = false;  // same user AND same session as this app
};

enum class Prio { Idle, BelowNormal, AboveNormal, High };

// Everything that touches real processes goes through this interface so the selection and
// reporting logic can be unit-tested with a fake.
class IProcessApi {
public:
    virtual ~IProcessApi() = default;
    virtual std::vector<ProcEntry> list() = 0;
    virtual bool requestClose(uint32_t pid) = 0;  // polite WM_CLOSE to the process' windows
    virtual bool terminate(uint32_t pid, std::string& err) = 0;
    virtual bool setPriority(uint32_t pid, Prio p, std::string& err) = 0;
    virtual bool launch(const std::string& path, std::string& err) = 0;
    virtual uint32_t selfPid() = 0;
};
std::unique_ptr<IProcessApi> makeSystemProcessApi();  // real on Windows; read-only stub elsewhere

struct ReducerOptions {
    bool maxMode = false;                // false: only well-known background apps; true: everything not protected
    std::set<std::string> keepNames;     // lowercase exe names the user never wants closed (e.g. discord.exe)
    bool lowerPriorityOfRest = true;     // remaining background processes -> idle priority
    bool raiseGame = true;               // FiveM / GTA processes -> high priority
    int gracefulWaitMs = 1500;
};

bool isAlwaysProtected(const std::string& exeName);
// Pure function: which processes would be closed.
std::vector<ProcEntry> selectTargets(const std::vector<ProcEntry>& all, uint32_t selfPid, const ReducerOptions& o);
// Top-level applications among the targets (parent not also a target) that are worth relaunching on restore.
std::vector<ProcEntry> relaunchRoots(const std::vector<ProcEntry>& targets);

struct ReducerOutcome {
    std::vector<ProcEntry> targeted, closed, stillRunning;
    int priorityLowered = 0, priorityRaised = 0;
    uint64_t memoryFreedEstimate = 0;  // sum of working sets of the processes that are gone (an estimate)
};
ReducerOutcome reduceProcesses(IProcessApi& api, const ReducerOptions& o, const std::atomic<bool>* cancel = nullptr);

}  // namespace fmo
