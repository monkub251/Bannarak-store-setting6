#pragma once
#include <string>
#include <vector>

namespace fmo {

// ------------------------------------------------------------------ Windows services (conservative)
namespace services {

struct Candidate {
    std::string name, display, reason;
};

// Short, curated list of optional services with no role in gaming, networking or security.
// Nothing outside this list is ever touched.
std::vector<Candidate> candidates();
// MAX BOOST list: telemetry, indexing, Xbox and other background services. Applied only in max mode
// (set to Disabled and stopped); every original start type / running state is backed up for Restore.
std::vector<Candidate> aggressiveCandidates();
// Hard deny-list: these are never modified even if someone adds them to the candidate list.
bool isProtected(const std::string& name);

struct State {
    bool installed = false;
    unsigned startType = 0;   // 2 auto, 3 manual, 4 disabled
    bool delayedAuto = false;
    bool running = false;
    bool hasRunningDependents = false;
    std::string display;
};
State query(const std::string& name);
// Sets startType (never stops a running service). Restores delayed-auto when startType == 2.
bool setStartType(const std::string& name, unsigned startType, bool delayedAuto, std::string& err);
bool stop(const std::string& name, std::string& err);   // waits up to ~8 s for the service to stop
bool start(const std::string& name, std::string& err);

}  // namespace services

// ------------------------------------------------------------------ power plan
namespace power {
extern const char* kHighPerformanceGuid;
bool activeScheme(std::string& guid, std::string& err);
bool setActive(const std::string& guid, std::string& err);
}  // namespace power

}  // namespace fmo
