#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace fmo {

enum class Status {
    Applied,    // changed and verified
    AlreadyOk,  // nothing to do
    Skipped,    // not applicable / not permitted / user opted out
    Warning,    // partially done or needs attention
    Failed      // attempted and failed, or verification failed
};

inline const char* statusName(Status s) {
    switch (s) {
        case Status::Applied: return "APPLIED";
        case Status::AlreadyOk: return "ALREADY OK";
        case Status::Skipped: return "SKIPPED";
        case Status::Warning: return "WARNING";
        case Status::Failed: return "FAILED";
    }
    return "?";
}

struct TaskResult {
    std::string category;
    std::string id;
    std::string title;
    Status status = Status::Skipped;
    std::string detail;
};

struct Report {
    std::vector<TaskResult> items;
    std::string backupId;            // empty when nothing needed a backup
    bool restartRecommended = false;
    uint64_t junkFilesScanned = 0;
    uint64_t junkFilesDeleted = 0;
    uint64_t junkFilesSkipped = 0;
    uint64_t junkFilesFailed = 0;
    uint64_t junkBytesReclaimed = 0;  // verified (measured), never estimated
    std::vector<std::string> measurements;  // human-readable, labelled measured/estimate

    void add(const std::string& category, const std::string& id, const std::string& title, Status s,
             const std::string& detail) {
        items.push_back({category, id, title, s, detail});
    }
    int count(Status s) const {
        int n = 0;
        for (const auto& i : items)
            if (i.status == s) ++n;
        return n;
    }
};

}  // namespace fmo
