#include "JunkCleaner.h"

#include <algorithm>
#include <chrono>

#include "FiveM.h"
#include "Log.h"

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <shellapi.h>
#endif

namespace fmo {

// ------------------------------------------------------------------ helpers
static std::string normKey(const fs::path& p) {
    std::string s = pathToUtf8(p.lexically_normal());
    while (s.size() > 1 && (s.back() == '/' || s.back() == '\\')) s.pop_back();
    for (auto& ch : s)
        if (ch == '\\') ch = '/';
    return toLower(s);
}

static bool isUnder(const fs::path& child, const fs::path& parent) {
    std::string c = normKey(child), p = normKey(parent);
    return c.size() > p.size() && c.compare(0, p.size(), p) == 0 && c[p.size()] == '/';
}

static bool isReparse(const fs::path& p) {
#ifdef _WIN32
    DWORD a = GetFileAttributesW(p.c_str());
    return a != INVALID_FILE_ATTRIBUTES && (a & FILE_ATTRIBUTE_REPARSE_POINT);
#else
    std::error_code ec;
    return fs::is_symlink(fs::symlink_status(p, ec));
#endif
}

static bool isLockedOrProtected(const std::error_code& ec) {
#ifdef _WIN32
    int v = ec.value();
    if (v == 5 || v == 32 || v == 33) return true;  // access denied, sharing/lock violation
#endif
    return ec == std::errc::permission_denied || ec == std::errc::operation_not_permitted ||
           ec == std::errc::device_or_resource_busy || ec == std::errc::text_file_busy;
}

bool JunkCleaner::globMatch(const std::string& pattern, const std::string& name) {
    std::string p = toLower(pattern), n = toLower(name);
    size_t pi = 0, ni = 0, star = std::string::npos, mark = 0;
    while (ni < n.size()) {
        if (pi < p.size() && (p[pi] == '?' || p[pi] == n[ni])) {
            ++pi;
            ++ni;
        } else if (pi < p.size() && p[pi] == '*') {
            star = pi++;
            mark = ni;
        } else if (star != std::string::npos) {
            pi = star + 1;
            ni = ++mark;
        } else {
            return false;
        }
    }
    while (pi < p.size() && p[pi] == '*') ++pi;
    return pi == p.size();
}

// ------------------------------------------------------------------ environment
CleanerEnv CleanerEnv::fromSystem() {
    CleanerEnv e;
    e.userTemp = pathFromUtf8(getEnv("TEMP"));
    e.userTemp2 = pathFromUtf8(getEnv("TMP"));
    e.winDir = pathFromUtf8(getEnv("SystemRoot"));
    e.localAppData = pathFromUtf8(getEnv("LOCALAPPDATA"));
    e.appData = pathFromUtf8(getEnv("APPDATA"));
    e.programData = pathFromUtf8(getEnv("ProgramData"));
    e.userProfile = pathFromUtf8(getEnv("USERPROFILE"));
    if (!e.localAppData.empty()) e.fivemAppDir = e.localAppData / "FiveM" / "FiveM.app";
    e.fivemRunning = [] { return isFiveMRunning(); };
    return e;
}

JunkCleaner::JunkCleaner(CleanerEnv env) : env_(std::move(env)) {
    auto add = [&](const fs::path& p) {
        if (!p.empty()) forbidden_.push_back(p);
    };
    add(env_.userProfile);
    add(env_.localAppData);
    add(env_.appData);
    add(env_.programData);
    add(env_.winDir);
    if (!env_.winDir.empty()) add(env_.winDir / "System32");
    if (!env_.userProfile.empty())
        for (const char* d : {"Documents", "Downloads", "Desktop", "Pictures", "Videos", "Music", "OneDrive"})
            add(env_.userProfile / d);
}

bool JunkCleaner::isSafeRoot(const fs::path& root) const {
    if (root.empty() || !root.is_absolute()) return false;
    fs::path p = root.lexically_normal();
    // Depth below the drive / filesystem root must be at least 2 (e.g. C:\Windows\Temp).
    size_t depth = 0;
    for (auto& part : p.relative_path()) {
        if (!part.empty() && part != ".") ++depth;
    }
    if (depth < 2) return false;
    std::string pk = normKey(p);
    for (const auto& f : forbidden_) {
        std::string fk = normKey(f);
        if (pk == fk) return false;                                              // the folder itself
        if (fk.size() > pk.size() && fk.compare(0, pk.size(), pk) == 0 && fk[pk.size()] == '/') return false;  // ancestor
    }
    // Never inside a personal folder.
    for (const auto& f : forbidden_) {
        std::string leaf = toLower(f.filename().string());
        static const char* personal[] = {"documents", "downloads", "desktop", "pictures", "videos", "music", "onedrive"};
        for (auto* pn : personal)
            if (leaf == pn && isUnder(p, f)) return false;
    }
    return true;
}

// ------------------------------------------------------------------ categories
std::vector<CleanCategory> JunkCleaner::categories() const {
    std::vector<CleanCategory> v;
    const fs::path &L = env_.localAppData, &P = env_.programData, &W = env_.winDir;

    auto mk = [](const char* id, const char* title, const char* desc, Tier tier, int age) {
        CleanCategory c;
        c.id = id;
        c.title = title;
        c.description = desc;
        c.tier = tier;
        c.minAgeMinutes = age;
        c.selectedByDefault = tier == Tier::Safe;
        return c;
    };
    auto tgt = [](CleanCategory& c, const fs::path& root, const std::string& pattern = {}, bool rec = true) {
        if (!root.empty()) c.targets.push_back({root, pattern, rec});
    };

    {
        auto c = mk("user_temp", "User temporary files (%TEMP%)",
                    "Files in your temp folder that have not been touched for at least an hour. Locked files are skipped.",
                    Tier::Safe, env_.tempMinAgeMinutes);
        tgt(c, env_.userTemp);
        if (!env_.userTemp2.empty() && normKey(env_.userTemp2) != normKey(env_.userTemp)) tgt(c, env_.userTemp2);
        v.push_back(c);
    }
    if (!W.empty()) {
        auto c = mk("win_temp", "Windows temporary files (C:\\Windows\\Temp)",
                    "System temp folder. Administrator rights are needed to remove most items.", Tier::Safe,
                    env_.tempMinAgeMinutes);
        tgt(c, W / "Temp");
        v.push_back(c);
    }
    if (!L.empty()) {
        auto c = mk("thumbnails", "Thumbnail cache", "Explorer thumbnail databases; Windows rebuilds them on demand.",
                    Tier::Safe, 0);
        tgt(c, L / "Microsoft" / "Windows" / "Explorer", "thumbcache_*.db", false);
        v.push_back(c);

        auto d = mk("shader_cache", "DirectX / GPU shader cache",
                    "Compiled shader caches. They are rebuilt automatically; the first launch of a game afterwards may "
                    "stutter slightly while shaders recompile.",
                    Tier::Safe, 0);
        tgt(d, L / "D3DSCache");
        tgt(d, L / "NVIDIA" / "DXCache");
        tgt(d, L / "NVIDIA" / "GLCache");
        tgt(d, L / "AMD" / "DxCache");
        v.push_back(d);

        auto e = mk("crash_dumps", "Application crash dumps", "Local crash dump files (%LOCALAPPDATA%\\CrashDumps).",
                    Tier::Safe, 0);
        tgt(e, L / "CrashDumps");
        v.push_back(e);

        auto w = mk("wer", "Windows Error Reporting archives", "Queued and archived error reports that were already sent.",
                    Tier::Safe, 0);
        tgt(w, L / "Microsoft" / "Windows" / "WER" / "ReportArchive");
        tgt(w, L / "Microsoft" / "Windows" / "WER" / "ReportQueue");
        if (!P.empty()) {
            tgt(w, P / "Microsoft" / "Windows" / "WER" / "ReportArchive");
            tgt(w, P / "Microsoft" / "Windows" / "WER" / "ReportQueue");
        }
        v.push_back(w);

        auto b = mk("browser_cache", "Browser disk caches (Chrome / Edge)",
                    "Only the 'Cache', 'Code Cache' and 'GPUCache' folders of the Default profile. Cookies, logins, "
                    "history and settings are never touched.",
                    Tier::Safe, 0);
        for (const char* base : {"Google/Chrome/User Data/Default", "Microsoft/Edge/User Data/Default"})
            for (const char* sub : {"Cache", "Code Cache", "GPUCache"}) tgt(b, L / fs::path(base) / sub);
        v.push_back(b);
    }
    if (!P.empty()) {
        auto c = mk("delivery_opt", "Delivery Optimization cache", "Windows Update peer-to-peer download cache.", Tier::Safe, 0);
        tgt(c, P / "Microsoft" / "Windows" / "DeliveryOptimization" / "Cache");
        if (!W.empty())
            tgt(c, W / "ServiceProfiles" / "NetworkService" / "AppData" / "Local" / "Microsoft" / "Windows" /
                       "DeliveryOptimization" / "Cache");
        v.push_back(c);
    }
    if (!env_.fivemAppDir.empty()) {
        auto c = mk("fivem_cache", "FiveM cache",
                    "Downloaded server/resource caches (data\\cache, server-cache, server-cache-priv). FiveM re-downloads "
                    "what it needs. Skipped while FiveM is running. Game files, plugins and settings are never touched.",
                    Tier::Safe, 0);
        c.needsGameClosed = true;
        for (const char* sub : {"cache", "server-cache", "server-cache-priv"}) tgt(c, env_.fivemAppDir / "data" / sub);
        v.push_back(c);
    }
    {
        auto c = mk("recycle_bin", "Recycle Bin",
                    "Permanently deletes everything in the Recycle Bin. Requires your separate confirmation.",
                    Tier::Optional, 0);
        c.recycleBin = true;
        c.selectedByDefault = false;
        v.push_back(c);
    }
    return v;
}

std::vector<std::string> JunkCleaner::protectedData() {
    return {"Documents, Downloads, Desktop, Pictures, Videos, Music, OneDrive",
            "Browser profiles, cookies, saved logins, history and extensions",
            "Anything else in %APPDATA% and %LOCALAPPDATA% (settings, sessions, saved games, credentials)",
            "FiveM game files, plugins, CitizenFX.ini and your FiveM settings",
            "Previous Windows installations, restore points and recovery data",
            "Windows Update installation files and system components"};
}

// ------------------------------------------------------------------ walking
namespace {
struct Ctx {
    fs::path root;
    std::string pattern;
    bool recursive = true;
    int minAgeMin = 0;
    bool dry = false;
    const CleanProgress* progress = nullptr;
    const std::atomic<bool>* cancel = nullptr;
    std::string label;
    uint64_t scanned = 0, deleted = 0, skipped = 0, failed = 0, reclaimed = 0, estFiles = 0, estBytes = 0;
    bool cancelled = false;
    uint64_t tick = 0;
};

// Returns true when `dir` is empty afterwards (so the caller may remove it).
bool walk(Ctx& c, const fs::path& dir, int depth) {
    std::error_code ec;
    fs::directory_iterator it(dir, fs::directory_options::skip_permission_denied, ec), end;
    if (ec) {
        ++c.skipped;
        return false;
    }
    bool empty = true;
    for (; it != end; it.increment(ec)) {
        if (ec) {
            empty = false;
            break;
        }
        if (c.cancel && c.cancel->load()) {
            c.cancelled = true;
            return false;
        }
        const fs::path p = it->path();
        if (!isUnder(p, c.root)) {  // defence in depth: never leave the approved root
            ++c.skipped;
            empty = false;
            continue;
        }
        if (isReparse(p)) {  // symlinks / junctions are never followed or removed
            ++c.scanned;
            ++c.skipped;
            empty = false;
            continue;
        }
        std::error_code e2;
        fs::file_status st = it->symlink_status(e2);
        if (fs::is_directory(st)) {
            if (!c.recursive || !c.pattern.empty() || depth >= 40) {
                empty = false;
                continue;
            }
            bool subEmpty = walk(c, p, depth + 1);
            if (c.cancelled) return false;
            if (!c.dry && subEmpty) {
                std::error_code e3;
                fs::remove(p, e3);
                if (e3) empty = false;
            } else {
                empty = false;
            }
            continue;
        }
        if (!c.pattern.empty() && !JunkCleaner::globMatch(c.pattern, p.filename().string())) {
            empty = false;
            continue;
        }
        ++c.scanned;
        if (c.minAgeMin > 0) {
            std::error_code e3;
            auto t = fs::last_write_time(p, e3);
            if (!e3) {
                auto age = std::chrono::duration_cast<std::chrono::minutes>(fs::file_time_type::clock::now() - t);
                if (age.count() < c.minAgeMin) {
                    ++c.skipped;
                    empty = false;
                    continue;
                }
            }
        }
        std::error_code e4;
        uint64_t size = fs::is_regular_file(st) ? static_cast<uint64_t>(fs::file_size(p, e4)) : 0;
        if (e4) size = 0;
        if (c.dry) {
            ++c.estFiles;
            c.estBytes += size;
            empty = false;
        } else {
            std::error_code e5;
            fs::remove(p, e5);
            if (e5) {
                if (isLockedOrProtected(e5)) ++c.skipped; else ++c.failed;
                empty = false;
            } else {
                std::error_code e6;
                if (fs::exists(fs::symlink_status(p, e6))) {  // verify it is really gone
                    ++c.failed;
                    empty = false;
                } else {
                    ++c.deleted;
                    c.reclaimed += size;
                }
            }
        }
        if (c.progress && *c.progress && (++c.tick % 250) == 0)
            (*c.progress)(c.label + ": " + std::to_string(c.scanned) + " files examined");
    }
    return empty;
}
}  // namespace

void JunkCleaner::walkTarget(const CleanTarget& t, const CleanCategory& cat, bool dryRun, const CleanProgress& progress,
                             const std::atomic<bool>* cancel, CategoryResult& r, CategoryScan* s) const {
    Ctx c;
    c.root = t.root;
    c.pattern = t.filePattern;
    c.recursive = t.recursive;
    c.minAgeMin = cat.minAgeMinutes;
    c.dry = dryRun;
    c.progress = &progress;
    c.cancel = cancel;
    c.label = cat.title;
    walk(c, t.root, 0);
    r.scanned += c.scanned;
    r.deleted += c.deleted;
    r.skipped += c.skipped;
    r.failed += c.failed;
    r.bytesReclaimed += c.reclaimed;
    if (s) {
        s->files += c.estFiles;
        s->bytes += c.estBytes;
    }
    if (c.cancelled) r.note = "cancelled";
}

#ifdef _WIN32
static bool queryBin(uint64_t& bytes, uint64_t& items) {
    SHQUERYRBINFO info{};
    info.cbSize = sizeof info;
    if (SHQueryRecycleBinW(nullptr, &info) != S_OK) return false;
    bytes = static_cast<uint64_t>(info.i64Size);
    items = static_cast<uint64_t>(info.i64NumItems);
    return true;
}
#endif

CategoryScan JunkCleaner::scan(const CleanCategory& c, const std::atomic<bool>* cancel) const {
    CategoryScan s;
    s.id = c.id;
    if (c.recycleBin) {
#ifdef _WIN32
        uint64_t b = 0, n = 0;
        if (queryBin(b, n)) {
            s.available = true;
            s.bytes = b;
            s.files = n;
        }
#else
        s.note = "Windows only";
#endif
        return s;
    }
    CategoryResult dummy;
    for (const auto& t : c.targets) {
        std::error_code ec;
        if (!isSafeRoot(t.root)) {
            s.note = "refused: unsafe root";
            continue;
        }
        if (!fs::is_directory(t.root, ec) || isReparse(t.root)) continue;
        s.available = true;
        walkTarget(t, c, true, {}, cancel, dummy, &s);
    }
    return s;
}

CategoryResult JunkCleaner::clean(const CleanCategory& c, const CleanProgress& progress,
                                  const std::atomic<bool>* cancel) const {
    CategoryResult r;
    r.id = c.id;
    r.title = c.title;
    if (c.needsGameClosed && env_.fivemRunning && env_.fivemRunning()) {
        r.status = Status::Skipped;
        r.note = "FiveM is running. Close the game and run again.";
        return r;
    }
    if (c.recycleBin) {
#ifdef _WIN32
        uint64_t b0 = 0, n0 = 0, b1 = 0, n1 = 0;
        if (!queryBin(b0, n0)) {
            r.status = Status::Failed;
            r.note = "Could not query the Recycle Bin.";
            return r;
        }
        if (n0 == 0) {
            r.status = Status::AlreadyOk;
            r.note = "Recycle Bin is already empty.";
            return r;
        }
        HRESULT hr = SHEmptyRecycleBinW(nullptr, nullptr, SHERB_NOCONFIRMATION | SHERB_NOPROGRESSUI | SHERB_NOSOUND);
        queryBin(b1, n1);
        r.scanned = n0;
        r.deleted = n0 > n1 ? n0 - n1 : 0;
        r.bytesReclaimed = b0 > b1 ? b0 - b1 : 0;
        r.status = (FAILED(hr) || n1 > 0) ? Status::Warning : Status::Applied;
        r.note = r.status == Status::Applied ? "Recycle Bin emptied (verified)." : "Recycle Bin was not completely emptied.";
#else
        r.status = Status::Skipped;
        r.note = "Windows only.";
#endif
        return r;
    }
    bool any = false;
    std::string refused;
    for (const auto& t : c.targets) {
        std::error_code ec;
        if (!isSafeRoot(t.root)) {
            refused += "refused unsafe folder " + pathToUtf8(t.root) + "; ";
            logWarn("cleaner", "refused unsafe root " + pathToUtf8(t.root));
            continue;
        }
        if (!fs::is_directory(t.root, ec) || isReparse(t.root)) continue;
        any = true;
        walkTarget(t, c, false, progress, cancel, r, nullptr);
        if (cancel && cancel->load()) break;
    }
    if (!refused.empty()) r.note += refused;
    if (!any) {
        r.status = refused.empty() ? Status::AlreadyOk : Status::Skipped;
        if (r.note.empty()) r.note = "Nothing to clean (folder not present).";
    } else if (r.note == "cancelled") {
        r.status = Status::Warning;
    } else if (r.failed > 0) {
        r.status = r.deleted > 0 ? Status::Warning : Status::Failed;
    } else if (r.deleted > 0) {
        r.status = r.skipped > 0 ? Status::Warning : Status::Applied;
    } else {
        r.status = r.skipped > 0 ? Status::Warning : Status::AlreadyOk;
        if (r.note.empty()) r.note = r.skipped > 0 ? "Nothing removable (items locked, protected or recent)." : "Nothing to clean.";
    }
    logInfo("cleaner", c.id + ": scanned=" + std::to_string(r.scanned) + " deleted=" + std::to_string(r.deleted) +
                           " skipped=" + std::to_string(r.skipped) + " failed=" + std::to_string(r.failed) +
                           " reclaimed=" + std::to_string(r.bytesReclaimed));
    return r;
}

std::vector<JunkCleaner::Handler> JunkCleaner::diskCleanupHandlers(IRegistry& reg) {
    static const std::set<std::string> covered = {"Thumbnail Cache",
                                                  "D3D Shader Cache",
                                                  "Delivery Optimization Files",
                                                  "Temporary Files",
                                                  "Windows Error Reporting Files",
                                                  "Recycle Bin"};
    std::vector<Handler> out;
    for (const auto& n : reg.subKeys(Hive::HKLM, "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\VolumeCaches"))
        out.push_back({n, covered.count(n) > 0});
    return out;
}

}  // namespace fmo
