#pragma once
#include <string>
#include <vector>

#include "Platform.h"
#include "Util.h"

namespace fmo {

struct FiveMInfo {
    bool installed = false;
    fs::path root;      // %LOCALAPPDATA%\FiveM
    fs::path appDir;    // ...\FiveM.app
    fs::path exe;       // ...\FiveM.exe (launcher)
    std::vector<fs::path> gameExes;  // FiveM*_GTAProcess.exe that exist
};

// `localAppData` is injectable for tests; pass getEnv("LOCALAPPDATA") in production.
FiveMInfo detectFiveM(const fs::path& localAppData);

// True when any FiveM process (FiveM.exe, FiveM_*.exe) is running. Case-insensitive.
bool isFiveMRunning(const std::vector<std::string>& processNames);
bool isFiveMRunning();

// Regenerable cache folders inside FiveM.app\data (never citizen\, plugins\ or settings).
std::vector<fs::path> fivemCacheDirs(const FiveMInfo& info);

struct Bottleneck {
    std::string severity;  // info | warn
    std::string text;
};
// Heuristics over a point-in-time snapshot. Labelled as snapshot, never as a measured FPS result.
std::vector<Bottleneck> analyzeSnapshot(const LoadSnapshot& l, const SysInfo& s, bool fivemRunning);

// Background processes worth closing before playing (named set only; we never close anything ourselves).
std::vector<std::string> knownBackgroundHogs(const std::vector<std::string>& processNames);

}  // namespace fmo
