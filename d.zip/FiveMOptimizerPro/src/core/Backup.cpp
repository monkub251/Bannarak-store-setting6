#include "Backup.h"

#include <algorithm>
#include <fstream>
#include <sstream>

#include "Log.h"

namespace fmo {

static const char* kHeader = "FMO-BACKUP\t1";

bool BackupStore::parseManifest(const fs::path& file, BackupSet& out, std::string& err) {
    std::ifstream in(file, std::ios::binary);
    if (!in) {
        err = "cannot open manifest";
        return false;
    }
    std::string line;
    if (!std::getline(in, line) || trim(line) != kHeader) {
        err = "bad header";
        return false;
    }
    out.entries.clear();
    bool ended = false;
    size_t declared = 0;
    while (std::getline(in, line)) {
        line = trim(line);
        if (line.empty()) continue;
        auto parts = splitStr(line, '\t');
        if (parts[0] == "CREATED" && parts.size() >= 2) {
            out.created = parts[1];
        } else if (parts[0] == "E" && parts.size() >= 2) {
            BackupEntry e;
            e.kind = unescapeField(parts[1]);
            for (size_t i = 2; i < parts.size(); ++i) {
                size_t eq = parts[i].find('=');
                if (eq == std::string::npos) {
                    err = "bad field";
                    return false;
                }
                e.f[unescapeField(parts[i].substr(0, eq))] = unescapeField(parts[i].substr(eq + 1));
            }
            out.entries.push_back(std::move(e));
        } else if (parts[0] == "END" && parts.size() >= 2) {
            declared = static_cast<size_t>(std::stoull(parts[1]));
            ended = true;
        }
    }
    if (!ended) {
        err = "manifest incomplete (no END marker)";
        return false;
    }
    if (declared != out.entries.size()) {
        err = "manifest entry count mismatch";
        return false;
    }
    return true;
}

bool BackupStore::create(const std::vector<BackupEntry>& entries, BackupSet& out, std::string& err) const {
    std::error_code ec;
    fs::create_directories(root_, ec);
    if (ec) {
        err = "cannot create backup folder: " + ec.message();
        return false;
    }
    // Unique folder: an existing backup is never reused or overwritten.
    std::string base = nowStamp();
    fs::path dir;
    for (int n = 0; n < 1000; ++n) {
        dir = root_ / (n == 0 ? base : base + "-" + std::to_string(n));
        if (fs::create_directory(dir, ec)) break;
        if (ec) {
            err = "cannot create backup folder: " + ec.message();
            return false;
        }
        dir.clear();
    }
    if (dir.empty()) {
        err = "could not allocate a unique backup folder";
        return false;
    }
    std::string created = isoNow();
    fs::path tmp = dir / "manifest.tmp", fin = dir / "manifest.txt";
    {
        std::ofstream o(tmp, std::ios::binary | std::ios::trunc);
        if (!o) {
            err = "cannot write manifest";
            return false;
        }
        o << kHeader << '\n' << "CREATED\t" << created << '\n';
        for (const auto& e : entries) {
            o << "E\t" << escapeField(e.kind);
            for (const auto& kv : e.f) o << '\t' << escapeField(kv.first) << '=' << escapeField(kv.second);
            o << '\n';
        }
        o << "END\t" << entries.size() << '\n';
        o.flush();
        if (!o) {
            err = "manifest write failed (disk full?)";
            return false;
        }
    }
    fs::rename(tmp, fin, ec);
    if (ec) {
        err = "cannot finalize manifest: " + ec.message();
        return false;
    }
    BackupSet check;
    std::string perr;
    if (!parseManifest(fin, check, perr)) {
        err = "backup validation failed: " + perr;
        return false;
    }
    if (check.entries.size() != entries.size() || !std::equal(entries.begin(), entries.end(), check.entries.begin())) {
        err = "backup validation failed: read-back differs from what was written";
        return false;
    }
    out = check;
    out.id = dir.filename().string();
    out.dir = dir;
    out.restored = false;
    logInfo("backup", "created " + out.id + " with " + std::to_string(entries.size()) + " entries");
    return true;
}

std::vector<BackupSet> BackupStore::list() const {
    std::vector<BackupSet> sets;
    std::error_code ec;
    if (!fs::exists(root_, ec)) return sets;
    for (auto& d : fs::directory_iterator(root_, ec)) {
        if (!d.is_directory(ec)) continue;
        BackupSet s;
        std::string err;
        if (!parseManifest(d.path() / "manifest.txt", s, err)) {
            logWarn("backup", "skipping unreadable backup " + d.path().filename().string() + ": " + err);
            continue;
        }
        s.id = d.path().filename().string();
        s.dir = d.path();
        s.restored = fs::exists(d.path() / "restored.txt", ec);
        sets.push_back(std::move(s));
    }
    std::sort(sets.begin(), sets.end(), [](const BackupSet& a, const BackupSet& b) { return a.id > b.id; });
    return sets;
}

bool BackupStore::markRestored(const BackupSet& set, std::string& err) const {
    std::ofstream o(set.dir / "restored.txt");
    o << "restored " << isoNow() << '\n';
    if (!o) {
        err = "cannot write restore marker";
        return false;
    }
    return true;
}

}  // namespace fmo
