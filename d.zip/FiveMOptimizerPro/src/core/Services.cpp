#include "Services.h"

#include <algorithm>
#include <set>

#include "Platform.h"

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#endif

namespace fmo {
namespace services {

std::vector<Candidate> candidates() {
    return {{"Fax", "Fax", "Only needed with fax hardware."},
            {"RetailDemo", "Retail Demo Service", "Used only by retail demo units."},
            {"MapsBroker", "Downloaded Maps Manager", "Only needed by the Maps app."},
            {"WMPNetworkSvc", "Windows Media Player Network Sharing Service", "Only needed for media sharing."},
            {"wisvc", "Windows Insider Service", "Only needed when enrolled in the Insider program."}};
}

std::vector<Candidate> aggressiveCandidates() {
    return {{"SysMain", "SysMain (Superfetch)", "Prefetching service; constant disk/RAM activity."},
            {"DiagTrack", "Connected User Experiences and Telemetry", "Telemetry upload and diagnostics."},
            {"dmwappushservice", "WAP Push Message Routing", "Telemetry helper."},
            {"WSearch", "Windows Search", "Background indexing."},
            {"WerSvc", "Windows Error Reporting", "Crash report upload."},
            {"PcaSvc", "Program Compatibility Assistant", "Compatibility monitoring."},
            {"XblAuthManager", "Xbox Live Auth Manager", "Xbox sign-in; not used by FiveM."},
            {"XblGameSave", "Xbox Live Game Save", "Xbox cloud saves."},
            {"XboxNetApiSvc", "Xbox Live Networking Service", "Xbox networking."},
            {"XboxGipSvc", "Xbox Accessory Management Service", "Xbox accessories."},
            {"lfsvc", "Geolocation Service", "Location tracking."},
            {"RemoteRegistry", "Remote Registry", "Remote registry access."},
            {"TrkWks", "Distributed Link Tracking Client", "NTFS link tracking."},
            {"PhoneSvc", "Phone Service", "Phone Link integration."},
            {"WalletService", "WalletService", "Wallet."},
            {"icssvc", "Windows Mobile Hotspot Service", "Mobile hotspot."},
            {"Fax", "Fax", "Fax hardware."},
            {"RetailDemo", "Retail Demo Service", "Retail demo mode."},
            {"MapsBroker", "Downloaded Maps Manager", "Maps app."},
            {"WMPNetworkSvc", "Windows Media Player Network Sharing Service", "Media sharing."},
            {"wisvc", "Windows Insider Service", "Insider program."}};
}

bool isProtected(const std::string& name) {
    static const std::set<std::string> deny = {
        "winmgmt", "rpcss", "rpceptmapper", "dcomlaunch", "samss", "lsass", "eventlog", "eventsystem", "cryptsvc",
        "trustedinstaller", "windefend", "wdnissvc", "sense", "securityhealthservice", "mpssvc", "bfe", "wuauserv",
        "usosvc", "bits", "dhcp", "dnscache", "nlasvc", "netprofm", "lanmanworkstation", "lanmanserver", "nsi",
        "audiosrv", "audioendpointbuilder", "plugplay", "power", "profsvc", "schedule", "themes", "vds", "storsvc",
        "hidserv", "gpsvc", "appinfo", "keyiso", "lmhosts", "wlansvc", "dot3svc", "tcpipreg", "shellhwdetection"};
    std::string l = name;
    std::transform(l.begin(), l.end(), l.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return deny.count(l) > 0;
}

#ifdef _WIN32

State query(const std::string& name) {
    State s;
    SC_HANDLE scm = OpenSCManagerW(nullptr, nullptr, SC_MANAGER_CONNECT);
    if (!scm) return s;
    SC_HANDLE svc = OpenServiceW(scm, widen(name).c_str(),
                                 SERVICE_QUERY_CONFIG | SERVICE_QUERY_STATUS | SERVICE_ENUMERATE_DEPENDENTS);
    if (!svc) {
        CloseServiceHandle(scm);
        return s;
    }
    s.installed = true;
    DWORD need = 0;
    QueryServiceConfigW(svc, nullptr, 0, &need);
    if (need) {
        std::vector<BYTE> buf(need);
        auto* cfg = reinterpret_cast<QUERY_SERVICE_CONFIGW*>(buf.data());
        if (QueryServiceConfigW(svc, cfg, need, &need)) {
            s.startType = cfg->dwStartType;
            if (cfg->lpDisplayName) s.display = narrow(cfg->lpDisplayName);
        }
    }
    SERVICE_DELAYED_AUTO_START_INFO d{};
    DWORD got = 0;
    if (QueryServiceConfig2W(svc, SERVICE_CONFIG_DELAYED_AUTO_START_INFO, reinterpret_cast<LPBYTE>(&d), sizeof d, &got))
        s.delayedAuto = d.fDelayedAutostart != 0;
    SERVICE_STATUS_PROCESS ssp{};
    if (QueryServiceStatusEx(svc, SC_STATUS_PROCESS_INFO, reinterpret_cast<LPBYTE>(&ssp), sizeof ssp, &got))
        s.running = ssp.dwCurrentState != SERVICE_STOPPED;
    DWORD bytes = 0, count = 0;
    if (!EnumDependentServicesW(svc, SERVICE_ACTIVE, nullptr, 0, &bytes, &count) && GetLastError() == ERROR_MORE_DATA)
        s.hasRunningDependents = true;
    CloseServiceHandle(svc);
    CloseServiceHandle(scm);
    return s;
}

bool setStartType(const std::string& name, unsigned startType, bool delayedAuto, std::string& err) {
    if (isProtected(name)) {
        err = "service is on the protected list";
        return false;
    }
    SC_HANDLE scm = OpenSCManagerW(nullptr, nullptr, SC_MANAGER_CONNECT);
    if (!scm) {
        err = "cannot open Service Control Manager (error " + std::to_string(GetLastError()) + ")";
        return false;
    }
    SC_HANDLE svc = OpenServiceW(scm, widen(name).c_str(), SERVICE_CHANGE_CONFIG);
    if (!svc) {
        err = "cannot open service (error " + std::to_string(GetLastError()) + ")";
        CloseServiceHandle(scm);
        return false;
    }
    BOOL ok = ChangeServiceConfigW(svc, SERVICE_NO_CHANGE, startType, SERVICE_NO_CHANGE, nullptr, nullptr, nullptr,
                                   nullptr, nullptr, nullptr, nullptr);
    if (!ok) err = "ChangeServiceConfig failed (error " + std::to_string(GetLastError()) + ")";
    if (ok && startType == SERVICE_AUTO_START) {
        SERVICE_DELAYED_AUTO_START_INFO d{delayedAuto ? TRUE : FALSE};
        if (!ChangeServiceConfig2W(svc, SERVICE_CONFIG_DELAYED_AUTO_START_INFO, &d)) {
            err = "could not restore delayed-start flag (error " + std::to_string(GetLastError()) + ")";
            ok = FALSE;
        }
    }
    CloseServiceHandle(svc);
    CloseServiceHandle(scm);
    return ok == TRUE;
}

bool stop(const std::string& name, std::string& err) {
    if (isProtected(name)) {
        err = "service is on the protected list";
        return false;
    }
    SC_HANDLE scm = OpenSCManagerW(nullptr, nullptr, SC_MANAGER_CONNECT);
    if (!scm) { err = "cannot open Service Control Manager"; return false; }
    SC_HANDLE svc = OpenServiceW(scm, widen(name).c_str(), SERVICE_STOP | SERVICE_QUERY_STATUS);
    if (!svc) { err = "cannot open service (error " + std::to_string(GetLastError()) + ")"; CloseServiceHandle(scm); return false; }
    SERVICE_STATUS st{};
    bool ok = true;
    if (!ControlService(svc, SERVICE_CONTROL_STOP, &st) && GetLastError() != ERROR_SERVICE_NOT_ACTIVE) {
        err = "stop request failed (error " + std::to_string(GetLastError()) + ")";
        ok = false;
    }
    for (int i = 0; ok && i < 80; ++i) {
        SERVICE_STATUS_PROCESS ssp{};
        DWORD got = 0;
        if (!QueryServiceStatusEx(svc, SC_STATUS_PROCESS_INFO, reinterpret_cast<LPBYTE>(&ssp), sizeof ssp, &got)) break;
        if (ssp.dwCurrentState == SERVICE_STOPPED) break;
        Sleep(100);
        if (i == 79) { err = "service did not stop in time"; ok = false; }
    }
    CloseServiceHandle(svc);
    CloseServiceHandle(scm);
    return ok;
}

bool start(const std::string& name, std::string& err) {
    SC_HANDLE scm = OpenSCManagerW(nullptr, nullptr, SC_MANAGER_CONNECT);
    if (!scm) { err = "cannot open Service Control Manager"; return false; }
    SC_HANDLE svc = OpenServiceW(scm, widen(name).c_str(), SERVICE_START);
    if (!svc) { err = "cannot open service (error " + std::to_string(GetLastError()) + ")"; CloseServiceHandle(scm); return false; }
    bool ok = StartServiceW(svc, 0, nullptr) || GetLastError() == ERROR_SERVICE_ALREADY_RUNNING;
    if (!ok) err = "start failed (error " + std::to_string(GetLastError()) + ")";
    CloseServiceHandle(svc);
    CloseServiceHandle(scm);
    return ok;
}

#else

bool stop(const std::string&, std::string& err) { err = "not supported on this platform"; return false; }
bool start(const std::string&, std::string& err) { err = "not supported on this platform"; return false; }
State query(const std::string&) { return {}; }
bool setStartType(const std::string&, unsigned, bool, std::string& err) {
    err = "not supported on this platform";
    return false;
}

#endif

}  // namespace services

namespace power {
const char* kHighPerformanceGuid = "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c";

#ifdef _WIN32
static std::string exe() { return systemTool("powercfg.exe"); }

bool activeScheme(std::string& guid, std::string& err) {
    ProcResult r = runProcess({exe(), "/getactivescheme"}, 10000);
    if (!r.started || r.exitCode != 0) {
        err = r.started ? "powercfg exit code " + std::to_string(r.exitCode) : r.error;
        return false;
    }
    // "Power Scheme GUID: 381b4222-f694-41f0-9685-ff5bb260df2e  (Balanced)"
    size_t p = r.output.find(": ");
    if (p == std::string::npos || p + 2 + 36 > r.output.size()) {
        err = "could not parse powercfg output";
        return false;
    }
    guid = r.output.substr(p + 2, 36);
    for (char c : guid)
        if (!(std::isxdigit(static_cast<unsigned char>(c)) || c == '-')) {
            err = "unexpected GUID format";
            return false;
        }
    return true;
}

bool setActive(const std::string& guid, std::string& err) {
    if (guid.size() != 36) {
        err = "invalid GUID";
        return false;
    }
    ProcResult r = runProcess({exe(), "/setactive", guid}, 10000);
    if (!r.started || r.exitCode != 0) {
        err = r.started ? "powercfg exit code " + std::to_string(r.exitCode) + ": " + r.output : r.error;
        return false;
    }
    return true;
}
#else
bool activeScheme(std::string&, std::string& err) { err = "not supported on this platform"; return false; }
bool setActive(const std::string&, std::string& err) { err = "not supported on this platform"; return false; }
#endif
}  // namespace power

}  // namespace fmo
