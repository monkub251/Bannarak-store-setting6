#include "Optimizer.h"

#include <algorithm>
#include <chrono>
#include <sstream>
#include <thread>

#include "Log.h"

namespace fmo {

namespace {

std::atomic<bool> g_busy{false};
struct BusyGuard {
    bool owned;
    BusyGuard() : owned(!g_busy.exchange(true)) {}
    ~BusyGuard() {
        if (owned) g_busy = false;
    }
};

std::string joinCsv(const std::vector<std::string>& v) {
    std::string s;
    for (size_t i = 0; i < v.size(); ++i) s += (i ? "," : "") + v[i];
    return s;
}

BackupEntry regEntry(const TweakDef& d, const RegRead& cur) {
    BackupEntry e;
    e.kind = "reg";
    e.f["hive"] = hiveName(d.hive);
    e.f["key"] = d.key;
    e.f["name"] = d.name;
    e.f["tweak"] = d.id;
    e.f["existed"] = cur.state == RegRead::Found ? "1" : "0";
    if (cur.state == RegRead::Found) {
        e.f["type"] = cur.value.type == RegType::DWord ? "dword" : "sz";
        e.f["data"] = cur.value.toText();
    }
    return e;
}

std::string countsText(const CategoryResult& r) {
    std::ostringstream o;
    o << "scanned " << r.scanned << ", deleted " << r.deleted << ", skipped " << r.skipped << ", failed " << r.failed
      << ", reclaimed " << formatBytes(r.bytesReclaimed) << " (measured)";
    if (!r.note.empty()) o << ". " << r.note;
    return o.str();
}

struct SvcPlan {
    std::string name, display;
    unsigned target;
    bool stopIt;
};

}  // namespace

Report Optimizer::run(const Options& opts, const Callbacks& cb) {
    Report rep;
    BusyGuard guard;
    if (!guard.owned) {
        rep.add("System", "busy", "Another operation is running", Status::Failed,
                "Wait for the current operation to finish.");
        return rep;
    }
    auto P = [&](int pct, const std::string& m) {
        logInfo("optimizer", m);
        if (cb.progress) cb.progress(pct, m);
    };
    auto cancelled = [&] { return cb.cancel && cb.cancel->load(); };
    IRegistry& reg = *env_.reg;
    const SysInfo& sys = env_.sys;
    const bool elevated = sys.elevated;

    P(3, "Detecting system");
    {
        std::ostringstream o;
        o << sys.osName << (sys.edition.empty() ? "" : " " + sys.edition) << " build " << sys.build << ", " << sys.arch
          << ", " << sys.cpu << ", " << sys.logicalCores << " threads, " << formatBytes(sys.ramBytes) << " RAM";
        rep.add("System", "detect", "System detected", Status::AlreadyOk, o.str());
        if (!sys.windows)
            rep.add("System", "platform", "Non-Windows build", Status::Warning,
                    "Windows-only operations are unavailable; registry changes go to an in-memory test registry.");
    }
    LoadSnapshot before = sampleLoad(150);
    size_t procCountBefore = env_.procs ? env_.procs->list().size() : 0;

    // ------------------------------------------------------------------ plan: registry / policy
    P(8, "Planning registry and policy changes");
    std::vector<TweakDef> catalog = tweakCatalog();
    for (auto& d : dynamicTweaks(env_.fivem)) catalog.push_back(d);
    std::set<std::string> optIn;
    if (opts.pointerPrecisionOff)
        for (const char* n : {"ptr_MouseSpeed", "ptr_MouseThreshold1", "ptr_MouseThreshold2"}) optIn.insert(n);
    Plan plan = buildPlan(catalog, opts.profiles, optIn, sys, elevated);
    for (auto& n : plan.notes) rep.items.push_back(n);

    std::vector<BackupEntry> backup;
    std::vector<PlanItem> toApply;
    for (auto& it : plan.items) {
        RegRead cur = reg.read(it.def.hive, it.def.key, it.def.name);
        const char* cat = it.def.policy ? "Policy" : "Registry";
        if (cur.state == RegRead::Error) {
            rep.add(cat, it.def.id, it.def.title, Status::Failed, "Cannot read current value: " + cur.error);
        } else if (cur.state == RegRead::Found && cur.value == it.def.desired) {
            rep.add(cat, it.def.id, it.def.title, Status::AlreadyOk, "Already set (" + it.sources + ").");
        } else {
            backup.push_back(regEntry(it.def, cur));
            toApply.push_back(it);
        }
    }

    // ------------------------------------------------------------------ plan: power plan
    bool doPower = false;
    std::string oldScheme;
    if (opts.powerPlan && sys.windows) {
        P(14, "Checking power plan");
        std::string err;
        if (!sys.desktop) {
            rep.add("Power", "powerplan", "High performance power plan", Status::Skipped,
                    "This PC has a battery (laptop). The power plan was not changed.");
        } else if (!power::activeScheme(oldScheme, err)) {
            rep.add("Power", "powerplan", "High performance power plan", Status::Failed, "Cannot read active plan: " + err);
        } else if (oldScheme == power::kHighPerformanceGuid) {
            rep.add("Power", "powerplan", "High performance power plan", Status::AlreadyOk, "Already active.");
        } else {
            BackupEntry e;
            e.kind = "power";
            e.f["guid"] = oldScheme;
            backup.push_back(e);
            doPower = true;
        }
    }

    // ------------------------------------------------------------------ plan: services
    std::vector<SvcPlan> svcPlans;
    if (opts.services != ServiceMode::Off && sys.windows) {
        P(20, "Inspecting services");
        bool aggr = opts.services == ServiceMode::Aggressive;
        auto list = aggr ? services::aggressiveCandidates() : services::candidates();
        if (!elevated) {
            rep.add("Services", "services", "Service reduction", Status::Skipped,
                    "Requires Administrator. Use 'Relaunch as Administrator'.");
        } else {
            for (const auto& c : list) {
                if (services::isProtected(c.name)) continue;
                auto st = services::query(c.name);
                if (!st.installed) continue;
                unsigned target = aggr ? 4 : 3;
                bool alreadyOff = st.startType == target || (st.startType == 4 && !aggr);
                if (alreadyOff && !st.running) {
                    rep.add("Services", c.name, c.display, Status::AlreadyOk, "Already " + std::string(st.startType == 4 ? "disabled." : "manual."));
                    continue;
                }
                if (st.hasRunningDependents) {
                    rep.add("Services", c.name, c.display, Status::Skipped, "Other running services depend on it.");
                    continue;
                }
                BackupEntry e;
                e.kind = "service";
                e.f["name"] = c.name;
                e.f["display"] = c.display;
                e.f["start"] = std::to_string(st.startType);
                e.f["delayed"] = st.delayedAuto ? "1" : "0";
                e.f["running"] = st.running ? "1" : "0";
                backup.push_back(e);
                svcPlans.push_back({c.name, c.display, target, aggr});
            }
        }
    }

    // ------------------------------------------------------------------ plan: DNS
    bool doDns = false;
    net::Adapter dnsAdapter;
    std::vector<std::string> newDns;
    std::string dnsChoice;
    double dnsBeforeMs = -1;
    if (opts.applyFastestDns && sys.windows) {
        P(28, "Benchmarking DNS providers");
        auto ads = net::adapters(reg);
        const net::Adapter* pa = net::primaryAdapter(ads);
        if (!pa) {
            rep.add("Network", "dns", "DNS provider", Status::Skipped, "No active network adapter found.");
        } else {
            net::Probe cur = pa->dnsServers.empty() ? net::Probe{} : net::probeDns("current", pa->dnsServers[0]);
            dnsBeforeMs = cur.medianMs;
            const net::DnsProvider* best = nullptr;
            net::Probe bestProbe;
            for (const auto& pv : net::providers()) {
                net::Probe pr = net::probeDns(pv.name, pv.servers[0]);
                if (pr.medianMs > 0 && pr.lossPercent <= 20 && (!best || pr.medianMs < bestProbe.medianMs)) {
                    best = &pv;
                    bestProbe = pr;
                }
            }
            if (!best) {
                rep.add("Network", "dns", "DNS provider", Status::Skipped, "No public DNS provider answered; DNS left unchanged.");
            } else if (cur.medianMs > 0 && bestProbe.medianMs >= cur.medianMs * 0.85) {
                rep.add("Network", "dns", "DNS provider", Status::AlreadyOk,
                        "Current DNS (" + std::to_string(static_cast<int>(cur.medianMs)) + " ms) is already about as fast as " +
                            best->name + " (" + std::to_string(static_cast<int>(bestProbe.medianMs)) + " ms). Unchanged.");
            } else {
                doDns = true;
                dnsAdapter = *pa;
                newDns = best->servers;
                dnsChoice = best->name;
                BackupEntry e;
                e.kind = "dns";
                e.f["ifindex"] = std::to_string(pa->ifIndex);
                e.f["adapter"] = pa->friendlyName;
                e.f["static"] = pa->dnsStatic ? "1" : "0";
                e.f["servers"] = joinCsv(pa->dnsServers);
                backup.push_back(e);
            }
        }
    }

    // ------------------------------------------------------------------ plan: processes
    ReducerOptions ro;
    ro.maxMode = opts.processes == ProcMode::Max;
    for (auto& k : opts.keepProcesses) ro.keepNames.insert(toLower(k));
    std::vector<ProcEntry> procTargets;
    if (opts.processes != ProcMode::Off && env_.procs) {
        procTargets = selectTargets(env_.procs->list(), env_.procs->selfPid(), ro);
        for (const auto& r : relaunchRoots(procTargets)) {
            BackupEntry e;
            e.kind = "proc";
            e.f["name"] = r.name;
            e.f["path"] = r.path;
            backup.push_back(e);
        }
    }

    if (cancelled()) {
        rep.add("System", "cancel", "Cancelled", Status::Warning, "Cancelled before any change was made.");
        return rep;
    }

    // ------------------------------------------------------------------ backup (point of no return)
    bool canModify = true;
    if (!backup.empty()) {
        P(36, "Creating and validating backup");
        BackupSet set;
        std::string err;
        if (env_.store && env_.store->create(backup, set, err)) {
            rep.backupId = set.id;
            rep.add("Backup", set.id, "Backup created", Status::Applied,
                    std::to_string(backup.size()) + " original settings saved and read back successfully.");
        } else {
            canModify = false;
            rep.add("Backup", "backup", "Backup", Status::Failed,
                    "Backup could not be validated (" + err + "). No system settings, services or processes were changed.");
        }
    }

    if (canModify) {
        // -------------------------------------------------------------- apply registry
        int n = 0;
        for (auto& it : toApply) {
            P(40 + (n++ * 15) / std::max<size_t>(1, toApply.size()), "Applying: " + it.def.title);
            const char* cat = it.def.policy ? "Policy" : "Registry";
            std::string err;
            if (!reg.write(it.def.hive, it.def.key, it.def.name, it.def.desired, err)) {
                rep.add(cat, it.def.id, it.def.title, Status::Failed, "Write failed: " + err);
                continue;
            }
            RegRead v = reg.read(it.def.hive, it.def.key, it.def.name);
            if (v.state == RegRead::Found && v.value == it.def.desired) {
                rep.add(cat, it.def.id, it.def.title, Status::Applied, "Verified (" + it.sources + "). " + it.def.rationale);
                if (it.def.restartNote) rep.restartRecommended = true;
            } else {
                rep.add(cat, it.def.id, it.def.title, Status::Failed, "Value did not persist after writing; verification failed.");
            }
        }

        // -------------------------------------------------------------- power
        if (doPower) {
            P(57, "Setting High performance power plan");
            std::string err, now;
            if (!power::setActive(power::kHighPerformanceGuid, err))
                rep.add("Power", "powerplan", "High performance power plan", Status::Failed, err);
            else if (power::activeScheme(now, err) && now == power::kHighPerformanceGuid)
                rep.add("Power", "powerplan", "High performance power plan", Status::Applied, "Verified active.");
            else
                rep.add("Power", "powerplan", "High performance power plan", Status::Failed, "Plan did not become active.");
        }

        // -------------------------------------------------------------- services
        int si = 0;
        for (const auto& s : svcPlans) {
            P(60 + (si++ * 8) / static_cast<int>(svcPlans.size()), "Service: " + s.display);
            std::string err;
            if (!services::setStartType(s.name, s.target, false, err)) {
                rep.add("Services", s.name, s.display, Status::Failed, err);
                continue;
            }
            std::string stopErr;
            bool stopped = true;
            if (s.stopIt && services::query(s.name).running) stopped = services::stop(s.name, stopErr);
            auto after = services::query(s.name);
            if (after.startType != s.target)
                rep.add("Services", s.name, s.display, Status::Failed, "Start type did not change.");
            else if (!stopped || (s.stopIt && after.running))
                rep.add("Services", s.name, s.display, Status::Warning,
                        std::string("Start type set to ") + (s.target == 4 ? "Disabled" : "Manual") + " but the service is still running (" + stopErr + ").");
            else
                rep.add("Services", s.name, s.display, Status::Applied,
                        std::string("Set to ") + (s.target == 4 ? "Disabled" : "Manual") + (s.stopIt ? " and stopped" : "") + " (verified).");
        }

        // -------------------------------------------------------------- DNS
        if (doDns) {
            P(70, "Applying DNS: " + dnsChoice);
            std::string err;
            if (!net::applyDns(dnsAdapter.ifIndex, newDns, err)) {
                rep.add("Network", "dns", "DNS provider", Status::Failed, err);
            } else {
                auto ads = net::adapters(reg);
                bool ok = false;
                for (auto& a : ads)
                    if (a.ifIndex == dnsAdapter.ifIndex && !a.dnsServers.empty() && a.dnsServers[0] == newDns[0]) ok = true;
                if (ok) {
                    net::flushDnsCache(err);
                    net::Probe after = net::probeDns("after", newDns[0]);
                    rep.add("Network", "dns", "DNS provider", Status::Applied,
                            dnsChoice + " set on '" + dnsAdapter.friendlyName + "' (verified).");
                    if (dnsBeforeMs > 0 && after.medianMs > 0)
                        rep.measurements.push_back("DNS lookup time (measured, median of 5): " + std::to_string(static_cast<int>(dnsBeforeMs)) +
                                                   " ms -> " + std::to_string(static_cast<int>(after.medianMs)) + " ms");
                } else {
                    rep.add("Network", "dns", "DNS provider", Status::Failed, "DNS servers did not change on the adapter.");
                }
            }
        }

        // -------------------------------------------------------------- processes
        if (opts.processes != ProcMode::Off && env_.procs) {
            P(76, opts.processes == ProcMode::Max ? "MAX BOOST: closing background processes" : "Closing known background apps");
            ReducerOutcome ro2 = reduceProcesses(*env_.procs, ro, cb.cancel);
            std::ostringstream o;
            o << ro2.closed.size() << " of " << ro2.targeted.size() << " processes closed";
            if (!ro2.closed.empty()) o << " (about " << formatBytes(ro2.memoryFreedEstimate) << " of working set, estimate)";
            o << "; priority: " << ro2.priorityRaised << " raised, " << ro2.priorityLowered << " lowered.";
            if (ro2.targeted.empty())
                rep.add("Processes", "procs", "Background processes", Status::AlreadyOk, "No closable background processes found.");
            else if (!ro2.stillRunning.empty()) {
                std::string names;
                for (size_t i = 0; i < ro2.stillRunning.size() && i < 8; ++i) names += (i ? ", " : "") + ro2.stillRunning[i].name;
                rep.add("Processes", "procs", "Background processes", Status::Warning, o.str() + " Still running: " + names + ".");
            } else {
                rep.add("Processes", "procs", "Background processes", Status::Applied, o.str() + " (verified).");
            }
        }
    }

    // ------------------------------------------------------------------ junk cleaning
    if (opts.cleanJunk) {
        P(82, "Cleaning junk files");
        JunkCleaner jc(env_.cleaner);
        for (const auto& cat : jc.categories()) {
            if (cancelled()) {
                rep.add("Cleanup", "cancel", "Cleanup cancelled", Status::Warning, "Remaining categories were skipped.");
                break;
            }
            if (cat.tier != Tier::Safe || !cat.selectedByDefault) continue;
            P(84, "Cleaning: " + cat.title);
            CategoryResult r = jc.clean(cat, {}, cb.cancel);
            rep.junkFilesScanned += r.scanned;
            rep.junkFilesDeleted += r.deleted;
            rep.junkFilesSkipped += r.skipped;
            rep.junkFilesFailed += r.failed;
            rep.junkBytesReclaimed += r.bytesReclaimed;
            rep.add("Cleanup", cat.id, cat.title, r.status, countsText(r));
        }
    }

    // ------------------------------------------------------------------ measurements
    P(96, "Measuring result");
    LoadSnapshot after = sampleLoad(150);
    if (before.ramFree && after.ramFree)
        rep.measurements.push_back("Free RAM (measured): " + formatBytes(before.ramFree) + " -> " + formatBytes(after.ramFree));
    if (env_.procs && opts.processes != ProcMode::Off)
        rep.measurements.push_back("Running processes (measured): " + std::to_string(procCountBefore) + " -> " +
                                   std::to_string(env_.procs->list().size()));
    if (rep.junkFilesScanned)
        rep.measurements.push_back("Storage reclaimed by cleanup (measured, verified deletions only): " + formatBytes(rep.junkBytesReclaimed));
    P(100, "Done");
    return rep;
}

// ============================================================================ restore
Report Optimizer::restore(const BackupSet& set, const Callbacks& cb) {
    Report rep;
    BusyGuard guard;
    if (!guard.owned) {
        rep.add("System", "busy", "Another operation is running", Status::Failed, "Wait for the current operation to finish.");
        return rep;
    }
    rep.backupId = set.id;
    IRegistry& reg = *env_.reg;
    std::vector<BackupEntry> relaunch;
    size_t n = 0;
    for (auto it = set.entries.rbegin(); it != set.entries.rend(); ++it, ++n) {
        const BackupEntry& e = *it;
        if (cb.progress) cb.progress(static_cast<int>(100 * n / std::max<size_t>(1, set.entries.size())), "Restoring " + e.kind);
        std::string err;
        if (e.kind == "reg") {
            Hive h = e.get("hive") == "HKLM" ? Hive::HKLM : Hive::HKCU;
            std::string key = e.get("key"), name = e.get("name");
            std::string title = e.get("tweak") + " (" + e.get("hive") + "\\" + key + "\\" + name + ")";
            bool existed = e.get("existed") == "1";
            bool ok;
            if (existed) {
                RegValue v = e.get("type") == "dword" ? RegValue::dw(static_cast<uint32_t>(std::stoul(e.get("data")))) : RegValue::sz(e.get("data"));
                ok = reg.write(h, key, name, v, err);
                if (ok) {
                    RegRead r = reg.read(h, key, name);
                    ok = r.state == RegRead::Found && r.value == v;
                    if (!ok) err = "value did not persist";
                }
            } else {
                ok = reg.removeValue(h, key, name, err);
                if (ok) {
                    ok = reg.read(h, key, name).state == RegRead::NotFound;
                    if (!ok) err = "value still present";
                }
            }
            rep.add("Registry", e.get("tweak"), title, ok ? Status::Applied : Status::Failed,
                    ok ? (existed ? "Original value restored (verified)." : "Value created by the optimizer removed (verified).") : err);
        } else if (e.kind == "power") {
            std::string now;
            bool ok = power::setActive(e.get("guid"), err) && power::activeScheme(now, err) && now == e.get("guid");
            rep.add("Power", "powerplan", "Power plan", ok ? Status::Applied : Status::Failed, ok ? "Original plan restored (verified)." : err);
        } else if (e.kind == "service") {
            unsigned start = static_cast<unsigned>(std::stoul(e.get("start")));
            bool ok = services::setStartType(e.get("name"), start, e.get("delayed") == "1", err);
            if (ok && e.get("running") == "1" && start != 4) ok = services::start(e.get("name"), err);
            auto st = services::query(e.get("name"));
            ok = ok && st.startType == start;
            rep.add("Services", e.get("name"), e.get("display"), ok ? Status::Applied : Status::Failed,
                    ok ? "Original start type restored (verified)." : err);
        } else if (e.kind == "dns") {
            std::vector<std::string> servers;
            for (auto& s : splitStr(e.get("servers"), ','))
                if (!s.empty()) servers.push_back(s);
            unsigned idx = static_cast<unsigned>(std::stoul(e.get("ifindex")));
            bool wasStatic = e.get("static") == "1";
            bool ok = net::restoreDns(idx, wasStatic, servers, err);
            rep.add("Network", "dns", "DNS on " + e.get("adapter"), ok ? Status::Applied : Status::Failed,
                    ok ? (wasStatic ? "Previous DNS servers restored." : "Automatic (DHCP) DNS restored.") : err);
        } else if (e.kind == "proc") {
            relaunch.push_back(e);
        }
    }
    if (!relaunch.empty() && env_.procs) {
        for (auto& e : relaunch) {
            std::string err;
            if (!env_.procs->launch(e.get("path"), err))
                rep.add("Processes", e.get("name"), "Relaunch " + e.get("name"), Status::Failed, err);
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(1500));
        auto now = env_.procs->list();
        for (auto& e : relaunch) {
            bool running = std::any_of(now.begin(), now.end(), [&](const ProcEntry& p) { return iequals(p.name, e.get("name")); });
            if (running) rep.add("Processes", e.get("name"), "Relaunch " + e.get("name"), Status::Applied, "Application started again (unsaved state cannot be recovered).");
        }
    }
    if (rep.count(Status::Failed) == 0 && env_.store) {
        std::string err;
        if (!env_.store->markRestored(set, err)) rep.add("Backup", set.id, "Restore marker", Status::Warning, err);
    }
    return rep;
}

// ============================================================================ report text
std::string renderReport(const Report& r) {
    std::ostringstream o;
    o << "FiveM Optimizer PRO - report (" << isoNow() << ")\n";
    o << "Applied: " << r.count(Status::Applied) << "   Already OK: " << r.count(Status::AlreadyOk)
      << "   Skipped: " << r.count(Status::Skipped) << "   Warnings: " << r.count(Status::Warning)
      << "   Failed: " << r.count(Status::Failed) << "\n";
    if (!r.backupId.empty()) o << "Backup: " << r.backupId << "\n";
    if (r.restartRecommended) o << "A restart or sign-out is recommended for some changes to fully apply.\n";
    o << "\n";
    for (const auto& i : r.items) o << "[" << statusName(i.status) << "] " << i.category << " - " << i.title << ": " << i.detail << "\n";
    if (!r.measurements.empty()) {
        o << "\nMeasurements\n";
        for (const auto& m : r.measurements) o << "  " << m << "\n";
    }
    return o.str();
}

}  // namespace fmo
