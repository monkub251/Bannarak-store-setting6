#pragma once
#include <atomic>
#include <functional>
#include <set>
#include <string>

#include "Backup.h"
#include "FiveM.h"
#include "JunkCleaner.h"
#include "Network.h"
#include "Platform.h"
#include "ProcessReducer.h"
#include "Registry.h"
#include "Services.h"
#include "Tweaks.h"
#include "Types.h"

namespace fmo {

enum class ServiceMode { Off, Optional, Aggressive };
enum class ProcMode { Off, KnownApps, Max };

struct Options {
    uint32_t profiles = ProfileImpact | ProfileFlow;
    bool cleanJunk = true;
    bool powerPlan = true;
    bool applyFastestDns = false;
    bool pointerPrecisionOff = false;
    ServiceMode services = ServiceMode::Off;
    ProcMode processes = ProcMode::Off;
    std::set<std::string> keepProcesses = {"discord.exe"};  // never closed in any mode

    // MAX BOOST: every reduction switched on at once.
    static Options maxBoost() {
        Options o;
        o.services = ServiceMode::Aggressive;
        o.processes = ProcMode::Max;
        return o;
    }
};

struct Callbacks {
    std::function<void(int percent, const std::string& message)> progress;
    const std::atomic<bool>* cancel = nullptr;
};

struct Env {
    IRegistry* reg = nullptr;
    BackupStore* store = nullptr;
    IProcessApi* procs = nullptr;
    SysInfo sys;
    FiveMInfo fivem;
    CleanerEnv cleaner;
};

class Optimizer {
public:
    explicit Optimizer(Env env) : env_(std::move(env)) {}
    // OPTIMIZE NOW. Order: detect -> plan -> read current state -> backup (validated) -> apply+verify -> close
    // processes -> clean junk -> report. Nothing is changed before the backup has been written and read back.
    Report run(const Options& opts, const Callbacks& cb = {});
    // Reverts one backup. Registry values that did not exist are removed again.
    Report restore(const BackupSet& set, const Callbacks& cb = {});

private:
    Env env_;
};

// Plain-text rendering of a report (also used by "Export report").
std::string renderReport(const Report& r);

}  // namespace fmo
